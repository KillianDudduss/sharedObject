library(shiny)
library(sp)
library(rgdal)
library(raster)
library(rgeos)
library(lattice)
library(plotGoogleMaps)
library(RColorBrewer)
library(dismo)
library(shinyjs)

shinyUI(bootstrapPage(
#useShinyjs(),
HTML(' <input type="text" id="userID" name="userID" style="display: none;"> '),
HTML(' <input type="text" id="username" name="username" style="display: none;"> '),

includeScript("get_user_id.js"),

theme ="cascade.css",
useShinyjs(),
  div(
    id = "loading_page",
    h1("Loading...")
  ),
  hidden(
        div(id = "main_content",
h1("Success"),
navbarPage(title=div("MCDA Map Application",textOutput("typechosen")),
windowTitle = "MCDA Map Application",

                #########Panel 1 #############################################################################
              tabPanel("Welcome",
		useShinyjs(),
                                        tags$div(id="welcome",
                        uiOutput("welcome"),
                                                                                          tags$br(),
                                                                                          uiOutput("testdata"),
                                                                                          tags$br(),
                                                                                          tags$p("Welcome to this Shiny web application."),
                                                                                          tags$br(),
                                                                                          tags$p("The main purpose of this project was to create a web tool able to help policy makers concerning land expansion issues in Aberdeenshire. The application calculate an index on a map to determine good areas for woodland or agricultural expansion. You can use a threshold tool to determine the best hectares for the project selected expansion. You are able to save some combination of weights and produce an average map of your favourite combination. You participate to build a consensus map concerning woodland and agricultural expansion."),
                                                                                          tags$br(),
                                                                                          tags$p("The application was realized with Shiny, R, CSS, HTML and JavaScript by the Information and Computational Sciences department of the James Hutton Institute"),
                        img(src="Huttonlogo345.jpg", height = 200, width = 200, align = "center")
                                                    ),
                                                          tags$br(),tags$br(),tags$br()

             ),


                ##########Panel 2 #############################################################################
                                      tabPanel("Select project",
                                          tags$div(id="project",
                                                   tags$h3("Select project"),
                                                   tags$p(" "), #text
                                                   uiOutput("renderProject"),
                                                   fileInput('file', 'Use my data'),
                                                   tags$p("The file must be in .zip format and must contain:"),
                                                   tags$p("~ negatives and positives pictures"),
                                                   tags$p("~ two text files (one for negative and for positive ) composed by"),
                                                   tags$p("Number File Nickname Description"),
                                                   tags$p("Even if you have no negative file"),
                                                   tags$p("Number begins with 1, File is the name of the pictures with the extension"),
                                                   tags$p("~ if you have hard contraints files, a text file named Hard_Constraint.txt composed by"),
                                                   tags$p("Number File Nickname Description"),
                                                   tags$p("with the hard constraints pictures"),
                                                   tags$p("~ a TIF file named extent delimiting the area of the data"),
                                                   tags$p("~ a text file named index and composed of a single line with: the name of the folder without extension (",
                                                          span("Attention to", style = "texte:bold"), " upper/lower case.), an adjectif, description, the name of the positif file and the name of the negatif file"),
                                                   tags$strong("Beware:"),
                                                   tags$p("Nickname, Descriptions or Names must not contain spaces , use _"),
                                                   tags$p("Use a different name than the already known Project for your folder"),
                                                   tags$br(),
                                                   downloadButton('downloadData', 'Download an example'),
                                                   tags$br(),
                                                   tags$p("After you select My Data and upload your file you can press ok ."),
                                                   textOutput("erreur"),
                                                   tags$head(tags$style("#erreur{color: red;}")),
                                                   textOutput("uploadok"),
                                                   tags$head(tags$style("#uploadok{color: blue;}")),
                                                   actionButton('uploaded', 'ok')

                                          )
                                           ),
                ##########Panel 3 #############################################################################
                tabPanel("Select area",
                         tags$div(id="area",
                                  tags$h3("Select area"),
                                  tags$p("You can choose a specific working area by drawing a rectangle on the map or by a shapefile."),
                                  tags$br(),
                                  actionButton('selecta', 'Select'),
                                  uiOutput("error"),
                                  plotOutput("selectarea", click= "plot_click", brush = brushOpts(id = "plot_brush"),
                                             hover = hoverOpts(id = "plot_hover")),
                                  tags$br(),
                                  actionButton('fullarea', 'Select the full area'),
                                  tags$br(),
                                  fileInput('sarea', 'Select with a shapefile', multiple=TRUE),
                                  tags$p("The file needs to be a .zip with the shapefile in it."),
                                  tags$p("Please upload ALL the files composing a shapefile (shp, dbf...)."),
                                  plotOutput("renderShapefile")
                         )
                ),
                ##########Panel 4 #############################################################################
                        tabPanel("Select hard constraints",
                                 tabsetPanel("subpanelHC",
                                 tabPanel("List of hard constraints",
                                 tags$div(id="listHC",
                                          tags$h3("List of hard constraints"),
                                          #tags$p("Groups of settlers began building the first known permanent houses on Scottish soil around 9,500 years ago,"), text
                                          tags$br(),
                                          tableOutput("matrixHC"),
                                          tags$br(),
                                          uiOutput("renderSelectHC"),
                                          uiOutput("mapShowHC"),img(src="bigorb.jpg", height = 40, width = 40, align = "center"),
                                          tags$br()
                                 )
                                 ),
                                 tabPanel("Choice of hard constraints",
                                 tags$div(id="choiceHC",
                                          tags$h3("Hard constraints chosen by the User"),
                                          tags$br(),
                                          tags$p("You can choose the hards constraints you want (four maximum)."),
                                          tags$br(),
                                          uiOutput("renderChoiceHC"),
                                          actionButton("HCbutton", "Ok"),tags$br(),tags$br(),
                                          uiOutput("mapFinalHC"),img(src="bigorb.jpg", height = 40, width = 40, align = "center"),tags$br()
                                    )
                                  )
                                )
                        ),
                ##########Panel 5 #############################################################################
                                            tabPanel("Select criteria",
                                                tabsetPanel("subpanelCriteria",
                                                    tabPanel("List of criteria",
                        tags$div(id="listcrit",
                                                                                            tags$h3("List of Criteria"),
                                                                                            #tags$p("and the first villages around 6,000 years ago."), text
                            tags$br(),
                                tableOutput("matrixPN"),
                            tags$br(),
                                                                                            uiOutput("renderSelectCriteria"),
                                                              uiOutput("mapShowCriteria"),img(src="bigorb.jpg", height = 40, width = 40, align = "center"),
                                                        tags$br()
                        )
                                                                                        ),
                                                                                        tabPanel("Choice of criteria",                       
                                                          #div 2
                        tags$div(id="choicecrit",
                           tags$h3("Criteria chosen by the User"),
                             tags$br(),
                             tags$p("You can choose the criteria you want. Just put them in the right window. 2 criteria are already selected."),
                                                                     tags$br(),
                                                                                             tags$h4("Electre and LWC Methods used"),
                                                                                             tags$br(),
                                                                                             tags$p("The Linear Weight Combination can be used : It combines TIFF files which represent the criteria in an unique raster. You are able to modify the weight of this linear combination"),
                               tags$br(),
                                                         tags$p(tags$b("LWC")," : Each criteria which is not on the right will count as NA and will be used to calculate the background. Each criteria selected set to 0 will not be used at all. Both positive and negative criteria are normalized to a total weight of 1",tags$b("each"),"."),
                               tags$br(),
                               tags$p(tags$b("LWC2")," :  Positive and negative criteria are normalized ",tags$b("together")," to a total weight of 1."),
                               tags$br(),
                                                                                               #tags$p("The Electre method can be used : The well-preserved village of Skara Brae on the mainland of Orkney dates from this period."),
                               tags$h4("Positive Criteria"),
                               uiOutput("chooserpdisplayed"),
                               tags$h4("Negative Criteria"),
                                                                                               uiOutput("chooserndisplayed")
                                                                               )
                                                                                        )
                                                )
               ),

                ##########Panel 6 #############################################################################
             tabPanel("Select weights",
                          sidebarLayout(
                                                                                        #Left side
                              sidebarPanel(
                                 tags$h3("Criteria Weights"),
                                 tags$p("For each selected criteria, choose its weight between 0 and 1 and the method you want. Then press Go!. If you want to store a combination, press Save!. If you want to store your final combination press Save for real"),
                                   tags$h4("Positive Criteria"),
                                   uiOutput("slidersp"),
                                   tags$h4("Negative Criteria"),
                                   uiOutput("slidersn"),

                                                                                                                      tags$br(),

                                                                                                                  #div method selection
                                                                                                                            tags$div(id="metsel",

            radioButtons("methodsmain",

                                     label = h3("Method selection"),
                                                                                                                                                                                 choices = list("Method LWC" = 1, "Method LWC2" = 2, "Electre" = 3),

                                     selected = 1)
                                           ),
                                                                                                                       tags$br(),
                                   actionButton("goButton", "Go!"),
                                   actionButton("saveButton", "Save weights"),
                                                                                                                       actionButton("savorButton", "Save weights for real!"),
                                                                                                                       actionButton("saveRasterButton", "Save raster"),
                                                                                                                       uiOutput('downloadRasterbutton')
                                                                                                        ),

                                                                                 #Right side
                                                           mainPanel(
                                 tags$div(id="maparea1",
                                    tags$h3("Mapping area"),
                                    tags$p("The best value is 1 (blue) and the worst 0 (red) for the project chosen Expansion considering these criteria, the weights selected and the chosen method")
                                 ),
                                 uiOutput("mapMain"),
                                 img(src="bigorb.jpg", height = 40, width = 40, align = "center"),

                                                                                                                 tags$br(),
                                                                                                                 tags$br(),
                                                                                                                 tags$br(),

                                                                                                                #div 2
                                                                                                                     tags$div(id="histogar",
                                                                                                                        tags$h3("Histogram"),
                                                                                                                        tags$p("An histogram of the above map")),
                                         tags$br(),
                                 plotOutput("histo"),
                                 img(src="bigorb.jpg", height = 40, width = 40, align = "center")
                              )
                         )
                 ),

                ##########Panel 7 #############################################################################
              tabPanel("Threshold",
                               sidebarLayout(
                                                                                                                        #Left side
                                  sidebarPanel(
                                    tags$h3("Threshold"),
                                    tags$p("Select the number of ha you want"),
                                    uiOutput("renderThr"),
                                    tags$p("Select the percentage you want"),
                                    uiOutput("renderThrQ"),
                                                                                                                                                actionButton("goButtonThr", "Go!"),
                                    tags$br(),tags$br(),
                                    uiOutput("stata")
                                                                                                                            ),

                                                                                                                        #Right side          
                                                                                                          mainPanel(
                                    tags$div(id="mapareathr",
                                      tags$h3("Mapping area"),
                                      tags$p("Best pixels under the threshold are in blue, the others are in red.")),
                                      uiOutput("mapThr"),
                                      img(src="bigorb.jpg", height = 40, width = 40, align = "center")
                                  )
                                )
                       ),

                ##########Panel 8 #############################################################################
                                        tabPanel("Compare methods",
                                                 sidebarLayout(
                                                   #Left side
                                                   sidebarPanel(
                                                     checkboxGroupInput("checkGroupCM",
                                                                        label = h3("Choose the methods to be compared"),
                                                                        choices = list("LWC" = 1, "LWC2" = 2, "Electre" = 3),
                                                                        selected = NULL),
                                                     actionButton("comparebutton","Ok"),tags$br(),uiOutput("renderSelectlayerCM"),
                                                     tags$h3("Scatterplot"),
                                                     tags$p("A graph of plotted points that show the relationship between the values obtained with each method chosen."),
                                                     plotOutput("scatter"),
                                                     tags$h3("Compare threshold"), uiOutput("renderSelectlayerThrCM"),tags$p("Select the number of ha you want"),
                                                     uiOutput("renderThrCM"), uiOutput("renderThrCMQ")

                                                   ),

                                                   #Right side
                                                   mainPanel(
                                                     tags$div(id="mapareaCM",
                                                              tags$h3("Mapping area"),textOutput("txtmapCM")
                                                     ),
                                                     uiOutput("mapCM"),
                                                     img(src="bigorb.jpg", height = 40, width = 40, align = "center"),
                                                     tags$br(),
                                                     tags$div(id="mapareaCM",
                                                              tags$h3("Threshold map")
                                                     ),
                                                     plotOutput("mapThrCM"),textOutput("txtgoodarea"), tags$br(),tags$br(),tags$br()
                                                   )
                                                 )
                                        ),

                ##########Panel 9 #############################################################################
              tabPanel("Stats",
                                        #div 1
                                                                                                                        tags$div(id="weista",
                              tags$h3("Weights"),
                              tags$br(),
                                tags$h4("Weights P"),
                                  tableOutput("matrixCurrentWeightsP"),
                                  tags$br(),
                                                                                                                                tags$h4("Weights N"),
                                  tableOutput("matrixCurrentWeightsN")),
                                                                                                                                  tags$br(),

                                                                                                                        tags$div(id="weihi",
                              tags$h3("Criteria History Matrix"),
                                                                                                                                tags$h4("Method LWC"),
                                    tableOutput("christomatLWC1"),
                                                                                                                                  conditionalPanel(
                                      condition = "input.saveButton != 0",

    downloadButton('downloadCWH_LWC1', 'Download')),
                                                                                                                                tags$h4("Method LWC2"),
                                    tableOutput("christomatLWC2"),
                                                                                                                                        conditionalPanel(
                                        condition = "input.saveButton != 0",

      downloadButton('downloadCWH_LWC2', 'Download')),
                                                                                                                                tags$h4("Method Electre"),
                                                                                                                                        tableOutput("christomatElectre"),
                                                                                                                                        conditionalPanel(
 
      condition = "input.saveButton != 0",

      downloadButton('downloadCWH_Electre', 'Download'))
                                                                                                                                )            
                     ),               

 ##########Panel 10 #############################################################################
                                         tabPanel("Average",
                               mainPanel(
                                 tags$div(id="mapareaAV",
                                 tags$h3("Average User Map Method LWC"),
                                                                                                         tags$p("It corresponds to the map with the geometric mean of each criteria selected by the user with method LWC. The best value is 1 (blue) and the worst 0 (red)")),
                                    uiOutput("mapAV_LWC1"),

    tags$br(),

    uiOutput("tabAV_LWC1"),
                                    img(src="bigorb.jpg", height = 40, width = 40, align = "center"),

                                                                                                                                 tags$div(id="mapareaAV",
                                 tags$h3("Average User Map Method LWC2"),
                                                                                                                           tags$p("It corresponds to the map with the geometric mean of each criteria selected by the user with method LWC2. The best value is 1 (blue) and the worst 0 (red)")),
                                                                                                                   uiOutput("mapAV_LWC2"),
                                                                                                                                                 tags$br(),

     uiOutput("tabAV_LWC2"),
                                     img(src="bigorb.jpg", height = 40, width = 40, align = "center"),


                                                                                                                                 tags$div(id="mapareaAV",
                                                                                                                                 tags$h3("Average User Map Method Electre"),
                                                                                                                                 tags$p("It corresponds to the map with the geometric mean of each criteria selected by the user with method Electre. The best value is 1 (blue) and the worst 0 (red)")),
                                                                  uiOutput("mapAV_Electre"),
                                                                  tags$br(),
                                                                  uiOutput("tabAV_Electre"),
                                                                  img(src="bigorb.jpg", height = 40, width = 40, align = "center")
                                 )
                     ),

                ##########Panel 11 #############################################################################
                                        tabPanel("Consensus",
                                mainPanel(
                                  tags$div(id="mapareaCON",
                                  tags$h3("Users Consensus Map Method LWC"),
                                                                                                                            tags$p("It corresponds to geometric mean of the final combinations stored on the website with method LWC. The best value is 1 (blue) and the worst 0 (red)")),

      uiOutput("mapCON_LWC1"),

      tags$br(),

      uiOutput("tabCON_LWC1"),
                                      img(src="bigorb.jpg", height = 40, width = 40, align = "center"),
                                                                                                                                             
                                                                                                                                        tags$div(id="mapareaCON",
                                  tags$h3("Users Consensus Map Method LWC2"),
                                                                                                                                        tags$p("It corresponds to geometric mean of the final combinations stored on the website with method LWC2. The best value is 1 (blue) and the worst 0 (red)")),

uiOutput("mapCON_LWC2"),

      tags$br(),
                                                                                                                                                  uiOutput("tabCON_LWC2"),
                                      img(src="bigorb.jpg", height = 40, width = 40, align = "center"),
                                                                                                                                        tags$div(id="mapareaCON",

     tags$h3("Users Consensus Map Method Electre"),
                                                                                                                                                 tags$p("It corresponds to geometric mean of the final combinations stored on the website with method Electre. The best value is 1 (blue) and the worst 0 (red)")),
                                                                                                                                        uiOutput("mapCON_Electre"),
                                                                                                                                        tags$br(),
                                                                                                                                        uiOutput("tabCON_Electre"),
                                                                                                                                        img(src="bigorb.jpg", height = 40, width = 40, align = "center")
                                )
                                        ),

                ##########Panel 12 #############################################################################
                 tabPanel("Compare projects",
                          sidebarLayout(
                            #Left side
                            sidebarPanel(

                              uiOutput("selectrastersaved"),
                              actionButton("CPrbutton", "Ok"),tags$br(),
                              uiOutput("downloadCPrbutton"), uiOutput("downloadCPrLegendbutton"),
                              plotOutput("Legend"),tags$br(),tags$br(),
                              tags$h3("Threshold map"),
                              uiOutput("selectlayerCPrcompared"),tags$br(),
                              tags$br(),
                              uiOutput("renderThrCPr"), uiOutput("renderThrCPrP"),
                              uiOutput("textthr")
                            ),

                            #Right side
                            mainPanel(
                              tags$div(id="mapareaCPr",
                                       tags$h3("Mapping area"),
                                       tags$p("For each pixel, its values in the rasters selected are compared. The final value corresponds to the layer which has the higher value for the pixel.")
                              ),
                              uiOutput("mapCPr"),
                              img(src="bigorb.jpg", height = 40, width = 40, align = "center"),tags$br(),tags$br(),
                              tags$div(id="mapareaCPr",
                                  tags$h3("Threshold map"),
                                  tags$p("Best pixels under the threshold are in blue, the others are in red.")
                              ),
                              uiOutput("mapCPrThr"),
                              img(src="bigorb.jpg", height = 40, width = 40, align = "center")

                            )
                          )
                 )

)))))



