 library(raster)

#' Load the data and call the function to create the criteria raster corresponding to the project
#' 
#' @param project A number corresponding to a project.
#' @return Nothing
#' @examples
#' launchingProject(1)
launchingProject <-function(project, Pr){
	Prinfo <- Pr[project,]
	type <<- Prinfo[1,2]
	# Read the positive and negative files associated to the project chosen with the information about the criteria
	HP<<- read.table(paste0("../data/",type,"/", Prinfo[1,5]),h=T)
	HN<<- read.table(paste0("../data/",type,"/", Prinfo[1,6]),h=T)
	#Binding of positive and negative tables
	HPN<<- rbind(HP,HN)
	# print(HPN$Nickname)
	row.names(HPN)<-sapply(HPN$Nickname, toString)
	HPN <<- HPN
	if (length(HN[,1])==0){
	  # Stock the name of each criteria
	  xp <<-HP[,3]
	  x1p <<-sapply(xp, toString)
	  
	  #Create the positive raster, negative and positive+negative criteria raster
	  rst.pl.original <<- creationCriteriaRaster(HP)
	  rst.pnl.original <<- creationPNLCriteriaraster(rst.pl.original,rst.nl.original)
	  
	  # If the user has chosen a specific area, crop of the rasters
	  rst.pl <<- cuttingAreaSelected(rst.pl.original, areaselected)
	  rst.pnl <<-  cuttingAreaSelected(rst.pnl.original, areaselected)
	  
	  # Creation of the files which will contain the saved combinations of weights
	  path_final <- c()
	  path_temp <- c()
	  path_final=sapply(1:length(Met[,1]), function(i){
	    path_f <- paste0("./finalweights",Met[i,2],"_",type,".txt")
	  })
	  
	  path_temp=sapply(1:length(Met[,1]), function(i){
	    path_t <- paste0("./weights",Met[i,2],"_",type,".txt")
	  })
	  
	  PF <- data.frame(path_final, path_temp)
	  row.names(PF) <- Met[,2]
	  Path <<- PF
	  
	  #If the files don't already exist, they are created
	  lapply(1:nrow(Path), function(i){
	    if (file.exists(paste0(Path[i,1]))==F){
	      file.create(paste0(Path[i,1]))
	    }
	    if (file.exists(paste0(Path[i,2]))==F){
	      file.create(paste0(Path[i,2]))
	    }
	  })
	}else{
  	# Stock the name of each criteria
  	xp <<-HP[,3]
  	xn <<-HN[,3]
  	x1p <<-sapply(xp, toString)
  	x1n <<-sapply(xn, toString)

  	#Create the positive raster, negative and positive+negative criteria raster
  	rst.pl.original <<- creationCriteriaRaster(HP)
  	rst.nl.original <<- creationCriteriaRaster(HN)
  	rst.pnl.original <<- creationPNLCriteriaraster(rst.pl.original,rst.nl.original)
  	
  	# If the user has chosen a specific area, crop of the rasters
  	rst.pl <<- cuttingAreaSelected(rst.pl.original, areaselected)
  	rst.nl <<-  cuttingAreaSelected(rst.nl.original, areaselected)
  	rst.pnl <<-  cuttingAreaSelected(rst.pnl.original, areaselected)
  
  	# Creation of the files which will contain the saved combinations of weights
  	path_final <- c()
  	path_temp <- c()
  	path_final=sapply(1:length(Met[,1]), function(i){
  	  path_f <- paste0("./finalweights",Met[i,2],"_",type,".txt")
  	  #path_final <- c(path_final, path_f)
  	})
    
  	path_temp=sapply(1:length(Met[,1]), function(i){
  	  path_t <- paste0("./weights",Met[i,2],"_",type,".txt")
  	  #	path_temp <- c(path_temp, path_t)
  	})
  
  	PF <- data.frame(path_final, path_temp)
  	row.names(PF) <- Met[,2]
  	Path <<- PF
  	#If the files don't already exist, they are created
  	lapply(1:nrow(Path), function(i){
  	  if (file.exists(paste0(Path[i,1]))==F){
  	    file.create(paste0(Path[i,1]))
  	  }
  	  if (file.exists(paste0(Path[i,2]))==F){
  	    file.create(paste0(Path[i,2]))
  	  }
  	})
	}
}



#' Crop a raster with an area
#' 
#' @param ras A raster to be cropped
#' @param area A raster with the same CRS than ras and a smaller extent
#' @return the cropped raster
#' @examples
#' cuttingAreaSelected(rst.pnl,areaselected)
cuttingAreaSelected <- function(ras, area=ras){
  ras.crop <-crop(ras,area)
  return(ras.crop)
}

#' Add the hard constraints to a raster
#' 
#' @param ras A raster
#' @param HCras the binary raster with the hard constraints (HCras must have the same extent and CRS than ras). The pixels with a value different of 0 in the HCras will be replaced by NA in the final raster
#' @return the raster with NA values corresponding to the hard constraints
#' @examples
#' r <- raster(matrix(1:4))
#' h <- raster(matrix(c(NA,NA,2,1)))
#' addHC(r,h)
addHC <-function(ras, HCras){
  namelayers <- names(ras)
  Q<-lapply(1:nlayers(ras), function(i){
    ras[[i]] <- overlay(ras[[i]], HCras, fun=function(x,y){ifelse(y ==0,x,NA)})
    ras[[i]]=ratify(ras[[i]])
  })
  ras=stack(Q)
  names(ras) <- namelayers
  return(ras)
  
}

#' Calculate the number of pixels of a raster which are not NA
#' 
#' @param ras A raster
#' @return the number of pixels of a raster which are not NA
#' @examples
#' r <- raster(matrix(c(NA,NA,1:3)))
#' nbpx_notNA(r)
nbpx_notNA <- function(ras){
	somma <-length(na.omit( ras@data@values))
	return(somma)
}

#' Calculate the total area of a raster which is not NA
#' 
#' @param ras A raster
#' @return a number corresponding to the total area of a raster which is not NA in ha
#' @examples
#' r <- raster(matrix(c(NA,NA,2,1)))
#' maxThrCalculation(r)
maxThrCalculation <- function(ras){
	somma <- nbpx_notNA(ras)
    # Calculus of the resolution of the map
    rx <-xres(ras)
    ry <-yres(ras)
   
    # Calculus the total area of the pixels which are not NA
    area <-as.numeric((rx*ry)/10000*somma)
   
	return(area)
}

#' Generate the matrix with all the weights saved by the user during the session
#' 
#' @param dataweights A datatable containing weights
#' @return an array with all the weights saved by the user
#' @examples
#' matrix_Stats(readWeightssaved("LWC1","temp"))
matrix_Stats <- function(dataweights){
	#Read the txt file created to save the weights. Create the matrix
	mat <-t(dataweights)
	tp <-sapply(HP[,3], toString)
	tn <-sapply(HN[,3], toString)
	rownames(mat)<-c(tp,tn)
	return(mat)
}

#' Calculate the average vector of the weights vector given as parameter
#' 
#' @param weightsSaved A matrix corresponding to the weights saved in a file. Each row corresponds to a criteria and each column to a vector saved
#' @return the average vector
#' @examples
#' mat <-matrix(c(1,1,1,0.1,0.1,0.1), nrow=2)
#' weightAverage(mat)
weightAverage <- function(weightsSaved){
	#Read the txt file created to save the weights
	mater <-weightsSaved
	#Create vector average
	vec <-c()

	#Loop for each criteria do the geometric mean of the values saved
	vec=sapply(1:ncol(mater), function(i){
		m<-exp(mean(log(na.omit(mater[ ,i]))))
		if(is.nan(m)){m<-NA}  
		vec <- c(vec,m)
	})
	return(vec)
}

#' Generate the matrix ready to be displayed with the weights given as parameter
#' 
#' @param weight the vector to be displayed
#' @return the matrix ready to be displayed
#' @examples
#' weightArray(weightAverage(readWeightssaved("LWC1", "temp")))
weightArray <- function(weight){
  descript <-sapply(HPN[,4], toString)
  descript <- gsub("_", " ", descript)
  descript <- strtrim(descript, 20)
  
  matrix <- cbind(descript,weight)
  colnames(matrix) <- c('Criteria','Weight')
  
  return(matrix)
}

#' Read the size of the temporary file associated to the method given as parameter where the weightsvector are saved
#' 
#' @param method the method corresponding to the temporary file you want the size
#' @return the size of the temporary file
#' @examples
#' temp_WeightssavedSize("LWC2")
temp_WeightssavedSize <-function(method){
      fpe <- file.info(paste0(Path[method,2]))$size
      return(fpe)						   
}

#' Read the vectors saved in a file associated to the method given as parameter
#' 
#' @param method the method corresponding to the file you want to read
#' @param status final by default, indicate the file to be read (final or temp)
#' @return the datatable corresponding to the file
#' @examples
#' readWeightssaved("LWC2")
#' readWeightssaved("LWC2", status="temp")
readWeightssaved <- function(method, status="final"){
	if (status=="final"){
		fpe <- read.table(paste0(Path[method,1]),col.names=c(x1p,x1n))
	}
	else if (status=="temp"){
		fpe <- read.table(paste0(Path[method,2]),col.names=c(x1p,x1n))
	}
    return(fpe)							   
}	