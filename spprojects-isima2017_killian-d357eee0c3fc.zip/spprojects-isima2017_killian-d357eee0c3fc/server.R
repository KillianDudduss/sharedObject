# Tasks that need to occur once, e.g. sourcing scripts, reading some data, and loading packages .
################ Library ###########################################
library(shiny)
library(sp)
library(rgdal)
library(raster)
library(rgeos)
library(lattice)
library(plotGoogleMaps)
library(RColorBrewer)
library(dismo)
library(ggplot2)
library(RMySQL)
library(leaflet)
library(shinyjs)
library(devtools)
library(leafletGoogle)

################ Sources ###########################################

# setwd("C:\\Users\\dk42999\\MCDAMA\\API\\MCDAMA")
# getwd()

# Uncomment the next line when not deploying on shinyapps.io
# source("verif_db.R")
source("calc.R")
source("chooser.R")
source("methods.R")
source("creationDataRaster.R")
source("utilitarian.R")
source("resoudre.R")

#Loading of the compiled .c code
#To comment when deploying on shiny apps
 # if (Sys.info()["sysname"]=="Windows"){dyn.load("methods.dll")}
 if (Sys.info()["sysname"]=="Linux"){dyn.load("methods.so")}
#To uncomment when deploying on shiny apps
# dyn.load("methods.dll")
  
# Change Project directory to a sub directory www. Everything will happen there now.
setwd("./www/")

#Loading of the data
hc <<-raster(readGDAL("../data/CL_cscapeQ_r01.tif"))
areaselected <<- hc
Pr <<-read.table(paste0("../data/Project.txt"),h=T)
HC <<-read.table(paste0("../data/Hard_Constraint.txt"),h=T)
rst.hcl <<- creationHardConstraintRaster(HC)
use_HC<<-TRUE
Met <<-read.table(paste0("../data/Methods.txt"),h=T)

################ End of Sources ##########################################
# Define server logic required
shinyServer(function(input, output,session) {
  env<-environment()

    ############## Headers ###########################################
    ## The two next lines are here to hide the 
    ## buffering page and show the real page
    hide("loading_page")
    shinyjs::show("main_content")

    # Remove previous maps and grid to avoid oversize issue
    unlink("./*.html")
    unlink("./*.png")
    unlink("./*.png")
    unlink("./weights*.txt")
    # Reset of the rasters saved and the rasters saved numbering
    rastersaved <<- stack()
    num <<- 0
    nbgoodpx<<-0
    px <<-0
    breakscol <- c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1)
    # Define welcome message with the session username 
    output$welcome <- renderUI({
      tags$h3(paste("Welcome"),session$user,"!")
    })
    
    #test if the data is normalized
    output$testdata <- renderUI({
      validate(need(hc@data@min >= -1 && hc@data@max <= 1, "Data not normalized, please change it."))
    })
    
    # session var for maximes shapes ###
    sessionVars <- reactiveValues(area_cur=NULL)
    
    ############## Hide/Show the pannel with two shinyJs functions ###########################################
    # That's what makes the application more sequential
    ######### Tab2
    observe({
      hide(selector = "#navbar li a[data-value=tab2]")})
    
    observeEvent(input$pann2, {
      shinyjs::show(selector = '#navbar li a[data-value=tab2]')
      hide(id = "advanced")
      hide(id="Doyouwanto")
      updateTabsetPanel(session, 
                        inputId = "navbar", 
                        selected = "tab2")
    })
    
    
    ######### Tab3
    observe({
      hide(selector = "#navbar li a[data-value=tab3]")})
    
    observeEvent(input$pann3, {
      shinyjs::show(selector = "#navbar li a[data-value=tab3]")
      updateTabsetPanel(session, 
                        inputId = "navbar", 
                        selected = "tab3")
    })
    
    hide(id="pann4")
    
    ######### Tab4
    observe({
      hide(selector = "#navbar li a[data-value=tab4]")})
    
    observeEvent(input$pann4, {
      shinyjs::show(selector = "#navbar li a[data-value=tab4]")
      updateTabsetPanel(session, 
                        inputId = "navbar", 
                        selected = "tab4")
    })
    
    ######### Tab5
    observe({
      hide(selector = "#navbar li a[data-value=tab5]")})
    
    ######### Tab6a and 6b
    
    observe({
      hide(selector = "#navbar li a[data-value=tab6a]")})
    
    observe({
      hide(selector = "#navbar li a[data-value=tab6b]")})
    
    observeEvent(input$pann6, {
      if(input$advanced == TRUE){
        # It's sadvanced even if it's b
        shinyjs::show(selector = "#navbar li a[data-value=tab6b]")
        updateTabsetPanel(session, 
                          inputId = "navbar", 
                          selected = "tab6b")
      }
      else {
        shinyjs::show(selector = "#navbar li a[data-value=tab6a]")
        updateTabsetPanel(session, 
                          inputId = "navbar", 
                          selected = "tab6a")
      }
    })
    
    hide(id="metsela")
    
    # Two Buttons to update the pannel automatically (adv and basic mode).
    observeEvent(input$thresholdPannel,{
      updateTabsetPanel(session, 
                        inputId = "navbar", 
                        selected = "tab7")
    })
    
    observeEvent(input$thresholdPannela,{
      updateTabsetPanel(session, 
                        inputId = "navbar", 
                        selected = "tab7")
    })
    
    # Hide the buttons before you have clicked on the go button
    # Basic 
    hide(id="downloadRasterbuttona")
    hide(id='thresholdPannela')
    observeEvent(input$goButtona, {
      # validate(need(Reduce(function(acc, cur) { acc = (acc || (!is.na(cur) && (cur != 0))) }, weightsVector(), F), ""))
      shinyjs::show(id="downloadRasterbuttona")
      shinyjs::show(id="thresholdPannela")
    })
    
    #Advanced User
    hide(id="savePannel")

    observeEvent(input$goButton, {
      # validate(need(Reduce(function(acc, cur) { acc = (acc || (!is.na(cur) && (cur != 0))) }, weightsVector(), F), ""))
      shinyjs::show(id="savePannel")
    })
    
    ######### Tab7
    observe({
      hide(selector = "#navbar li a[data-value=tab7]")})
    
    observeEvent(input$pann6, {
      shinyjs::show(selector = "#navbar li a[data-value=tab7]")})
    
    ######### TabAdvanced-User
    # value = "tabAU",
    observe({
      hide(selector = "#navbar li a[data-value=tabAU]")})
    
    observeEvent(input$pann6, {
      if(input$advanced == TRUE){
        shinyjs::show(selector = "#navbar li a[data-value=tabAU]")
      }
    })
    
    ## Average
    hide(id = "tabAV_LWC2_desc")
    hide(id = "tabAV_Electre_desc")
    
    observe({
      input$saveButton
      input$Project
      
      validate( need(temp_WeightssavedSize("LWC2") > 0, ""))
      shinyjs::show(id="tabAV_LWC2_desc")
    })
    
    observe({
      input$saveButton
      input$Project
      
      validate( need(temp_WeightssavedSize("Electre") > 0, ""))
      shinyjs::show(id="tabAV_Electre_desc")
    })
    
    ############## Help Menu ###########################################
    
    # We need to put as much observe as we got pannel so here it's 8/9
    # Help message for the second tab
    observeEvent(input$helpProject, {
      showModal(modalDialog(title = "Help message for the user",
                            "This is a somewhat important to help the user to go through the app.",
                            easyClose = TRUE, footer = NULL))
    })
    
    # Help message for the third tab (Select Subset Area)
    observeEvent(input$helpArea, {
      showModal(modalDialog(title = "Help message for the user",
                            "This is a somewhat important to help the user to go through the app.",
                            easyClose = TRUE, footer = NULL))
    })
    
    # Help message for the fourth tab (Hard Constraint)
    observeEvent(input$helpHC, {
      showModal(modalDialog(title = "Help message for the user",
                            "This is a somewhat important to help the user to go through the app.",
                            easyClose = TRUE, footer = NULL))
    })
    
    # Help message for the fifth tab (Criteria)
    observeEvent(input$helpCrit, {
      showModal(modalDialog(title = "Help message for the user",
                            "This is a somewhat important to help the user to go through the app.",
                            easyClose = TRUE, footer = NULL))
    })
    
    # Help message for the sixth tab (Weight advanced user)
    observeEvent(input$helpWeight, {
      showModal(modalDialog(title = "Help message for the user",
                            "This is a somewhat important to help the user to go through the app.",
                            easyClose = TRUE, footer = NULL))
    })
    
    # Help message for the sixth bis tab (Weight basic user)
    observeEvent(input$helpWeighta, {
      showModal(modalDialog(title = "Help message for the user",
                            "This is a somewhat important to help the user to go through the app.",
                            easyClose = TRUE, footer = NULL))
    })
    
    # Help message for the seventh tab (Threshold)
    observeEvent(input$helpThr, {
      showModal(modalDialog(title = "Help message for the user",
                            "This is a somewhat important to help the user to go through the app.",
                            easyClose = TRUE, footer = NULL))
    })
    
    # Help message for the seventh tab (Compare Methods)
    observeEvent(input$helpCmpMth, {
      showModal(modalDialog(title = "Help message for the advanced user",
                            "This is a somewhat important to help the user to go through the app.",
                            easyClose = TRUE, footer = NULL))
    })
    
    # Help message for the seventh tab (Stats)
    observeEvent(input$helpStats, {
      showModal(modalDialog(title = "Help message for the advanced user",
                            "This is a somewhat important to help the user to go through the app.",
                            easyClose = TRUE, footer = NULL))
    })
    
    
    # Help message for the seventh tab (Average)
    observeEvent(input$helpAverage, {
      showModal(modalDialog(title = "Help message for the advanced user",
                            "This is a somewhat important to help the user to go through the app.",
                            easyClose = TRUE, footer = NULL))
    })
    
    ################ Choice of the project ###########################################
    # Creation of a radiobutton enabling to choose a project
    output$renderProject <- renderUI({
      # Read the names of the projects in the project database and create a list
      Pnames <- sapply(Pr[,2], toString)
      Pnames <- c(Pnames, "My own Data")
      mylist <- vector(mode="list", length=length(Pnames))
      mylist= lapply(1:length(Pnames), function(i){
        mylist[[i]] <- i
      })
      names(mylist) <- Pnames

      # Create the radiobutton with each name of project
      radioButtons("Project",
                   label = "You have to choose a project, by default the project selected is the first one", 
                   choices = mylist, 
                   selected = 1)
      
    })
  
    # Depending on the project choosen, loading of the criteria rasters
    observe({
      if (length(input$Project) ==0){
        # By default, if the user doesn't click on the project tab, Project = Forest
        launchingProject(1, Pr)
        x1 <<- c(x1p,x1n)
        x1bis <<- factor(x1)
        initialisation <<- TRUE
      }
      else if (initialisation==TRUE){ 
        # To avoid the reloading of the data when the user clicks on the project tab for the first time
        initialisation <<- FALSE
      }
      else {
        # Uploading data and using the ones existing is different 
        if(input$Project!="3"){
          # Then
          launchingProject(input$Project, Pr)
          x1 <<- c(x1p,x1n)
          x1bis <<- factor(x1)
          #update hc if necessary
          if (input$Project=="2"){
            hc <<-raster(readGDAL("../data/CL_cscapeQ_r01.tif"))
          }
          #Reset the Compare Methods checkbox
          updateCheckboxGroupInput(session=session, 
                                   inputId="checkGroupCM",
                                   choices = list("LWC2" = 2, "Electre" = 3), 
                                   selected=NULL)
        }
      }
    })
    
    # Observe event to toggle the button "Ok" of the tab Select the project because
    # It has nothing to do there if you don't chose "My data"
    observeEvent(input$Project,{
      
      if (input$Project == 1){
        shinyjs::show(id="InformationForest")
        
        hide(id= "InformationAgriculture")
        
        hide(id="file")
        hide(id="uploaded")
        hide(id="instructionselectdata")
        hide(id="InformationOwnData")
        hide(id="BewareOwnData")
      }
      
      if (input$Project == 2){
        hide(id= "InformationForest")
        
        shinyjs::show(id="InformationAgriculture")
        
        hide(id="file")
        hide(id="uploaded")
        hide(id="instructionselectdata")
        hide(id="InformationOwnData")
        hide(id="BewareOwnData")
      }
      
      
      if (input$Project == 3){
        hide(id="InformationForest")
        
        hide(id= "InformationAgriculture")
        
        shinyjs::show(id="file")
        shinyjs::show(id="uploaded")
        shinyjs::show(id="instructionselectdata")
        shinyjs::show(id="InformationOwnData")
        shinyjs::show(id="BewareOwnData")
      }
    })
    
    xdist <- 0
    ydist <- 0
    xcenter <- 0
    ycenter <- 0
    reactX <- -1
    mamapAvailable <- NA
    
    #Event button Download Example
    output$downloadData <- downloadHandler(
      filename = 'Example.zip',
      content = function(f.out.name) {
        cat(f.out.name,"\n")
        zip(zipfile = f.out.name ,files = 'Example')
      },
      contentType = "application/zip"
    )
    
    # Event button ok 
    observeEvent(input$uploaded,{
      if (input$Project=="3"){
        if (length(input$file) !=0){
          # Name of the folder
          nameuploaded <- unlist(strsplit(input$file$name,"\\."))[1]
          # Name diffrent from the others
          if (nameuploaded!= "Forest" && nameuploaded!="Agriculture" ){
            # Erase a file if they have the same name
            if (file.exists(file.path(getwd(),nameuploaded))){
              #file.remove(file.path(getwd(),nameuploaded))
              unlink(file.path(getwd(),nameuploaded), recursive = TRUE)
              file.remove(file.path(getwd(),"0"))
              unlink(file.path(getwd(),"0"), recursive = TRUE)
            }
            # Copy and unzip the data
            p <- input$file$datapath
            file.copy(p, getwd(), overwrite = TRUE)
            unzip(file.path(getwd(),"0"), exdir = ".")
            file.copy(file.path(getwd(),nameuploaded),"../data", overwrite=TRUE, recursive = TRUE)
            # Read the index file and put in the project table
            if (file.exists(file.path(file.path("../data", nameuploaded), "index.txt"))){
              LU <<- scan(file.path(file.path("../data", nameuploaded), "index.txt"), what="factor")
              u <- c(length(Pr[,1])+1, LU)
                
              # update levels
              levels(Pr[,2]) <- c(levels(Pr[,2]), u[2]) 
              levels(Pr[,3]) <- c(levels(Pr[,3]), u[3]) 
              levels(Pr[,4]) <- c(levels(Pr[,4]), u[4]) 
              levels(Pr[,5]) <- c(levels(Pr[,5]), u[5]) 
              levels(Pr[,6]) <- c(levels(Pr[,6]), u[6]) 

              Pr <- rbind(Pr, u)
              launchingProject(input$Project, Pr)
              Pr <<- Pr
              #update hc
              if (file.exists(file.path(file.path("../data", nameuploaded), "extent.tif"))){
                hc <<- raster(readGDAL(file.path(file.path("../data", nameuploaded), "extent.tif")))
              }else{
                output$erreur<- renderText({ 
                  paste("extent.tif is missing")})
              }
              #Upload the Hard Constraints
              if (file.exists(file.path(file.path("../data", nameuploaded), "Hard_Constraint.txt"))){
                HC <<-read.table(paste0(file.path(file.path("../data", nameuploaded), "Hard_Constraint.txt")), h=T)
                if(length(HC)==0){
                  use_HC<<-FALSE
                }else{
                  # print(nameuploaded)
                  rst.hcl <<- creationHardConstraintRasterUser(HC, nameuploaded)}
              }else{
                use_HC<<-FALSE
              }
              #Reset the Compare Methods checkbox
              updateCheckboxGroupInput(session=session, 
                                       inputId="checkGroupCM",
                                       choices = list("LWC2" = 2, "Electre" = 3), 
                                       selected=NULL)
              
              output$uploadok<- renderText({ 
                paste("Data uploaded")})
            }else{
             output$erreur<- renderText({ 
              paste("The file is not correct")})
            }
          }else{
            output$erreur<- renderText({ 
              paste("The name of the file is already used.")})
          }
         }else{
           output$erreur<- renderText({ 
             paste("Uploade your data")})
         }
      }else{
        output$uploadok<- renderText({ 
          paste("Please select My Data")})
      }
    })
    
    # Text below the title, indicating the project chosen
    output$typechosen<- renderText({ input$Project
      if (initialisation == TRUE){
        name <- Pr[1,2]
      } 
      else{ 
        if (input$Project=="3"){
          name <- "My Data"
        }else{
        name <- Pr[input$Project,2]}
      paste0("Project selected : ", name)} 
      
    })
   
  
    ################ Select subset of the project area ###########################################
    
    # Hide and show "polygon, rectangle and shapefile selection"
    observeEvent(input$allareaselect,{
      if (input$allareaselect == 0){
        
        hide(id= "divSubset")
      }
      
      if (input$allareaselect == 1){
        
        shinyjs::show(id= "divSubset")
        
      }
    })
    
    
    # Enable selection of a smaller area
    # Display the map with the google layer on which you can select the area you want to use 
    output$selectarealeaf <- renderLeaflet({
      
      # Transform the extent of the raster hc
      hcext <- extent(hc)
      hcp <- as(hcext,'SpatialPolygons')
      crs(hcp) <- crs(hc)
      hc4 <- spTransform(hcp,CRSobj = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
      
      leaflet()%>%
        addGoogleTiles(layerId = "googleTileSat",
                       options = tileOptions(maxZoom = 15,
                                             updateWhenZooming = TRUE),
                       type = "satellite",
                       group = "Satellite (default)") %>%
        addGoogleTiles(layerId = "googleTileRoad",
                       options = tileOptions(maxZoom = 15,
                                             updateWhenZooming = TRUE),
                       type = "roadmap",
                       group = "Roadmap") %>%
        addGoogleTiles(layerId = "googleTileTer",
                       options = tileOptions(maxZoom = 15,
                                             updateWhenZooming = TRUE),
                       type = "terrain",
                       group = "Terrain") %>%
        
        #################
        setView(lng = -4.10889,
                lat = 56.9176,
                zoom = 5) %>%
        addLayersControl(
          baseGroups = c("Satellite (default)", "Roadmap", "Terrain"),
          options = layersControlOptions(collapsed = FALSE)) %>%
        addRectangles(lng1 = hc4@bbox[1,1],
                      lat1 = hc4@bbox[2,1],
                      lng2 = hc4@bbox[1,2],
                      lat2 = hc4@bbox[2,2],color = "blue",fill = FALSE)
        #################
    })
    
    cptclickselectarealeaf <<- 0 
    ## Replace the ancient selection by the new one using the tool of maxime
    observeEvent(input$selectarealeaf_click, {
      if(is.null(input$selectarealeaf_click))
        return()
      
      # What to do if it's the free selection
      if(input$inputselect =="0"){
        sessionVars$area_cur$LAT <- c(sessionVars$area_cur$LAT, input$selectarealeaf_click$lat)
        sessionVars$area_cur$LNG <- c(sessionVars$area_cur$LNG, input$selectarealeaf_click$lng)
        leafletProxy("selectarealeaf") %>%
          removeShape(layerId = "areaselected") %>%
          addPolygons(lng = sessionVars$area_cur$LNG,
                      lat = sessionVars$area_cur$LAT,
                      layerId = "areaselected",
                      color = "#F03", fillColor = "#03F")
        bound <<- polygonBoundaries(sessionVars$area_cur)
      }
      
      # What to do if it's the rectangle selection
      if(input$inputselect =="2"){
        # cptclickselectarealeaf <<- 0 
        if(cptclickselectarealeaf ==2)
          return()
        else if(cptclickselectarealeaf ==0){
          sessionVars$area_cur$LAT <- c(sessionVars$area_cur$LAT, input$selectarealeaf_click$lat)
          sessionVars$area_cur$LNG <- c(sessionVars$area_cur$LNG, input$selectarealeaf_click$lng)
          cptclickselectarealeaf <<- cptclickselectarealeaf+1
          leafletProxy("selectarealeaf") %>%
            removeShape(layerId = "areaselected") %>%
            addPolygons(lng = sessionVars$area_cur$LNG,
                        lat = sessionVars$area_cur$LAT,
                        layerId = "areaselected",
                        color = "#F03", fillColor = "#03F")
        }
        else{
          sessionVars$area_cur$LAT <- c(sessionVars$area_cur$LAT, input$selectarealeaf_click$lat)
          sessionVars$area_cur$LNG <- c(sessionVars$area_cur$LNG, input$selectarealeaf_click$lng)
          cptclickselectarealeaf <<- cptclickselectarealeaf+1
          leafletProxy("selectarealeaf") %>%
            removeShape(layerId = "areaselected") %>%
            addRectangles(lng1 = sessionVars$area_cur$LNG[1],
                          lat1 = sessionVars$area_cur$LAT[1],
                          lng2 = sessionVars$area_cur$LNG[2],
                          lat2 = sessionVars$area_cur$LAT[2],
                          layerId = "areaselected",
                          color = "#F03", fillColor = "#03F")
          # print(sessionVars$area_cur$LNG[1])
          # print(sessionVars$area_cur$LAT[1])
          # print(sessionVars$area_cur$LNG[2])
          # print(sessionVars$area_cur$LAT[2])
        }
      }
    })
    
    # Function to Undo the last action you haved performed on the map ( click to add a point )
    observeEvent(input$undoarea,{
      # We must change the undo for the different selection
      # So this selection is the free selection
      if(input$inputselect =="0"){
        if(length(sessionVars$area_cur$LAT) > 0){
          sessionVars$area_cur$LAT <- sessionVars$area_cur$LAT[1:length(sessionVars$area_cur$LAT)-1]
          sessionVars$area_cur$LNG <- sessionVars$area_cur$LNG[1:length(sessionVars$area_cur$LNG)-1]
          leafletProxy("selectarealeaf") %>%
            removeShape(layerId = "areaselected") %>%
            addPolygons(lng = sessionVars$area_cur$LNG,
                        lat = sessionVars$area_cur$LAT,
                        layerId = "areaselected",
                        color = "#F03", fillColor = "#03F")
        }
      }
      # And this selection is the rectangle selection
      # We need to be careful about the click cpt
      if(input$inputselect =="2"){
        if(cptclickselectarealeaf ==0)
          return()
        else {
          if(length(sessionVars$area_cur$LAT) > 0){
            sessionVars$area_cur$LAT <- sessionVars$area_cur$LAT[1:length(sessionVars$area_cur$LAT)-1]
            sessionVars$area_cur$LNG <- sessionVars$area_cur$LNG[1:length(sessionVars$area_cur$LNG)-1]
            cptclickselectarealeaf <<- cptclickselectarealeaf-1
            leafletProxy("selectarealeaf") %>%
              removeShape(layerId = "areaselected") %>%
              addPolygons(lng = sessionVars$area_cur$LNG,
                          lat = sessionVars$area_cur$LAT,
                          layerId = "areaselected",
                          color = "#F03", fillColor = "#03F")
          }
        }
      }
    })
    
    # Function to Remove the entire polygon you have created to select the area 
    observeEvent(input$cleararealeaf,{
      # We must change the clear for the different selection
      # Just because of the cpt click
      # So this selection is the free selection
      if(input$inputselect =="0"){
        sessionVars$area_cur <- NULL
        leafletProxy("selectarealeaf") %>%
          removeShape(layerId = "areaselected")
      }
      if(input$inputselect =="2"){
        sessionVars$area_cur <- NULL
        cptclickselectarealeaf <<- 0
        leafletProxy("selectarealeaf") %>%
          removeShape(layerId = "areaselected")
      }
    })
    
    # Use with a shapefile
    observeEvent(input$sarea, {
      if(input$inputselect == "1"){
        output$renderShapefile<- renderPlot({
          # Uploade the .zip, unzip it and read it
          file.copy(input$sarea$datapath, getwd(), overwrite = TRUE)
          unzip(file.path(getwd(),"0"), exdir = "./Shapefile")
          dsa <- unlist(strsplit(input$sarea$name,"\\."))[1]
          nsa <- unlist(strsplit(dir(path=file.path("./Shapefile", dsa))[1],"\\."))[1]
          ogrInfo(path.expand(file.path("./Shapefile", dsa)), nsa)
          sa <<- readOGR(dsn=path.expand(file.path("./Shapefile", dsa)), 
                         layer=nsa)
          plot(sa)
        })
      }
      else{
        output$error <- renderPrint({
          error<- "Press Selection with a Shapefile first"
          cat(error)
        })
      }
    })
    
    # Select button to go to the next step
    
    observeEvent(input$selecta, {
      error <-""
      
      # Select the entire area
      if(input$allareaselect ==0){
        # Transform the extent of the raster hc
        hcext <- extent(hc)
        hcp <- as(hcext,'SpatialPolygons')
        crs(hcp) <- crs(hc)
        hc4 <- spTransform(hcp,CRSobj = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")

        # Use the same pattern as the other one :)
        areaOSGB36 <<-extent(hc)
        areaselected <<- hc
        rst.pnl <<-  mask(rst.pnl.original, areaselected)
        rst.nl <<-  mask(rst.nl.original, areaselected)
        rst.pl <<- mask(rst.pl.original, areaselected)

        # Extent of the all area
        lng1 <-  hc4@bbox[1,1]
        lat1 <-  hc4@bbox[2,1]
        lng2 <-  hc4@bbox[1,2]
        lat2 <-  hc4@bbox[2,2]
        xcenter <<- (lng1+lng2)/2
        ycenter <<- (lat1+lat2)/2
        xdist <<- lng2-lng1
        ydist <<- lat2-lat1
        print(xdist)
        zoomin <- leafletGoogle::setZoomBound(xdist = xdist, ydist = ydist)
        
        # Show with the 'Next Step' button
        shinyjs::show(id="pann4")
        leafletProxy("selectarealeaf") %>%
          setView(lng = xcenter,
                  lat = ycenter,
                  zoom = zoomin[1])}
      else {
        # print(inputselect)
        # If the area is directly selected from the map by choosing which polygon to use
        if (input$inputselect=="0"){
          if(!is.null(sessionVars$area_cur)){
            
            # Create the SpatialPolygonDataFrame 
            polly <- Polygon(coords = list(sessionVars$area_cur$LNG,sessionVars$area_cur$LAT))
            polly2 <- Polygons(list(polly),ID=1)
            polly3 <- SpatialPolygons(list(polly2), proj4string = CRS(projargs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs "))
            polly4 <- spTransform(polly3, crs(hc))
            vect <- polly4@bbox
            # This is  the condition for the polygon to fit into the raster
            if(vect[1,1] > hc@extent@xmin & vect[2,2] < hc@extent@ymax
               & vect[2,1] > hc@extent@ymin & vect[1,2] < hc@extent@xmax){
              areaOSGB36 <<-extent(polly4)
              areaselected <<- polly4
              if ((rst.pnl@extent == areaOSGB36)==FALSE){
                rst.pnl <<-  mask(rst.pnl.original, areaselected,updatevalue=NA)
                rst.nl <<-  mask(rst.nl.original, areaselected,updatevalue=NA)
                rst.pl <<- mask(rst.pl.original, areaselected,updatevalue=NA)}
              else{
                error <- "(rst.pnl@extent == areaOSGB36)==FALSE"}
              # Show with the 'Next Step' button
              shinyjs::show(id="pann4")
              # These are the variables that needs to be changed
              vect <- polygonBoundaries(sessionVars$area_cur)
              xcenter <<- vect[5]
              ycenter <<- vect[6]
              xdist <<- vect[3]-vect[1]
              ydist <<- vect[4]-vect[2]
              zoomin <- leafletGoogle::setZoomBound(xdist = xdist, ydist = ydist)
              leafletProxy("selectarealeaf") %>%
                setView(lng = xcenter,
                        lat = ycenter,
                        zoom = zoomin[1])}
            else{
              error <-"The polygon needs to fit into the raster area"
              print("The polygon needs to fit into the raster area")
            }
          }
          else{
            error <-"Please select an area with at least a point"}
        }
        
        # Use with a shapefile ## inputselect=="1" ##
        else if(input$inputselect=="1"){
          areaOSGB36 <-extent(sa)
          ## Condition and error for the cut
          # The area selected needs to match the rasters, a text warns the user
          if (areaOSGB36@xmax > hc@extent@xmin & areaOSGB36@ymin < hc@extent@ymax
              & areaOSGB36@ymax > hc@extent@ymin & areaOSGB36@xmin < hc@extent@xmax){
            areaselected <<- sa
            rastersaved <<- stack()
            num <<- 0
            error <-"If you re-select an area after doing some analysis without downloading rasters, all the results will be lost."
            if ((rst.pnl@extent == areaOSGB36)==FALSE){
              rst.pnl <<-  cuttingAreaSelected(rst.pnl.original, areaselected)
              rst.nl <<-  cuttingAreaSelected(rst.nl.original, areaselected)
              rst.pl <<- cuttingAreaSelected(rst.pl.original, areaselected)
              # Show with the 'Next Step' button
              shinyjs::show(id="pann4")
            }
          }
          #If the area selected doesn't match the rasters, a text warns the user
          else {
            error <- "No data for this area, please select an other one"
          }
        }
        
        # Use a rectangle "Selection with a rectangle"
        else if (input$inputselect=="2"){
          #Selection of a smaller area by drawing a rectangle on the map
          if(!is.null(sessionVars$area_cur)){
            if(cptclickselectarealeaf ==2){
              # We need the two other points that hasn't been clicked on
              x1 <- sessionVars$area_cur$LNG[1]
              x2 <- sessionVars$area_cur$LNG[2]
              y1 <- sessionVars$area_cur$LAT[1]
              y2 <- sessionVars$area_cur$LAT[2]
              mat <- matrix(ncol = 2, nrow = 4, data = c(x1,x2,x2,x1,y1,y1,y2,y2))
              
              # Create the SpatialPolygonDataFrame 
              polly <- Polygon(coords = mat)
              polly2 <- Polygons(list(polly),ID=1)
              polly3 <- SpatialPolygons(list(polly2), proj4string = CRS(projargs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs "))
              polly4 <- spTransform(polly3, crs(hc))
              vect <- polly4@bbox
              
              ## Condition and error for the cut
              if (vect[1,1] > hc@extent@xmin & vect[2,2] < hc@extent@ymax
                  & vect[2,1] > hc@extent@ymin & vect[1,2] < hc@extent@xmax){
                
                areaOSGB36 <<-extent(polly4)
                areaselected <<- polly4
                
                if ((rst.pnl@extent == areaOSGB36)==FALSE){
                  rst.pnl <<-  mask(rst.pnl.original, areaselected,updatevalue=NA)
                  rst.nl <<-  mask(rst.nl.original, areaselected,updatevalue=NA)
                  rst.pl <<- mask(rst.pl.original, areaselected,updatevalue=NA)}
                else{
                  error <- "(rst.pnl@extent == areaOSGB36)==FALSE"}
                
                # These are the variables that needs to be changed
                vect <- polygonBoundaries(sessionVars$area_cur)
                xcenter <<- vect[5]
                ycenter <<- vect[6]
                xdist <<- vect[3]-vect[1]
                ydist <<- vect[4]-vect[2]
                # Show with the 'Next Step' button
                shinyjs::show(id="pann4")

                zoomin <- leafletGoogle::setZoomBound(xdist = xdist, ydist = ydist)
                leafletProxy("selectarealeaf") %>%
                  setView(lng = xcenter,
                          lat = ycenter,
                          zoom = zoomin[1])}
              else {
                #If the area selected doesn't match the rasters, a text warns the user
                error <- "No data for this area, please select an other one"
              }
            }
            else{
              error <- "You need to select a rectangle by clicking on two points"
            }
          }
        } 
        output$error <- renderPrint({
          cat(error)
        })
      }
    })
    
    
    # Observe event to toggle the file input to show it only if you select the "Shapefile"
    # Option in the selection of the area
    observeEvent(input$inputselect,{
      if(input$inputselect != 1){
        hide(id="sarea")
        hide(id="sareazip")
        hide(id="sareaupload")
      }
      else{
        shinyjs::show(id="sarea")
        shinyjs::show(id="sareazip")
        shinyjs::show(id="sareaupload")
      }
    })
    
    ################ Select Hard Constraints ###########################################
    # Display the matrix which contains the hard constraints description
    output$matrixHC <- renderTable({
      validate( need(use_HC==TRUE , "No Hard Constraint Data"))
      
      #Transform the row data in understandable text
      descript <-sapply(HC[,4], toString)
      descript <- gsub("_", " ", descript)
      
      #Get back names of hard constraints
      tname <-sapply(HC[,3], toString)

      matrix <- matrix(descript, nrow=length(HC[,1]))
      dimnames(matrix)=list(tname,c("Description"))
      matrix
    })
    
    
    #Display the select input of hard constraint that the user wants to display on the map
    output$renderSelectHC <-renderUI({
      validate( need(use_HC==TRUE , ""))
      descript <-sapply(HC[,4], toString)
      descript <- gsub("_", " ", descript)
      choices <- list()
      for(i in 1:length(HC)){
        choices[i] <- toString(HC[i,3])
      }
      names(choices) <- descript
      selectInput(inputId = "hardconstraint", 
                  label = "Choose a hard constraint to display:",
                  choices = choices,
                  selected = 1
                  )
    })
    
    
    # Display the HC map
    output$mapShowHC <- renderLeaflet({
      input$hardconstraint 
      # print(input$hardconstraint)
      if(is.null(input$hardconstraint)){
        delay(100,{})
      }
      if (!is.null(input$hardconstraint)){
        #The layer displayed is the one selected by the user in input hardconstraint
        layerdisplayed <- subset(rst.hcl,input$hardconstraint)
        ## This is the raster which is displayed on the map!!!!!
        layerd <- mask(layerdisplayed, areaselected)
        # Boundaries of the rasters
        # vect <<- polygonBoundaries(sessionVars$area_cur)
        # xcenter <- vect[5]
        # ycenter <- vect[6]
        # print("xcenter and ycenter")
        # print(xcenter)
        # print(ycenter)
        
        zoomin <- leafletGoogle::setZoomBound(xdist = xdist, ydist = ydist)
        # print("zoomin1")
        # print(zoomin[1])
        colorszz <- c("grey", "green")
        # print("JE NE VEUX PAS TRAVAILLER")
        leaflet()%>%
          addGoogleTiles(layerId = "googleTileSat",
                         options = tileOptions(maxZoom = 15,
                                               updateWhenZooming = TRUE),
                         type = "satellite") %>%
          setView(lng = xcenter,
                  lat = ycenter,
                  zoom = zoomin[1]) %>%
          addLegend(position = "bottomright",colors = colorszz,labels =c("rest", "best"))
      }
    })
    
    
    # Observer to redraw the raster
    observe({
      input$mapShowHC_zoom
      input$mapOpacityhc
      input$hardconstraint
      input$mapHCSelect
      # print("ydist")
      # print(ydist)
      # The console will trigger an error if the leaflet object called
      # Is not defined and this is sometimes the case as the map take less time to initalize then
      # the input hardconstraint, that's why we need to delay the execution
      # of the code for the first time you enter into the tab
      if(is.null(input$hardconstraint)){
        delay(200,{})
      }
      isolate({
        # print("ydist")
        # print(ydist)
        zoomin <- leafletGoogle::setZoomBound(xdist = xdist, ydist = ydist)
        # print("zoomin1")
        # print(zoomin[1])
        if(length(input$hardconstraint) != 0 ){
          if(input$mapShowHC_zoom == zoomin[1] || input$mapShowHC_zoom == zoomin[2] || input$mapShowHC_zoom == zoomin[3] || input$mapShowHC_zoom == zoomin[4] || input$mapShowHC_zoom == zoomin[5] || length(input$hardconstraint) != 0 || input$mapOpacityhc){
            #The layer displayed is the one selected by the user in input hardconstraint
            layerdisplayed <- subset(rst.hcl,input$hardconstraint)
            ## This is the raster which is displayed on the map!!!!!
            layerd <- mask(layerdisplayed, areaselected)

            # Redraw the map now
            if(input$mapHCSelect == 0){
              leafletProxy("mapShowHC") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileSat",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "satellite") %>%
                clearImages() %>%
                # colorQuantile(c("#ff0000","#0000ff"), domain = NULL,n=2,na.color=NA)
                # addRasterImage(x = layerd,colors = colorQuantile(c("grey", "green"), domain = NULL,n=2,na.color=NA),opacity = (input$mapOpacityhc)/100)            }
                addRasterImage(x = layerd,colors = c("grey", "green"),opacity = (input$mapOpacityhc)/100)            }
          else if (input$mapHCSelect == 1){
              leafletProxy("mapShowHC") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileRoad",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "roadmap") %>%
                clearImages() %>%
                # addRasterImage(x = layerd,colors = colorQuantile(c("grey", "green"), domain = NULL,n=2,na.color=NA),opacity = (input$mapOpacityhc)/100)            }
                addRasterImage(x = layerd,colors = c("grey", "green"),opacity = (input$mapOpacityhc)/100)            }
            else{
              leafletProxy("mapShowHC") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileTer",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "terrain") %>%
                clearImages() %>%
                addRasterImage(x = layerd,colors = c("grey", "green"),opacity = (input$mapOpacityhc)/100)            }
                # addRasterImage(x = layerd,colors = colorQuantile(c("grey", "green"), domain = NULL,n=2,na.color=NA),opacity = (input$mapOpacityhc)/100)            }
          }
        }
      })
    })
    
    
    # Event to toggle the legend
    observeEvent(input$mapshowhcS,{
      proxy <- leafletProxy("mapShowHC")
      colorszz <- c("grey", "green")
      # Remove any existing legend, and only if the legend is
      # enabled, create a new one.
      if (input$mapshowhcS) {
        proxy %>% addLegend(position = "bottomright",colors = colorszz,labels =c("rest", "best"))
      }
      else{
        proxy %>% clearControls()
      }
    })
    
    
    # List the hard constraints 
    output$renderChoiceHC <-renderUI({
      validate( need(use_HC==TRUE , ""))
      # Read the names of the hard constraints in the HC database and create a list
      # List of names
      HCnames <- sapply(HC[,3], toString)
      HCdesc <- sapply(HC[,4], toString)
      HCdesc <- gsub("_", " ", HCdesc)
      mylist <- vector(mode="list", length=length(HCnames))
      names(mylist) <- HCnames
      mylist=lapply(1:length(HCnames), function(i){
        mylist[[i]] <- names(mylist)[i]
      })
      names(mylist) <- HCdesc
      #Create the checkbox to choose hardconstraints
      checkboxGroupInput("checkGroupHC", "Choose the hard constraints :", 
                         choices=mylist, selected= mylist[1])
    })
    
    
    # Compilation of the hard constraints raster in one final HC raster
    compilHC <- reactive({input$HCbutton
      # case of one contraint selected
      if(length(input$checkGroupHC)>0){
        hc_final <<-subset(rst.hcl, input$checkGroupHC[1])
        # case of two contraints selected
        if (length(input$checkGroupHC)==2){
              layer1 <- subset(rst.hcl, input$checkGroupHC[1])
              layer2 <- subset(rst.hcl, input$checkGroupHC[2])
              # If more than 1, they are merged
              hc_final <-overlay(layer1,layer2, fun=function(x,y){ifelse((x+y)==0,0,1)})
        }
        # case of three contraints selected
        if(length(input$checkGroupHC)==3){
          layer1 <- subset(rst.hcl, input$checkGroupHC[1])
          layer2 <- subset(rst.hcl, input$checkGroupHC[2])
          layer3 <- subset(rst.hcl, input$checkGroupHC[3])
          # If more than 1, they are merged
          hc_final <-overlay(layer1,layer2,layer3, fun=function(x,y,z){ifelse(x+y+z==0,0,1)})
        }
        # case of four contraints selected
        if(length(input$checkGroupHC)==4){
          layer1 <- subset(rst.hcl, input$checkGroupHC[1])
          layer2 <- subset(rst.hcl, input$checkGroupHC[2])
          layer3 <- subset(rst.hcl, input$checkGroupHC[3])
          layer4 <- subset(rst.hcl, input$checkGroupHC[4])
          # If more than 1, they are merged
          hc_final <-overlay(layer1,layer2,layer3,layer4, fun=function(x,y,z,k){ifelse(x+y+z+k==0,0,1)})
        }
        # case of more then four constraints selected
        if(length(input$checkGroupHC)>4){
          output$mapFinalHC <- renderPrint({
            cat(paste0("Please choose four hard constraints maximum."))
          }) 
        }
      }     # If 0 HC selected the final raster pixels values get 0
      else{
        hc_final <- rst.hcl[[1]]
        hc_final[hc_final]=0
      }
      return(hc_final)
    })
    
    
    #Add the hard constraint chosen to the criteria rasters
    observeEvent(input$HCbutton, {
      HCraster <- compilHC()
      nl <- addHC(rst.nl.original, HCraster)
      pl <- addHC(rst.pl.original, HCraster)
      pnl <- addHC(rst.pnl.original, HCraster)
      rst.pnl <<- mask(pnl, areaselected)
      rst.nl <<- mask(nl, areaselected)
      rst.pl <<- mask(pl, areaselected) 
      
      shinyjs::show(selector = "#navbar li a[data-value=tab5]")
      updateTabsetPanel(session, 
                        inputId = "navbar", 
                        selected = "tab5")
      
    })
    
    
    ################ Select Criteria ###########################################
    
    # Display the matrix which contains the criteria description
    output$matrixPN <- renderTable({input$Project 
         #Transform the row data in understandable text
         dp <-sapply(HP[,4], toString)
         dn <-sapply(HN[,4], toString)
        
         dp <- gsub("_", " ", dp)
         dn <- gsub("_", " ", dn)
         
         #Get back names of criteria
         tp <-sapply(HP[,3], toString)
         tn <-sapply(HN[,3], toString)
         N <- c(dp,dn) 
         
         matrix <- matrix(N, nrow=length(HP[,1])+length(HN[,1]))
         dimnames(matrix)=list(c(tp,tn),c("Description"))
         matrix
    })
   
    
    #Display the select input of criteria that the user wants to display on the map
    output$renderSelectCriteria <-renderUI({input$Project
      descript <-sapply(HPN[,4], toString)
      descript <- gsub("_", " ", descript)
      choices <- list()
      for(i in 1:length(HPN[,3])){
        choices[i] <- toString(HPN[i,3])
      }
      names(choices) <- descript
      selectInput("criteria", "Choose a criteria to display:", 
                  # choices=rownames(HPN)
                  choices = choices)
    })
    
    
    # Display the criteria map
    output$mapShowCriteria <- renderLeaflet({
      input$criteria
      input$HCbutton
      if(is.null(input$criteria)){
        delay(100,{})
      }
      if (!is.null(input$criteria)){
        #The layer displayed is the one selected by the user in input criteria
        layerdisplayed<- subset(rst.pnl,input$criteria)
        ## This is the raster which is displayed on the map!!!!!
        layerd <- mask(layerdisplayed, areaselected)
        
        colorszz <- c("#ff0000","#0000ff")
        zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
        
        leaflet()%>%
          addGoogleTiles(layerId = "googleTileSat",
                         options = tileOptions(maxZoom = 15,
                                               updateWhenZooming = TRUE),
                         type = "satellite") %>%
          setView(lng = xcenter,
                  lat = ycenter,
                  zoom = zoomin[1]) %>%
          addLegend(position = "bottomright",colors = colorszz,labels =c("rest", "best"))
      }
    })
    
    
    # Observer to redraw the raster
    observe({ 
      input$mapShowCriteria_zoom
      input$mapOpacitycrit
      input$criteria
      input$mapCritSelect
      # The console will trigger an error if the leaflet object called
      # Is not defined and this is sometimes the case as the map take less time to initalize then
      # the input hardconstraint, that's why we need to delay the execution
      # of the code for the first time you enter into the tab
      if(is.null(input$hardconstraint)){
        delay(200,{})
      }
      
      isolate({
        # print("ydist")
        # print(ydist)
        zoomin <- leafletGoogle::setZoomBound(xdist = xdist, ydist = ydist)
        # print("zoomin1")
        # print(zoomin[1])
        if(length(input$criteria) != 0 ){
          if(input$mapShowCriteria_zoom == zoomin[1] || input$mapShowCriteria_zoom == zoomin[2] || input$mapShowCriteria_zoom == zoomin[3] || input$mapShowCriteria_zoom == zoomin[4] || input$mapShowCriteria_zoom == zoomin[5] || length(input$criteria) != 0 || input$mapOpacitycrit){
            #The layer displayed is the one selected by the user in input criteria
            layerdisplayed<- subset(rst.pnl,input$criteria)
            ## This is the raster which is displayed on the map!!!!!
            layerd <- mask(layerdisplayed, areaselected)
            # Redraw the map now
            if(input$mapCritSelect == 0){
              leafletProxy("mapShowCriteria") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileSat",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "satellite") %>%
                clearImages() %>%
                addRasterImage(x = layerd,colors = c("#ff0000","#0000ff"),opacity = (input$mapOpacitycrit)/100)            }
            else if (input$mapCritSelect == 1){
              leafletProxy("mapShowCriteria") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileRoad",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "roadmap") %>%
                clearImages() %>%
                addRasterImage(x = layerd,colors = c("#ff0000","#0000ff"),opacity = (input$mapOpacitycrit)/100)            }
            else{
              leafletProxy("mapShowCriteria") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileTer",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "terrain") %>%
                clearImages() %>%
                addRasterImage(x = layerd,colors = c("#ff0000","#0000ff"),opacity = (input$mapOpacitycrit)/100)            }
            
          }
        }
      })
    })
    
    
    # Event to toggle the legend
    observeEvent(input$mapshowcrit,{
      proxy <- leafletProxy("mapShowCriteria")
      colorszz <- c("#ff0000","#0000ff")
      # Remove any existing legend, and only if the legend is
      # enabled, create a new one.
      if (input$mapshowcrit) {
        proxy %>% addLegend(position = "bottomright",colors = colorszz,labels =c("rest", "best"))
      }
      else{
        proxy %>% clearControls()
      }
    })
    
    # ==>
    # validate(need(!is.na(HPN),""))
    HPNnames <- sapply(HPN[,3], toString)
    HPNdesc <- sapply(HPN[,4], toString)
    HPNdesc <- gsub("_", " ", HPNdesc)
    mylist <- vector(mode="list", length=length(HPNnames))
    names(mylist) <- HPNnames
    mylist=lapply(1:length(HPNnames), function(i){
      mylist[[i]] <- names(mylist)[i]
    })
    names(mylist) <- HPNdesc
    
    # x1 <- c(x1p,x1n)
    # x1bis <- factor(x1)
    
    #Chooser for positive AND negative criteria
    output$chooserpdisplayed <-renderUI({input$Project 
      
      chooserInput("mychooserp", 
                   "available", 
                   "selected",
                   
                   leftChoices = HPN$Description[2:length(HPN$Number)],
                   rightChoices = HPN$Description[1],
                   
                   # leftChoices = names(mylist[2:length(mylist)]),
                   # rightChoices = names(mylist[1]),
                   # checkboxGroupInput("checkGroupHC", "Choose the hard constraints :", 
                   #                    choices=mylist, selected= 1)
                   
                   
                   # c(x1[2:length(x1)]),
                   # c(x1[1]),
                   size = length(x1), 
                   multiple = TRUE)
    })
    # output$chooserndisplayed <-renderUI({input$Project 
    #   chooserInput("mychoosern", 
    #                "available", 
    #                "selected",
    #                c(x1n[2:length(x1n)]), 
    #                c(x1n[1]), 
    #                size = length(x1n), 
    #                multiple = TRUE)
    # })
  
    
    ################ Select weights advanced ###########################################
    
    # Define input sliders as the selected criteria of the chooser input for any criteria advanced. 
    output$slidersp <- renderUI({
      input$Project
      print("x1")
      print(x1)
      print("x1bis")
      print(x1bis)
      if(length(input$mychooserp)>=1){
        print("input$mychooserp")
        print(input$mychooserp)
        lapply(input$mychooserp, function(i) {
          tmp <- HPN[HPN$Description == i,]$Nickname
          tmpdes <- HPN[HPN$Description == i,]$Description
          descript <- gsub("_", " ", tmpdes)
          # sliderInput(inputId = paste0("sliderp",which(x1bis==input$mychooserp[i])), label = input$mychooserp[i],min=0, max=1, value=0,ticks=F)
          sliderInput(inputId = paste0("sliderp",which(x1bis==tmp)), label = descript, min=0, max=1, value=0,ticks=F)
        }
        )                              
      }
    })
    
    ###
    # Reactive value for goButton and goButtona 
    # to make the difference between adv and basic user
    observeEvent(input$goButton,{
      reactX <<- 0
    })
    observeEvent(input$goButtona,{
      reactX <<- 1
    })
    
    
    
    # Define input data as the values of each criteria weight (sliders)
    # Updated when goButton is pressed
    weightsVector <- reactive({
      nbrOfProject <- input$pann3
      input$goButton
      input$goButtona
      
      isolate({      
        #creation of the vector weight
        y<-c()
        # Loop filling vector weight with positive and negative weights. 
        # Check if each criteria is selected to plot the sliders. 
        # If not remove the slider variable if it existed previously 
        # tmp <- sapply(input$mychooserp, function(i){ HPN[HPN$Description == i,]$Nickname })
        # print("tmp")
        # print(tmp)
        m=unlist(lapply(1:length(x1) ,function(i){
          if(!(HPN[HPN$Nickname == toString(x1[i]),]$Description %in% input$mychooserp)){
            #rm(list=input[[paste0("sliderp", i)]])
            y <-c(y,NA)
            print(i)
            print(y)
          }
          else{
            if (reactX == 0){
              y <-c(y,input[[paste0("sliderp", i)]])
              print(i)
              print(y)
            }
            else{
              y <-c(y,input[[paste0("sliderpa", i)]])
              print(i)
              print(y)
            }
          }
        }))
        y<-c(m)
        ar <- array(NA, dim=(length(x1)-length(input$mychooserp)+1))
        if(identical(y, c(ar))){
          y<-c(array(NA, (length(x1))))
        }
        return(y)
      })
    })
    
    #Waiting for press save button. Save weight combinations in the file created previously for the chosen method
    observe({
      if (input$saveButton == 0){return()}
      isolate({
        y <- weightsVector() 
        if(input$methodsmain==2){    
          write(y, file = toString(Path["LWC2",2]),ncolumns = length(HP[,1])+length(HN[,1]),append=TRUE)}
        else if(input$methodsmain==3){     
          write(y, file = toString(Path["Electre",2]),ncolumns = length(HP[,1])+length(HN[,1]),append=TRUE)}
      })
    })
    
    # Update of rastersaved when save Raster button is pressed 
    observe({
      if (input$saveRasterButton == 0){return()}
      isolate({
        names(temporaryrast) <- paste0(type,"_",num)
        rastersaved <<- addLayer(rastersaved, temporaryrast)
      })
    })
    
    #Waiting for press save for real button. Save final weight combinations in the file created previously for the chosen method
    observe({
      if (input$savorButton == 0){return()}
      isolate({y <- weightsVector()  
      if(input$methodsmain==2){     
        write(y, file = toString(Path["LWC2",1]),ncolumns = length(HP[,1])+length(HN[,1]),append=TRUE)}
      else if(input$methodsmain==3){     
        write(y, file = toString(Path["Electre",1]),ncolumns = length(HP[,1])+length(HN[,1]),append=TRUE)}
      })
    })
    
    # Transform the radio input in an input variable depending of the Go button.	  
    radiomInput <- reactive({input$goButton | input$goButtonThr
      isolate({  
        m <- input$methodsmain
        return(m)						   
      })    
    })
    
    #Calculation of the unique raster with the positive and negative weights vector and the method chosen
    calculmapmain <- reactive({weightsVector() 
      isolate({ 
        radiomInput
        # if(radiomInput()==1){
        #   # Definition of the positive and negative weights vector
        #   P <- head(weightsVector(),n=length(HP[,1]))
        #   N <- tail(weightsVector(),n=length(HN[,1]))
        #   rst.comb.w=lwc(rst.nl, rst.pl,N,P)}
        if(radiomInput()==2){rst.comb.w=lwc2(rst.pnl, weightsVector())}
        if(radiomInput()==3){rst.comb.w=electre(rst.pnl, weightsVector())}
        # if(radiomInput()==4){rst.comb.w=regime(rst.pnl, weightsVector())}
        
        # Normalization of the unique raster
        rst.comb.w2=normalizer(rst.comb.w)
        
        return(rst.comb.w2) 
      })   
    })
    
    # Define main map to visualize the unique raster created with the chosen weights combination 
    output$mapMain <- renderLeaflet({
      weightsVector()
      calculmapmain()
      validate(need(!is.null(weightsVector()),""))
      validate(need(Reduce(function(acc, cur) { acc = (acc || (!is.na(cur) && (cur != 0))) }, weightsVector(), F), 
                    "Please put a positive weigth for at least one criterion or select new criteria (go back to select criteria tab)"))
      
      # Define progress message to warn the user to wait during the calculus 
      withProgress({
      setProgress(message = "Calculating, please wait",
                  detail = "This may take a few moments...")
        rst.comb.w2 <- calculmapmain()
        # The layer is cropped to match the area selected
        rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
        if(input$inputselect=="1"){
          projection(rst.comb.w2) <- projection(areaselected)
          rst.comb.w2m <- mask(rst.comb.w2, areaselected)
        }else{
          rst.comb.w2m <- rst.comb.w2
        }
        temporaryrast <<- rst.comb.w2m
        
        num <<- num+1  
        # Definition of the colour palette  of the future map
        palos  <-brewer.pal(10,"RdYlBu")  
        zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
        mamapAvailable <<- 0
        
        leaflet()%>%
          addGoogleTiles(layerId = "googleTileSat",
                         options = tileOptions(maxZoom = 15,
                                               updateWhenZooming = TRUE),
                         type = "satellite") %>%
          setView(lng = xcenter,
                  lat = ycenter,
                  zoom = zoomin[1]) %>%
          addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacitymain)/100) %>%
          addLegend(position = "bottomright",colors = palos,labels =c("0","0,10","0,20","0,30","0,40","0,50","0,60","0,70","0,80","0,90 and more"))
        
      },
      session=session)
    })
    
    
    # Update the mapmain
    observe({ 
      input$mapMain_zoom
      input$mapOpacitymain
      input$goButton
      input$mapMainSelect
      weightsVector()
      # print("mamapAvailable observe")
      # print(mamapAvailable)
      # The console will trigger an error if the leaflet object called
      # Is not defined and this is sometimes the case as the map take less time to initalize then
      # the input hardconstraint, that's why we need to delay the execution
      # of the code for the first time you enter into the tab
      validate(need(mamapAvailable ==0,""))
      
      isolate({
        palos  <-brewer.pal(10,"RdYlBu")  
        # print("ydist")
        # print(ydist)
        zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
        # print("zoomin1 map main adv")
        # print(zoomin[1])
        if(input$goButton > 0 ){
          if(input$mapMain_zoom == zoomin[1] || input$mapMain_zoom == zoomin[2] || input$mapMain_zoom == zoomin[3] || input$mapMain_zoom == zoomin[4] || input$mapMain_zoom == zoomin[5] || input$mapOpacitymain){
            
            # Redraw the map now
            if(input$mapMainSelect == 0){
              leafletProxy("mapMain") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileSat",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "satellite") %>%
                clearImages() %>%
                addRasterImage(x = temporaryrast,colors = palos,opacity = (input$mapOpacitymain)/100)
            }
            else if (input$mapMainSelect == 1){
              leafletProxy("mapMain") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileRoad",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "roadmap") %>%
                clearImages() %>%
                addRasterImage(x = temporaryrast,colors = palos,opacity = (input$mapOpacitymain)/100)
            }
            else{
              leafletProxy("mapMain") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileTer",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "terrain") %>%
                clearImages() %>%
                addRasterImage(x = temporaryrast,colors = palos,opacity = (input$mapOpacitymain)/100)
            }
          }
        }
      })
    })
    
    
    # Show the legend
    observeEvent(input$mapshowmain,{
      proxy <- leafletProxy("mapMain")
      palos  <-brewer.pal(10,"RdYlBu")  
      # Remove any existing legend, and only if the legend is
      # enabled, create a new one.
      if (input$mapshowmain) {
        proxy %>% addLegend(position = "bottomright",colors = palos,labels =c("0%","10%","20%","30%","40%","50%","60%","70%","80%","90% et plus"))
      }
      else{
        proxy %>% clearControls()
      }
    })
    
    
    # Create an histogram to display the distribution of pixels for this combination of weigths
    output$histo <- renderPlot({ 
      validate(need(!is.null(weightsVector()),""))
      validate(need(Reduce(function(acc, cur) { acc = (acc || (!is.na(cur) && (cur != 0))) }, weightsVector(), F), 
                     "Please put a positive weigth for at least one criterion or select new criteria (go back to select criteria tab)"))
      
      # Colors and data for the histogram
      palos  <-brewer.pal(10,"RdYlBu")  
      rst.comb.w2 <- calculmapmain()
      rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
      if(input$inputselect=="1"){
        projection(rst.comb.w2) <- projection(areaselected)
        rst.comb.w2m <- mask(rst.comb.w2, areaselected)
      }else{
        rst.comb.w2m <- rst.comb.w2
      }
      #Plot the histogram
      hist(na.omit(rst.comb.w2m@data@values),
           main="Distribution of Pixels Score",col = palos,
           breaks=10,
           xlab="Pixel Score")
    })
    
    # Button to download the raster created, displayed only when a map has been displayed
    output$downloadRasterbutton <- renderUI({
      validate( need(Reduce(function(acc, cur) { acc = (acc || !is.na(cur)) }, weightsVector(), F), " "))
      downloadButton('downloadRaster', 'Download Raster')
    })
    
    # Function enabling the downloading of the raster
    output$downloadRaster <- downloadHandler(
      filename = function(){return(paste0(type,"_",num,".tif"))},
      content = function(file) {writeRaster(temporaryrast, format="GTiff", file)}
    )
 
   
    ################ Select weights ###########################################
    
    # Let's move to the beginner weigth tab
    
    # Define input sliders as the selected criteria of the chooser input for any criteria basic.
    output$sliderspa <- renderUI({input$Project
      if(length(input$mychooserp)>=1){
        lapply(input$mychooserp, function(i) {
          tmp <- HPN[HPN$Description == i,]$Nickname
          tmpdes <- HPN[HPN$Description == i,]$Description
          descript <- gsub("_", " ", tmpdes)
          sliderInput(inputId = paste0("sliderpa",which(x1bis==tmp)), label = descript, min=0, max=1, value=0,ticks=F)
        })                              
      }
    })
    
    
    # Transform the radio input in an input variable depending of the Go button.
    radiomInputa <- reactive({input$goButtona | input$goButtonThr
      isolate({
        m <- input$methodsmaina
        return(m)
      })
    })
    
    #Calculation of the unique raster with the positive and negative weights vector and the method chosen
    calculmapmaina <- reactive({
      weightsVector() 
      validate(need(!is.null(weightsVector()),""))
      isolate({ 
        radiomInputa
        # if(radiomInputa()==1){
        #   # Definition of the positive and negative weights vector
        #   P <- head(weightsVector(),n=length(HP[,1]))
        #   N <- tail(weightsVector(),n=length(HN[,1]))
        #   rst.comb.w=lwc(rst.nl, rst.pl,N,P)}
        # print("rst.pnl")
        # print("weightsVector()")
        # # print(rst.pnl)
        # print("###################")
        # print(weightsVector())
        # print("###################")
        if(radiomInputa()==2){rst.comb.w=lwc2(rst.pnl, weightsVector())}
        if(radiomInputa()==3){rst.comb.w=electre(rst.pnl, weightsVector())}
        # if(radiomInputa()==4){rst.comb.w=regime(rst.pnl, weightsVector())}
        
        # Normalization of the unique raster
        rst.comb.w2=normalizer(rst.comb.w)        
        return(rst.comb.w2) 
      })   
    })
    
    # Define main map to visualize the unique raster created with the chosen weights combination
    output$mapMaina <- renderLeaflet({
      # calculmapmaina()
      # rst.comb.w2 <- calculmapmaina()
      # If all weights sliders are on 0, warns the user
      print(weightsVector())
      validate(need(!is.null(weightsVector()),""))
      validate(need(Reduce(function(acc, cur) { acc = (acc || (!is.na(cur) && (cur != 0))) }, weightsVector(), F), 
                    "Please put a positive weigth for at least one criterion or select new criteria (go back to select criteria tab)"))
      
      # Define progress message to warn the user to wait during the calculus 
      withProgress({ 
        setProgress(message = "Calculating, please wait",
                    detail = "This may take a few moments...")
        # Demander a maxime
        # Son avis sur la pertinence de doubler la ligne calculmapmaina
        rst.comb.w2 <- calculmapmaina()
        # The layer is cropped to match the area selected
        rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
        if(input$inputselect=="1"){
          projection(rst.comb.w2) <- projection(areaselected)
          rst.comb.w2m <- mask(rst.comb.w2, areaselected)
        }else{
          rst.comb.w2m <- rst.comb.w2
        }
        temporaryrast <<- rst.comb.w2m
        
        num <<- num+1  
        # Definition of the colour palette  of the future map
        palos  <-brewer.pal(10,"RdYlBu")  
        print("##################")
        print('##################')
        # print("ydist")
        # print(ydist)
        zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
        # print("zoomin1")
        # print(zoomin[1])
        mamapAvailable <<- 1
        # print("mamapAvailable")
        # print(mamapAvailable)
        
        leaflet()%>%
          addGoogleTiles(layerId = "googleTileSat",
                         options = tileOptions(maxZoom = 15,
                                               updateWhenZooming = TRUE),
                         type = "satellite") %>%
          setView(lng = xcenter,
                  lat = ycenter,
                  zoom = zoomin[1]) %>%
          addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacitymaina)/100) %>%
          addLegend(position = "bottomright",colors = palos,labels =c("0","0,10","0,20","0,30","0,40","0,50","0,60","0,70","0,80","0,90 and more"))
      },
      session=session)		 
    })
    
    
    # Update the mapmaina
    observe({ 
      input$mapMaina_zoom
      input$mapOpacitymaina
      input$goButtona
      input$mapMainaSelect
      # The console will trigger an error if the leaflet object called
      # Is not defined and this is sometimes the case as the map take less time to initalize then
      # the input hardconstraint, that's why we need to delay the execution
      # of the code for the first time you enter into the tab
      validate(need(mamapAvailable ==1,""))
      
      isolate({
        palos  <-brewer.pal(10,"RdYlBu")  
        # print("ydist")
        # print(ydist)
        zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
        # print("zoomin1")
        # print(zoomin[1])
        if(input$goButtona > 0 ){
          if(input$mapMaina_zoom == zoomin[1] || input$mapMaina_zoom == zoomin[2] || input$mapMaina_zoom == zoomin[3] || input$mapMaina_zoom == zoomin[4] || input$mapMaina_zoom == zoomin[5] || input$mapOpacitymaina){           
            
            # Redraw the map now
            if(input$mapMainaSelect == 0){
              leafletProxy("mapMaina") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileSat",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "satellite") %>%
                clearImages() %>%
                addRasterImage(x = temporaryrast,colors = palos,opacity = (input$mapOpacitymaina)/100)            }
            else if (input$mapMainaSelect == 1){
              leafletProxy("mapMaina") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileRoad",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "roadmap") %>%
                clearImages() %>%
                addRasterImage(x = temporaryrast,colors = palos,opacity = (input$mapOpacitymaina)/100)            }
            else{
              leafletProxy("mapMaina") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileTer",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "terrain") %>%
                clearImages() %>%
                addRasterImage(x = temporaryrast,colors = palos,opacity = (input$mapOpacitymaina)/100)            }
          }
          }
      })
    })
    
    
    # Show the legend
    observeEvent(input$mapshowmaina,{
      proxy <- leafletProxy("mapMaina")
      palos  <-brewer.pal(10,"RdYlBu")  
      # Remove any existing legend, and only if the legend is
      # enabled, create a new one.
      if (input$mapshowmaina) {
        proxy %>% addLegend(position = "bottomright",colors = palos,labels =c("0%","10%","20%","30%","40%","50%","60%","70%","80%","90% et plus"))
      }
      else{
        proxy %>% clearControls()
      }
    })
    
    # Create an histogram to display the distribution of pixels for this combination of weigths
    output$histoa <- renderPlot({ 
      validate( need(weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])),  "Please put a positive weigth for at least one criterion or select new criteria (go back to select criteria tab)"))
      rst.comb.w2 <- calculmapmaina()
      rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
      if(input$inputselect=="1"){
        projection(rst.comb.w2) <- projection(areaselected)
        rst.comb.w2m <- mask(rst.comb.w2, areaselected)
      }else{
        rst.comb.w2m <- rst.comb.w2
      }
      #Plot the histogram
      hist(na.omit(rst.comb.w2m@data@values),main="Distribution of Pixels Select Criteria",xlab=paste0(toString(Pr[Pr$Name==type,3])," expansion index"))
    })
    
    # Button to download the raster created, displayed only when a map has been displayed
    output$downloadRasterbuttona <- renderUI({
      validate(need(Reduce(function(acc, cur) { acc = (acc || (!is.na(cur) && (cur != 0))) }, weightsVector(), F), " "))
      downloadButton('downloadRastera', 'Download Raster')
    })
    
    # Function enabling the downloading of the raster
    output$downloadRastera <- downloadHandler(
      filename = function(){return(paste0(type,"_",num,".tif"))},
      content = function(file) {writeRaster(temporaryrast, format="GTiff", file)}
    )
  
   
    ################ Select Threshold ###########################################
    
    # Define threshold input as the value of the slider "Threshold" in the panel threshold
    t <- "0"
    # Use of an input button to update
    thrInput <- reactive({input$goButton | input$goButtonThr | input$goButtona
      isolate({      
         input$thr
         # return(y)      
      })    
    })
    
    # Use of an input button to update
    thrQInput <- reactive({input$goButton | input$goButtonThr | input$goButtona 
     isolate({      
       input$thrQ
       # return(y)      
     })    
    })
   
    # Define the maximum of the sliders Threshold
    datamaxThreshold<- reactive({input$goButton | input$comparebutton | input$goButtona
      layer <-rst.pnl[[1]]
      area <- maxThrCalculation(layer)
      return(area)
    })
   
   
    ## The following part makes the two sliders to be reactive to each other -- once you move one of them the other one is triggered
    # Creation of the slider Threshold
    output$renderThr <- renderUI({
      sliderInput(inputId="thr", label = "Threshold per ha",min = 0, max =datamaxThreshold(), post=" ha", value = (50/100)*datamaxThreshold())
    })
   
    # Creation of the slider Threshold per quantile
    output$renderThrQ <- renderUI({
      sliderInput(inputId="thrQ", label = "Threshold per %",min = 0, max =100, post=" %", value = 50)
    })
   
    val <- reactive({input$thr}) #x
    valQ <- reactive({input$thrQ}) #y
    
    
    #Define the wanted threshold (area or quantile)
    observeEvent(input$thr,{
      t <<- "1"
      y <- as.integer((val()*100)/datamaxThreshold())
      updateSliderInput(session, "thrQ", value = y, step = 0.01)
    })
   
    observeEvent(input$thrQ,{
      t <<- "2"
      x <- as.integer(valQ()*(datamaxThreshold()/100))
      updateSliderInput(session, "thr", value = x, step = 0.01)
    })
    ## End of the "two sliders reactivity"
    
   
    # Define threshold map to visualize the best pixels under the threshold  
    output$mapThr <- renderLeaflet({
      input$goButtonThr 
      # If all weights sliders are on 0, warns the user
      validate(need(input$goButtonThr >0,""))
      validate(need(Reduce(function(acc, cur) { acc = (acc || (!is.na(cur) && (cur != 0))) }, weightsVector(), F), 
                    "Please put a positive weigth for at least one criterion or select new criteria (go back to select criteria tab)"))
      
      print("We entered the mapThr function")
      
      # Define progress message to warn the user to wait during the calculus 
      withProgress({
        setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
        
        # We need to know whether we used adv or basic mode
        if(mamapAvailable==0){
          # rst.comb.w <- calculmapmain()
          rst.comb.w <- calculmapmain()}
        else{
          rst.comb.w <- calculmapmaina()}
        
        thr=as.numeric(cellStats(rst.comb.w,stat=function(x,na.rm){stats::quantile(x,probs=1-thrInput()[1]/datamaxThreshold(),na.rm=T)}))
        
        # calculus of the threshold raster
        rst.comb.thr<-calcthr(rst.comb.w,thr)
        if(input$inputselect=="1"){
          projection(rst.comb.thr) <- projection(areaselected)
          rst.comb.thrm <- mask(rst.comb.thr, areaselected)}
        else{
          rst.comb.thrm <- rst.comb.thr}

        # Definition of the colour palette  of the future map + zoom for the map
        palos  <- c("#ff0000","#0000ff")
        zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
        
        # Leaflet map which replace the old map
        leaflet()%>%
          addGoogleTiles(layerId = "googleTileSat",
                         options = tileOptions(maxZoom = 15,
                                               updateWhenZooming = TRUE),
                         type = "satellite") %>%
          setView(lng = xcenter,
                  lat = ycenter,
                  zoom = zoomin[1]) %>%
          addLegend(position = "bottomright",colors = palos,labels =c("below", "above")) %>%
          addRasterImage(x = rst.comb.thrm,colors = colorQuantile(c("#ff0000","#0000ff"), domain = NULL,n=2,na.color=NA), opacity = 0.5)
      }, session=session)
    })    
    
    
    # Redraw the raster :)
    observe({ 
      input$mapThr_zoom
      input$mapOpacityThr
      input$mapThrSelect
      thrInput()
      thrQInput()
      validate(need((mamapAvailable==1 || mamapAvailable==0),""))
      # The console will trigger an error if the leaflet object called
      # Is not defined and this is sometimes the case as the map take less time to initalize then
      # the input trh, that's why we need to delay the execution
      # of the code for the first time you enter into the tab
      if(is.null(thrInput()) || is.null(thrQInput())){
        delay(200,{})
      }
      
      isolate({
        # print("ydist")
        # print(ydist)
        zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
        # print("zoomin1")
        # print(zoomin[1])
        
        if(mamapAvailable==0){
          # rst.comb.w <- calculmapmain()
          rst.comb.w <- calculmapmain()
        }
        else{
          rst.comb.w <- calculmapmaina()
        }
        
        if(!is.null(thrInput()) || !is.null(thrQInput())){
          if(input$mapThr_zoom == zoomin[1] || input$mapThr_zoom == zoomin[2] || input$mapThr_zoom == zoomin[3] || input$mapThr_zoom == zoomin[4] || input$mapThr_zoom == zoomin[5] || length(input$criteria) != 0 || input$mapOpacityThr){
            
            if (t == "2"){
              thr=as.numeric(cellStats(rst.comb.w,stat=function(x,na.rm){quantile(x,probs=1-thrInput()[1]/area,na.rm=T)}))
            } else if (t == "1"){
              thr=as.numeric(cellStats(rst.comb.w,stat=function(x,na.rm){quantile(x,probs=1-thrQInput()[1]/100,na.rm=T)}))
            }
            
            # calculus of the threshold raster
            rst.comb.thr<-calcthr(rst.comb.w,thr)
            if(input$inputselect=="1"){
              projection(rst.comb.thr) <- projection(areaselected)
              rst.comb.thrm <- mask(rst.comb.thr, areaselected)
            }else{
              rst.comb.thrm <- rst.comb.thr
            }
            
            # Redraw the map now
            if(input$mapThrSelect == 0){
              leafletProxy("mapThr") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileSat",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "satellite") %>%
                clearImages() %>%
                addRasterImage(x = rst.comb.thrm,colors =colorQuantile(c("#ff0000","#0000ff"), domain = NULL,n=2,na.color=NA),opacity = (input$mapOpacityThr)/100)            }
            else if (input$mapThrSelect == 1){
              leafletProxy("mapThr") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileRoad",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "roadmap") %>%
                clearImages() %>%
                addRasterImage(x = rst.comb.thrm,colors = colorQuantile(c("#ff0000","#0000ff"), domain = NULL,n=2,na.color=NA),opacity = (input$mapOpacityThr)/100)            }
            else{
              leafletProxy("mapThr") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileTer",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "terrain") %>%
                clearImages() %>%
                addRasterImage(x = rst.comb.thrm,colors = colorQuantile(c("#ff0000","#0000ff"), domain = NULL,n=2,na.color=NA),opacity = (input$mapOpacityThr)/100)            }
          }
        }
      })
    })
    
    # Event to toggle the legend
    observeEvent(input$mapshowThr,{
      proxy <- leafletProxy("mapThr")
      colorszz <- c("red", "blue")
      # Remove any existing legend, and only if the legend is
      # enabled, create a new one.
      if (input$mapshowThr) {
        proxy %>% addLegend(position = "bottomright",colors = c("#ff0000","#0000ff"),labels =c("below", "above"))
      }
      else{
        proxy %>% clearControls()
      }
    })
    
    observeEvent(input$goButtonThr, {
   #Statistics displayed on Thereshold tab
   output$stata  <- renderUI({   
     #If all weights sliders are on 0, display no text
     validate( need(weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])), ""))
       rst.comb.w <- calculmapmain()
       if(input$inputselect=="1"){
         projection(rst.comb.w) <- projection(areaselected)
         rst.comb.wm <- mask(rst.comb.w, areaselected)
       }else{
         rst.comb.wm <- rst.comb.w
       }
       somma <-nbpx_notNA(rst.comb.wm)
       area <-datamaxThreshold()
       
       # Calculus of the raster value which corresponds approximately to the quantile of the ratio 1-threshold/total area
       if(t=="0"){
         thr=as.numeric(cellStats(rst.comb.wm,stat=function(x,na.rm){quantile(x,probs=1,na.rm=T)}))}
       
       else if (t == "1"){
         thr=as.numeric(cellStats(rst.comb.wm,stat=function(x,na.rm){quantile(x,probs=1-thrInput()[1]/area,na.rm=T)}))
       } else if (t == "2"){
         thr=as.numeric(cellStats(rst.comb.wm,stat=function(x,na.rm){quantile(x,probs=1-thrQInput()[1]/100,na.rm=T)}))
       }
       
       #Calculus of the threshold raster
       rst.comb.thr2=binarythr(rst.comb.wm,thr)
       if(input$inputselect=="1"){
         projection(rst.comb.thr2) <- projection(areaselected)
         rst.comb.thr2m <- mask(rst.comb.thr2, areaselected)
       }else{
         rst.comb.thr2m <- rst.comb.thr2
       }
       
       #Count the number of good pixels
       c <- cellStats(rst.comb.thr2m,sum)
       
       #Calculus of the number of bad pixels
       d <- somma -c
       
       #Percentage of c and d
       pc <-c/somma*100
       pd <-d/somma*100
       
       # Area of c and d
       Agpx <-(xres(rst.comb.thr2m)*yres(rst.comb.thr2m))/10000*c
       Abpx <-(xres(rst.comb.thr2m)*yres(rst.comb.thr2m))/10000*d
       
       # Chosen method
       if(t =="1"){
         m <<- "Area"
       } else {
         m <<- "Percentage"
       }
       
       #Creation of the stata div 
       tags$div(  id="stata",
                  tags$p("Method : ", m),
                  tags$p("Number of pixels above the Threshold: ",c),
                  tags$p("Percentage of good pixels : ",tags$b(round(pc, digits = 1)),"%"),
                  tags$p("Area of good pixels : ",tags$i(round(Agpx,digits = 2)),"ha"),
                  tags$p("Number of bad pixels : ",d),
                  tags$p("Percentage of bad pixels : ",tags$b(round(pd, digits = 1)),"%"),
                  tags$p("Area of bad pixels : ",tags$i(round(Abpx,digits = 2)),"ha")
      )
  
   })
   })
   
    ################## Compare methods ###########################################

    # Retrieval of the names of the methods to compare (Panel "comparison of methods") from input$checkGroupCM
    mthr=1

    methodscomparedname <- reactive({
      input$comparebutton
      input$goButton
      isolate({ 
        n <-array(0,3)
        if(length(input$checkGroupCM)==2){
          K=sapply(1:2, function(i){
            if(input$checkGroupCM[i]==2){n[i]<- "LWC2"}
            else if(input$checkGroupCM[i]==3){n[i]<- "Electre"}})
          n[1] <- paste0(K[1], "-", K[2])
          n[2:3]<- K[1:2]
        }
        else {n[] <-0}
        return(n)
     })   
   })		
   
   
    # Calculation of the raster for the two methods chosen and comparison of the two methods
    methodscomparedcalcul <- reactive({methodscomparedname()
      isolate({ 
        n<- methodscomparedname()
        if (n[1] != 0){
          rst.comb <-stack()
          Q= lapply(2:3, function(i){
            if(n[i]=="LWC2"){rst.comb.w<-lwc2(rst.pnl,weightsVector())}
            else if(n[i]=="Electre"){rst.comb.w=electre(rst.pnl, weightsVector())}
            rst.comb.w=normalizer(rst.comb.w)
            rst.comb <- addLayer(rst.comb, rst.comb.w)
          })
          rst.comb=stack(Q)
          # Absolute difference between the two layers
          comp <- abs(rst.comb[[1]] - rst.comb[[2]])
          rst.comb <- addLayer(rst.comb, comp)
          names(rst.comb) <- c(n[2],n[3],n[1])
        }
        return(rst.comb) 
      })    
    })	
   
    # Define input selection list of the layers which can be displayed in the panel "Compare methods":
    # The unique raster with the positive and negative weights vector for each method
    # The absolute difference between the two unique rasters
    output$renderSelectlayerCM <- renderUI({methodscomparedname()
      isolate({
        n<- methodscomparedname()
        if (n[1] != 0){
          selectInput("methodscomp", "Choose a layer to display:",choices=lapply(1:length(n), function(i) {n[i]}))
        }
      })
    })
   
    # Define input selection list of the thresholdlayers which can be displayed in the panel "Compare methods" 
    output$renderSelectlayerThrCM <- renderUI({methodscomparedname()
      isolate({
        n<- methodscomparedname()
        if (n[1] != 0){
          selectInput("thresholdcomp", "Choose a layer to display:", 
                      choices=lapply(1:length(n), function(i) {n[i]}))
        }
      })
    })  
   
    #Text above the map, depends on the layer to be displayed selected
    output$txtmapCM <- renderText({input$methodscomp
      n<- methodscomparedname()
      validate(need(n[1] !=0," "))
      if (is.null(input$methodscomp) == F){
        if (input$methodscomp =="LWC" | input$methodscomp =="LWC2" |input$methodscomp =="Electre"){
          txt<-"The best value is 1 (blue) and the worst 0 (red) for the project chosen Expansion considering these criteria, the weights selected and the chosen method"
        }
        else{
          txt<-"Absolute difference of the values obtained with the two methods chosen."
        }
        txt
      }
    })
   
    # Display the layer selected on input$methodscomp
    # Display the layer selected on input$methodscomp
    output$mapCM <- renderLeaflet({input$methodscomp
      if (is.null(input$methodscomp) == F){
        n<- methodscomparedname()
        validate(need(Reduce(function(acc, cur) { acc = (acc || (!is.na(cur) && (cur != 0))) }, weightsVector(), F), 
                      "Please put a positive weigth for at least one criterion or select new criteria (go back to select criteria tab)"))
        validate( need(n[1] !=0, "Please choose 2 methods"))
        withProgress({ 
          setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
          rst.comb <- methodscomparedcalcul()
          
          # Substitution of the dash (-) by a point to match the selected layer and the layer to display
          dash <- gsub("-",".",input$methodscomp)
          if (names(rst.comb)[1]== dash | names(rst.comb)[2]== dash | names(rst.comb)[3] == dash){
            layerdisplayed <- subset(rst.comb,dash)
            
            # The layer is cropped to match the area selected
            layerdisplayed <- crop(layerdisplayed, extent(areaselected))
            if(input$inputselect=="1"){
              projection(layerdisplayed) <- projection(areaselected)
              layerd <- mask(layerdisplayed, areaselected)
            }else{
              layerd <- layerdisplayed
              # layerd = image to display into a addRaster
            }
            # Definition of the colour palette  of the map for one methods
            palos  <-brewer.pal(10,"RdYlBu")  
            zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
            
            # The colors used on the map depends of the layer chosen to be displayed
            if (input$methodscomp =="LWC2" |input$methodscomp =="Electre"){
              leaflet()%>%
                addGoogleTiles(layerId = "googleTileSat",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "satellite") %>%
                setView(lng = xcenter,
                        lat = ycenter,
                        zoom = zoomin[1]) %>%
                addRasterImage(x = layerd,colors = palos,opacity = (input$mapOpacityCM)/100) %>%
                addLegend(position = "bottomright",colors = palos,labels =c("0","0,10","0,20","0,30","0,40","0,50","0,60","0,70","0,80","0,90 and more"))
            }
            else{
              palos <- brewer.pal(9,"Reds")
              leaflet()%>%
                addGoogleTiles(layerId = "googleTileSat",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "satellite") %>%
                setView(lng = xcenter,
                        lat = ycenter,
                        zoom = zoomin[1]) %>%
                addRasterImage(x = layerd,colors = palos,opacity = (input$mapOpacityCM)/100) %>%
                addLegend(position = "bottomright",colors = palos,labels =c("0 to 0,10","0,20","0,30","0,40","0,50","0,60","0,70","0,80","0,90 and more"))
            }
          }
        },session=session)
      }
    })
    
    # Update the mapCM
    observe({ 
      input$mapCM_zoom
      input$mapCM
      input$methodscomp
      input$mapCMSelect
      
      validate(need(!is.null(input$methodscomp),""))
      
      isolate({
        if (input$methodscomp =="LWC2" |input$methodscomp =="Electre"){
          palos  <-brewer.pal(10,"RdYlBu")
        }
        else{
          palos <- brewer.pal(9,"Reds")
        }
        zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
        
        if(input$goButton > 0 ){
          if(input$mapCM_zoom == zoomin[1] || input$mapCM_zoom == zoomin[2] || input$mapCM_zoom == zoomin[3] || input$mapCM_zoom == zoomin[4] || input$mapCM_zoom == zoomin[5] || input$mapOpacitymain){
            
            rst.comb <- methodscomparedcalcul()
            
            # Substitution of the dash (-) by a point to match the selected layer and the layer to display
            dash <- gsub("-",".",input$methodscomp)
            if (names(rst.comb)[1]== dash | names(rst.comb)[2]== dash | names(rst.comb)[3] == dash){
              layerdisplayed <- subset(rst.comb,dash)
              
              # The layer is cropped to match the area selected
              layerdisplayed <- crop(layerdisplayed, extent(areaselected))
              if(input$inputselect=="1"){
                projection(layerdisplayed) <- projection(areaselected)
                layerd <- mask(layerdisplayed, areaselected)
              }else{
                layerd <- layerdisplayed
                # layerd = image to display into a addRaster
              }
              
              # Redraw the map now
              if(input$mapCMSelect == 0){
                leafletProxy("mapCM") %>%
                  clearTiles() %>%
                  addGoogleTiles(layerId = "googleTileSat",
                                 options = tileOptions(maxZoom = 15,
                                                       updateWhenZooming = TRUE),
                                 type = "satellite") %>%
                  clearImages() %>%
                  addRasterImage(x = layerd,colors = palos,opacity = (input$mapOpacityCM)/100)
              }
              else if (input$mapCMSelect == 1){
                leafletProxy("mapCM") %>%
                  clearTiles() %>%
                  addGoogleTiles(layerId = "googleTileRoad",
                                 options = tileOptions(maxZoom = 15,
                                                       updateWhenZooming = TRUE),
                                 type = "roadmap") %>%
                  clearImages() %>%
                  addRasterImage(x = layerd,colors = palos,opacity = (input$mapOpacityCM)/100)
              }
              else{
                leafletProxy("mapCM") %>%
                  clearTiles() %>%
                  addGoogleTiles(layerId = "googleTileTer",
                                 options = tileOptions(maxZoom = 15,
                                                       updateWhenZooming = TRUE),
                                 type = "terrain") %>%
                  clearImages() %>%
                  addRasterImage(x = layerd,colors = palos,opacity = (input$mapOpacityCM)/100)
              }
            }
          }
        }
      })
    })
    
    # Show the legend
    observeEvent(input$mapshowCM,{
      validate(need(!is.null(input$methodscomp),""))
      if (input$methodscomp =="LWC2" |input$methodscomp =="Electre"){
        palos  <-brewer.pal(10,"RdYlBu")
      }
      else{
        palos <- brewer.pal(9,"Reds")
      }
      proxy <- leafletProxy("mapCM")
      
      # Remove any existing legend, and only if the legend is
      # enabled, create a new one.
      if (input$mapshowCM) {
        proxy %>% addLegend(position = "bottomright",colors = palos,labels =c("0","0,10","0,20","0,30","0,40","0,50","0,60","0,70","0,80","0,90 and more"))
      }
      else{
        proxy %>% clearControls()
      }
    })
    
    # Define the scatter plot of the two methods chosen
    output$scatter <- renderPlot({ methodscomparedname()
      n<- methodscomparedname()
      validate( need(weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])), "Please put a positive weigth for at least one criterion (go back to select weights tab) or select new criteria (go back to select criteria tab)"))
      validate( need(n[1] !=0, "Please choose 2 methods"))
      withProgress({ 
        setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
        rst.comb <- methodscomparedcalcul()# The layer is cropped to match the area selected
        rst.comb <- crop(rst.comb, extent(areaselected))
        if(input$inputselect=="1"){
          #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
          projection(rst.comb) <- projection(areaselected)
          rst.combm <- mask(rst.comb, areaselected)
        }else{
          rst.combm <- rst.comb
        }
        layer1 <- subset(rst.combm,n[2])
        layer2 <- subset(rst.combm,n[3])
        plot(na.omit(layer1), na.omit(layer2), xlab=n[2], ylab=n[3])
      },session=session)
    })
    
    # Define threshold input as the value of the slider "Threshold" in the panel "compare methods"
    thrInputCM <- reactive({ input$thrCM | input$thrCMQ
      if(mthr==1){
        y<-input$thrCM
      }else if (mthr==0){
        y <-input$thrCMQ
      }
      return(y)      
    })
   
    
    # Observe which threshold you use
    observeEvent(input$thrCM, {
      mthr <<- 1
    })
    observeEvent(input$thrCMQ, {
      mthr<<-0
    })
    
    # Display the threshold sliderinput in Compare methods
    output$renderThrCM <- renderUI({
      sliderInput(inputId="thrCM", label = "Threshold per ha",min = 0, max =datamaxThreshold(), post=" ha", value = (50/100)*datamaxThreshold())
    })
    output$renderThrCMQ <- renderUI({
      sliderInput(inputId="thrCMQ", label = "Threshold per %",min = 0, max =100, post=" %", value = 50)
    })
    
    valCM <- reactive({input$thrCM}) #x
    valCMQ <- reactive({input$thrCMQ}) #y
    
    #Define the wanted threshold (area or quantile)
    observeEvent(input$thrCM,{
      t <<- "1"
      y <- as.integer((valCM()*100)/datamaxThreshold())
      updateSliderInput(session, "thrCMQ", value = y, step = 0.01)
    })
    
    observeEvent(input$thrCMQ,{
      t <<- "2"
      x <- as.integer(valCMQ()*(datamaxThreshold()/100))
      updateSliderInput(session, "thrCM", value = x, step = 0.01)
    })
    ## End of the "two sliders reactivity"
  
    # Display the threshold map of the layer selected in input$thresholdcomp
    output$mapThrCM <- renderPlot({input$thresholdcomp
      if (is.null(input$thresholdcomp) == F){
          n<- methodscomparedname()
          # If all weights sliders are on 0, warns the user
          validate(need(Reduce(function(acc, cur) { acc = (acc || (!is.na(cur) && (cur != 0))) }, weightsVector(), F), 
                        "Please put a positive weigth for at least one criterion or select new criteria (go back to select criteria tab)"))
          
          # Define progress message to warn the user to wait during the calculus 
          withProgress({ 
            setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
            
            rst.comb <- methodscomparedcalcul()
            dash <- gsub("-",".",input$thresholdcomp)
            rst.comb.thr <- stack()
            
            if (names(rst.comb)[1]== dash | names(rst.comb)[2]== dash | names(rst.comb)[3] == dash){
               Q=lapply(2:3, function(i){
                    rst.comb.thr.w <- subset(rst.comb, n[i])
                    if(input$inputselect=="1"){
                      #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
                      projection(rst.comb.thr.w) <- projection(areaselected)
                      rst.comb.thr.w <- mask(rst.comb.thr.w, areaselected)
                    }
                    
            
                    area <- maxThrCalculation(rst.comb.thr.w)
                    # Calculus of the raster value which corresponds approximately to the quantile of the ratio 1-threshold/total area
                    if (mthr==0){
                      thr=as.numeric(cellStats(rst.comb.thr.w,stat=function(x,na.rm){quantile(x,probs=1-thrInputCM()[1]/100,na.rm=T)}))
                    }
                    else if (mthr==1){
                      thr=as.numeric(cellStats(rst.comb.thr.w,stat=function(x,na.rm){quantile(x,probs=1-thrInputCM()[1]/area,na.rm=T)}))
                    }
                    
                    
                    # calculus of the threshold raster
                    rst.comb.thr.w=calcthr(rst.comb.thr.w,thr)
                    rst.comb.thr <- addLayer(rst.comb.thr, rst.comb.thr.w)
               })

               rst.comb.thr<-stack(Q)
               comp <- overlay(rst.comb.thr$layer.1,rst.comb.thr$layer.2, fun=function(x,y){ifelse(x>=0 & y>=0,10,ifelse(x<0 & y<0,-10, ifelse(x>=0 & y<0,-5,5)))})
               
               rst.comb.thr <- addLayer(rst.comb.thr, comp)
               names(rst.comb.thr) <- c(n[2],n[3],n[1])

               layerdisplayed <- subset(rst.comb.thr,dash)
               # The layer is cropped to match the area selected
               layerdisplayed <- crop(layerdisplayed, extent(areaselected))
               if(input$inputselect=="1"){
                 projection(layerdisplayed) <- projection(areaselected)
                 layerd <- mask(layerdisplayed, areaselected)
               }else{
                 layerd <- layerdisplayed
               }
               
               nbgoodpx <<- length(layerd[layerd==10])
               px <<- sum(is.na(layerd[1:ncell(layerd)])==FALSE)

               # Definition of the colour palette  of the future map
               palos  <- brewer.pal(10,"RdYlBu")  
                
               # Definition of the name of the map
               namos  <-paste0("MCDAMAMapII",as.numeric(Sys.time()),".html", collapse = NULL)
                
               # Creation of the html request to create the map with Google Maps. create an html map file and 2 png files a grid and a legend
               if (input$thresholdcomp =="LWC" | input$thresholdcomp =="LWC2" |input$thresholdcomp =="Electre"){
                 breakpoints<-unique(c(-1,0,1))
                  par(mar=c(8, 4.1, 4.1, 2.1), xpd=F)
                  plot(layerd, legend = FALSE, col = brewer.pal(2,"RdYlBu"),breaks=breakpoints)
                  par(xpd=TRUE,mar=c(1, 4.1, 1, 4.1))
                  legend("bottomright", inset=c(0,-0.4), legend = c("Others", "Best pixels"), fill = brewer.pal(2,"RdYlBu"),xpd = TRUE)
                   
               }
               else{
                  breakpoints<-unique(c(-10,-7,0,7,10))
                  par(mar=c(8, 4.1, 4.1, 2.1), xpd=F)
                  plot(layerd, legend=F, col = brewer.pal(4,"RdYlBu"),breaks=breakpoints)
                  par(xpd=TRUE,mar=c(1, 4.1, 1, 4.1))
                  legend("bottomright", inset=c(0,-0.4), legend = c("Others","Best for the first method","Best for the second method", "Best pixels"), fill = brewer.pal(4,"RdYlBu"))
                }
            }
         }, session=session)
      }
    })
    
    # Calculus used when the user want to compare the threshold between two methods
    # It calculate the area above the threshold for both methods selected
    areaboth <- reactive({thrInputCM()
      areagoodpx <- (xres(rst.pnl[[1]])*yres(rst.pnl[[1]]))/10000* nbgoodpx
      return(areagoodpx)
    })
    percentageboth <- reactive({thrInputCM()
      percentgoodpx <- 100*nbgoodpx/px
      return(percentgoodpx)
    })
    
    # Displayed the number obtained with areabothA ou areabothQ
    output$txtgoodarea <- renderText({
      n<- methodscomparedname()
      validate(need((weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])) & n[1] !=0 & input$thresholdcomp !="LWC" & input$thresholdcomp !="LWC2" & input$thresholdcomp !="Electre")," "))
      if (mthr==1){
        paste0("Areas above threshold for both methods : ",areaboth()," ha")
      }else if (mthr==0){
        paste0("Areas above threshold for both methods : ",percentageboth()," %")
      }
    })
    
     
    ################## Stats ###########################################

        # Create a matrix which contains the positive criteria weights
    output$matrixCurrentWeightsP <- renderTable({input$Project
      weightsVector()  								
      validate(need(Reduce(function(acc, cur) { acc = (acc || (!is.na(cur) && (cur != 0))) }, weightsVector(), F), 
                    "Please put a positive weigth for at least one criterion or select new criteria (go back to select criteria tab)"))
      
			#read the weights and create a matrix out of the weights.
      # P <- head(weightsVector(),n=length(HPN[,3]))
      # matrix <- matrix(P,ncol = 2)
      # dimnames(matrix)=list(c(""),HPN[,4])
      
      #Transform the row data in understandable text
      descript <-sapply(HPN[,4], toString)
      descript <- gsub("_", " ", descript)
      
      matrix <- cbind(descript,weightsVector())
      colnames(matrix) <- c('Criteria','Weight')
      # dimnames(matrix)= list('Criteria','Weight')
      matrix               
    })
  								   
    # Create a matrix which contains the negative criteria weights
  #   output$matrixCurrentWeightsN <- renderTable({input$Project 
  #      weightsVector()
  # 				validate( need(weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])), "Please put a positive weigth for at least one criterion (go back to select weights tab) or select new criteria (go back to select criteria tab)"))
  # 									#read the negative weights create a matrix
  #                   N <- tail(weightsVector(),n=length(HN[,1]))
  #                   matrix <- matrix(N,nrow=1)
  # 									dimnames(matrix)=list(c(""),xn)
  #                   matrix
  #   })
  								
    # # Create the weights history matrix for each method
    # output$christomatLWC1 <- renderTable({input$Project
    #   input$saveButton
    #   #If no weights are saved, warns the user
    # 			validate( need(temp_WeightssavedSize("LWC1") > 0, "Please save criteria weights with method LWC (go back to select weights tab)"))
    #       matrix_Stats(readWeightssaved("LWC1","temp"))
    # 
    # })
   
    output$christomatLWC2 <- renderTable({
      input$Project
      input$saveButton  #If no weights are saved, warns the user
        validate( need(temp_WeightssavedSize("LWC2") > 0, 
                       "Please save criteria weights with method LWC2 (go back to select weights tab)"))
        matrix_Stats(readWeightssaved("LWC2","temp"))
    })
   
    output$christomatElectre <- renderTable({
      input$Project
      input$saveButton  #If no weights are saved, warns the user
      validate( need(temp_WeightssavedSize("Electre") > 0, 
                     "Please save criteria weights with method Electre (go back to select weights tab)"))
      matrix_Stats(readWeightssaved("Electre", "temp"))
    })
  
    # Create the download handler to download the criteria weight history	(CWH)							  
    
    # # We need to get rid of the LWC1 method so that's why it is commented
    # output$downloadCWH_LWC1 <- downloadHandler(
    #   filename = function(){return("WeightsLWC.csv")},
    #   content = function(file) {write.csv(readWeightssaved("LWC1", "temp"), file)}
    # )
    
    output$downloadCWH_LWC2 <- downloadHandler( 
     filename = function(){return("WeightsLWC2.csv")},
     content = function(file) { write.csv(readWeightssaved("LWC2","temp"), file)}
    )
    
    output$downloadCWH_Electre <- downloadHandler( 
     filename = function(){return("WeightsElectre.csv")},
     content = function(file) {write.csv(readWeightssaved("Electre","temp"), file)}
    )
   
   
    ################## Average ##########################################################					  
  	
    # Display the map
    output$mapAV_LWC2 <- renderLeaflet({  
      input$Project
      input$saveButton
      
      #If no weights are saved, warns the user
      validate( need(temp_WeightssavedSize("LWC2") > 0, "Please save criteria weights with method LWC2 (go back to select weights tab)"))
        #Creation progress warning
        withProgress({ 
          setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
          vec <- weightAverage(readWeightssaved("LWC2", "temp"))
          
          #Create the corresponding map in an iframe
          rst.comb.w=lwc2(rst.pnl, vec)
          rst.comb.w2=normalizer(rst.comb.w)
          # The layer is cropped to match the area selected
          rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
          if(input$inputselect=="1"){
            #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
            projection(rst.comb.w2) <- projection(areaselected)
            rst.comb.w2m <- mask(rst.comb.w2, areaselected)
          }else{
            rst.comb.w2m <- rst.comb.w2
          }
          # rst.comb.w2m
          zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
          palos  <-brewer.pal(10,"RdYlBu")
          
          leaflet()%>%
            addGoogleTiles(layerId = "googleTileSat",
                           options = tileOptions(maxZoom = 15,
                                                 updateWhenZooming = TRUE),
                           type = "satellite") %>%
            setView(lng = xcenter,
                    lat = ycenter,
                    zoom = zoomin[1]) %>%
            addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityAv)/100) %>%
            addLegend(position = "bottomright",colors = palos,labels =c("0","0,10","0,20","0,30","0,40","0,50","0,60","0,70","0,80","0,90 and more"))
          
        }, session=session)
    })
    
    # Update the map with everything
    observe({ 
      input$mapAV_LWC2_zoom
      input$mapOpacityAv
      input$mapAvSelect
      
      isolate({
        zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
        
        if(input$goButton > 0 ){
          if(input$mapAV_LWC2_zoom == zoomin[1] || input$mapAV_LWC2_zoom == zoomin[2] || input$mapAV_LWC2_zoom == zoomin[3] || input$mapAV_LWC2_zoom == zoomin[4] || input$mapAV_LWC2_zoom == zoomin[5] || input$mapOpacitymain){
              vec <- weightAverage(readWeightssaved("LWC2", "temp"))
              #Create the corresponding map in an iframe
              rst.comb.w=lwc2(rst.pnl, vec)
              rst.comb.w2=normalizer(rst.comb.w)
              # The layer is cropped to match the area selected
              rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
              if(input$inputselect=="1"){
                #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
                projection(rst.comb.w2) <- projection(areaselected)
                rst.comb.w2m <- mask(rst.comb.w2, areaselected)
              }else{
                rst.comb.w2m <- rst.comb.w2
              }
              zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
              palos  <-brewer.pal(10,"RdYlBu")
              # Redraw the map now
              if(input$mapAvSelect == 0){
                leafletProxy("mapAV_LWC2") %>%
                  clearTiles() %>%
                  addGoogleTiles(layerId = "googleTileSat",
                                 options = tileOptions(maxZoom = 15,
                                                       updateWhenZooming = TRUE),
                                 type = "satellite") %>%
                  clearImages() %>%
                  addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityAv)/100)
              }
              else if (input$mapAvSelect == 1){
                leafletProxy("mapAV_LWC2") %>%
                  clearTiles() %>%
                  addGoogleTiles(layerId = "googleTileRoad",
                                 options = tileOptions(maxZoom = 15,
                                                       updateWhenZooming = TRUE),
                                 type = "roadmap") %>%
                  clearImages() %>%
                  addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityAv)/100)
              }
              else{
                leafletProxy("mapAV_LWC2") %>%
                  clearTiles() %>%
                  addGoogleTiles(layerId = "googleTileTer",
                                 options = tileOptions(maxZoom = 15,
                                                       updateWhenZooming = TRUE),
                                 type = "terrain") %>%
                  clearImages() %>%
                  addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityAv)/100)
              }
            
          }
        }
      })
    })
    
    # Show the legend
    observeEvent(input$mapshowAv,{
      proxy <- leafletProxy("mapAV_LWC2")
      palos  <-brewer.pal(10,"RdYlBu")
      # Remove any existing legend, and only if the legend is
      # enabled, create a new one.
      if (input$mapshowAv) {
        proxy %>% addLegend(position = "bottomright",colors = palos,labels =c("0","0,10","0,20","0,30","0,40","0,50","0,60","0,70","0,80","0,90 and more"))
      }
      else{
        proxy %>% clearControls()
      }
    })
  								  
  	output$tabAV_LWC2 <- renderTable({input$Project
  	  input$saveButton  
  					#If no weights are saved, warns the user
            validate( need(temp_WeightssavedSize("LWC2") > 0, ""))
  	            vec <- weightAverage(readWeightssaved("LWC2", "temp"))
  	            weightArray(vec)
       })
  		
  	# Display the Electre map 
  	output$mapAV_Electre <- renderLeaflet({ 
  	  input$Project
  	  input$saveButton 
  	  
  	  #If no weights are saved, warns the user
  	  validate( need(temp_WeightssavedSize("Electre") > 0, "Please save criteria weights with method Electre (go back to select weights tab)"))
  	  
  	  #Creation progress warning
  	  withProgress({ 
  	    setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
  	    vec <- weightAverage(readWeightssaved("Electre", "temp"))
  	    
  	    #Create the corresponding map in an iframe
  	    rst.comb.w=electre(rst.pnl, vec)
  	    rst.comb.w2=normalizer(rst.comb.w)
  	    # The layer is cropped to match the area selected
  	    rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
  	    if(input$inputselect=="1"){
  	      #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
  	      projection(rst.comb.w2) <- projection(areaselected)
  	      rst.comb.w2m <- mask(rst.comb.w2, areaselected)
  	    }else{
  	      rst.comb.w2m <- rst.comb.w2
  	    }
  	    zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
  	    palos  <-brewer.pal(10,"RdYlBu")  
  	    
  	    leaflet()%>%
  	      addGoogleTiles(layerId = "googleTileSat",
  	                     options = tileOptions(maxZoom = 15,
  	                                           updateWhenZooming = TRUE),
  	                     type = "satellite") %>%
  	      setView(lng = xcenter,
  	              lat = ycenter,
  	              zoom = zoomin[1]) %>%
  	      addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityAv2)/100) %>%
  	      addLegend(position = "bottomright",colors = palos,labels =c("0","0,10","0,20","0,30","0,40","0,50","0,60","0,70","0,80","0,90 and more"))
  	  }, session=session)
  	})
  	
  	# Update the Electre Map
  	observe({ 
  	  input$mapAV_Electre_zoom
  	  input$mapOpacityAv2
  	  input$mapAvSelect2
  	  
  	  
  	  isolate({
  	    zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
  	    
  	    if(input$goButton > 0 ){
  	      if(input$mapAV_Electre_zoom == zoomin[1] || input$mapAV_Electre_zoom == zoomin[2] || input$mapAV_Electre_zoom == zoomin[3] || input$mapAV_Electre_zoom == zoomin[4] || input$mapAV_Electre_zoom == zoomin[5] || input$mapOpacitymain){
  	          #Create the corresponding map in an iframe
  	          rst.comb.w=lwc2(rst.pnl, vec)
  	          rst.comb.w2=normalizer(rst.comb.w)
  	          # The layer is cropped to match the area selected
  	          rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
  	          if(input$inputselect=="1"){
  	            #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
  	            projection(rst.comb.w2) <- projection(areaselected)
  	            rst.comb.w2m <- mask(rst.comb.w2, areaselected)
  	          }else{
  	            rst.comb.w2m <- rst.comb.w2
  	          }
  	          zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
  	          palos  <-brewer.pal(10,"RdYlBu")
  	          # Redraw the map now
  	          if(input$mapAvSelect2 == 0){
  	            leafletProxy("mapAV_Electre") %>%
  	              clearTiles() %>%
  	              addGoogleTiles(layerId = "googleTileSat",
  	                             options = tileOptions(maxZoom = 15,
  	                                                   updateWhenZooming = TRUE),
  	                             type = "satellite") %>%
  	              clearImages() %>%
  	              addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityAv2)/100)
  	          }
  	          else if (input$mapAvSelect2 == 1){
  	            leafletProxy("mapAV_Electre") %>%
  	              clearTiles() %>%
  	              addGoogleTiles(layerId = "googleTileRoad",
  	                             options = tileOptions(maxZoom = 15,
  	                                                   updateWhenZooming = TRUE),
  	                             type = "roadmap") %>%
  	              clearImages() %>%
  	              addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityAv2)/100)
  	          }
  	          else{
  	            leafletProxy("mapAV_Electre") %>%
  	              clearTiles() %>%
  	              addGoogleTiles(layerId = "googleTileTer",
  	                             options = tileOptions(maxZoom = 15,
  	                                                   updateWhenZooming = TRUE),
  	                             type = "terrain") %>%
  	              clearImages() %>%
  	              addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityAv2)/100)
  	          }
  	        
  	      }
  	    }
  	  })
  	})
  	
  	# Show the legend
  	observeEvent(input$mapshowAv2,{
  	  proxy <- leafletProxy("mapAV_Electre")
  	  palos  <-brewer.pal(10,"RdYlBu")
  	  # Remove any existing legend, and only if the legend is
  	  # enabled, create a new one.
  	  if (input$mapshowAv2) {
  	    proxy %>% addLegend(position = "bottomright",colors = palos,labels =c("0","0,10","0,20","0,30","0,40","0,50","0,60","0,70","0,80","0,90 and more"))
  	  }
  	  else{
  	    proxy %>% clearControls()
  	  }
  	})
  		
  	output$tabAV_Electre <- renderTable({ input$Project
  		  input$saveButton 
  		  #If no weights are saved, warns the user
  		  validate( need(temp_WeightssavedSize("Electre") > 0, ""))
  		  vec <- weightAverage(readWeightssaved("Electre", "temp"))
  		  weightArray(vec)
  		  })
  		
  		
  	################## Consensus ###########################################
  	
  	# This is the renderLeaflet code for the 'LWC2/LWC' map 
  	# I've figure out that the code is pretty much the 
  	# same as the one for Average map and Weigth adv
  	# while reading the previous code of the last student
    output$mapCON_LWC2 <- renderLeaflet({  
  	  input$Project
  	  input$saveButton
  	  
  	  #If no weights are saved, warns the user
  	  validate( need((!is.na(readWeightssaved("LWC2")) & !is.null(readWeightssaved("LWC2"))) , 
  	                 "Please save for real criteria weights with method LWC2 (go back to select weights tab)"))
  	  #Creation progress warning
  	  withProgress({ 
  	    setProgress(message = "Calculating, please wait",
  	                detail = "This may take a few moments...")
  	    vec <- weightAverage(readWeightssaved("LWC2"))
  	    
  	    #Create the map with the consensus vector
  	    rst.comb.w=lwc2(rst.pnl, vec)
  	    rst.comb.w2=normalizer(rst.comb.w)
  	    # The layer is cropped to match the area selected
  	    rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
  	    if(input$inputselect=="1"){
  	      projection(rst.comb.w2) <- projection(areaselected)
  	      rst.comb.w2m <- mask(rst.comb.w2, areaselected)
  	    }else{
  	      rst.comb.w2m <- rst.comb.w2
  	    }
  	    
  	    zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
  	    palos  <-brewer.pal(10,"RdYlBu")
  	    
  	    leaflet()%>%
  	      addGoogleTiles(layerId = "googleTileSat",
  	                     options = tileOptions(maxZoom = 15,
  	                                           updateWhenZooming = TRUE),
  	                     type = "satellite") %>%
  	      setView(lng = xcenter,
  	              lat = ycenter,
  	              zoom = zoomin[1]) %>%
  	      addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityAv)/100) %>%
  	      addLegend(position = "bottomright",colors = palos,
  	                labels =c("0","0,10","0,20","0,30","0,40","0,50","0,60","0,70","0,80","0,90 and more"))
  	    
  	  }, session=session)
  	})
  	
  	# Update the map
  	observe({ 
  	  input$mapCON_LWC2_zoom
  	  input$mapOpacityCON
  	  input$mapCONSelect
  	  
  	  isolate({
  	    zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
  	    if(input$goButton > 0 ){
  	      if(input$mapCON_LWC2_zoom == zoomin[1] || input$mapCON_LWC2_zoom == zoomin[2] || input$mapCON_LWC2_zoom == zoomin[3] || input$mapCON_LWC2_zoom == zoomin[4] || input$mapCON_LWC2_zoom == zoomin[5] || input$mapOpacitymain){
  	        vec <- weightAverage(readWeightssaved("LWC2"))
  	        
  	        #Create the map with the consensus vector
  	        rst.comb.w=lwc2(rst.pnl, vec)
  	        rst.comb.w2=normalizer(rst.comb.w)
  	        # The layer is cropped to match the area selected
  	        rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
  	        if(input$inputselect=="1"){
  	          projection(rst.comb.w2) <- projection(areaselected)
  	          rst.comb.w2m <- mask(rst.comb.w2, areaselected)
  	        }else{
  	          rst.comb.w2m <- rst.comb.w2
  	        }
  	        palos  <-brewer.pal(10,"RdYlBu")
  	        
  	        # Redraw the map now
  	        if(input$mapCONSelect == 0){
  	          leafletProxy("mapCON_LWC2") %>%
  	            clearTiles() %>%
  	            addGoogleTiles(layerId = "googleTileSat",
  	                           options = tileOptions(maxZoom = 15,
  	                                                 updateWhenZooming = TRUE),
  	                           type = "satellite") %>%
  	            clearImages() %>%
  	            addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityCON)/100)
  	        }
  	        else if (input$mapCONSelect == 1){
  	          leafletProxy("mapCON_LWC2") %>%
  	            clearTiles() %>%
  	            addGoogleTiles(layerId = "googleTileRoad",
  	                           options = tileOptions(maxZoom = 15,
  	                                                 updateWhenZooming = TRUE),
  	                           type = "roadmap") %>%
  	            clearImages() %>%
  	            addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityCON)/100)
  	        }
  	        else{
  	          leafletProxy("mapCON_LWC2") %>%
  	            clearTiles() %>%
  	            addGoogleTiles(layerId = "googleTileTer",
  	                           options = tileOptions(maxZoom = 15,
  	                                                 updateWhenZooming = TRUE),
  	                           type = "terrain") %>%
  	            clearImages() %>%
  	            addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityCON)/100)
  	        }
  	        
  	      }
  	    }
  	  })
  	})
  	
  	# Legend for the map
  	observeEvent(input$mapshowCON,{
  	  proxy <- leafletProxy("mapCON_LWC2")
  	  palos  <-brewer.pal(10,"RdYlBu")
  	  # Remove any existing legend, and only if the legend is
  	  # enabled, create a new one.
  	  if (input$mapshowCON) {
  	    proxy %>% addLegend(position = "bottomright",colors = palos,
  	                        labels =c("0","0,10","0,20","0,30","0,40","0,50","0,60","0,70","0,80","0,90 and more"))
  	  }
  	  else{
  	    proxy %>% clearControls()
  	  }
  	})
  	
  	# This is the vector which represent the 'weigth vector' 
  	# used for the current analysis by the user 
  	output$tabCON_LWC2 <- renderTable({input$Project
  	  input$saveButton  
  	  #If no weights are saved, warns the user
  	  validate( need((!is.na(readWeightssaved("LWC2")) & !is.null(readWeightssaved("LWC2"))), ""))
  	  vec <- weightAverage(readWeightssaved("LWC2"))
  	  weightArray(vec)
  	})
  	
  	# This is the renderLeaflet code for the 'Electre' map 
  	output$mapCON_Electre <- renderLeaflet({  
  	  input$Project
  	  input$saveButton
  	  
  	  #If no weights are saved, warns the user
  	  validate( need((!is.na(readWeightssaved("Electre")) & !is.null(readWeightssaved("Electre"))),
  	                 "Please save for real criteria weights with method LWC2 (go back to select weights tab)"))
  	  #Creation progress warning
  	  withProgress({ 
  	    setProgress(message = "Calculating, please wait",
  	                detail = "This may take a few moments...")
  	    vec <- weightAverage(readWeightssaved("Electre"))
  	    
  	    #Create the map with the consensus vector
  	    rst.comb.w=electre(rst.pnl, vec)
  	    rst.comb.w2=normalizer(rst.comb.w)
  	    # The layer is cropped to match the area selected
  	    rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
  	    if(input$inputselect=="1"){
  	      #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
  	      projection(rst.comb.w2) <- projection(areaselected)
  	      rst.comb.w2m <- mask(rst.comb.w2, areaselected)
  	    }else{
  	      rst.comb.w2m <- rst.comb.w2
  	    }
  	    
  	    zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
  	    palos  <-brewer.pal(10,"RdYlBu")
  	    
  	    leaflet()%>%
  	      addGoogleTiles(layerId = "googleTileSat",
  	                     options = tileOptions(maxZoom = 15,
  	                                           updateWhenZooming = TRUE),
  	                     type = "satellite") %>%
  	      setView(lng = xcenter,
  	              lat = ycenter,
  	              zoom = zoomin[1]) %>%
  	      addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityAv)/100) %>%
  	      addLegend(position = "bottomright",colors = palos,
  	                labels =c("0","0,10","0,20","0,30","0,40","0,50","0,60","0,70","0,80","0,90 and more"))
  	    
  	  }, session=session)
  	})
  	
  	# Update the map
  	observe({ 
  	  input$mapCON_Electre_zoom
  	  input$mapOpacityCON2
  	  input$mapCONSelect2
  	  
  	  isolate({
  	    zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
  	    if(input$goButton > 0 ){
  	      if(input$mapCON_Electre_zoom == zoomin[1] || input$mapCON_Electre_zoom == zoomin[2] || input$mapCON_Electre_zoom == zoomin[3] || input$mapCON_Electre_zoom == zoomin[4] || input$mapCON_Electre_zoom == zoomin[5] || input$mapOpacitymain){
  	        vec <- weightAverage(readWeightssaved("LWC2"))
  	        
  	        #Create the map with the consensus vector
  	        rst.comb.w=lwc2(rst.pnl, vec)
  	        rst.comb.w2=normalizer(rst.comb.w)
  	        # The layer is cropped to match the area selected
  	        rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
  	        if(input$inputselect=="1"){
  	          projection(rst.comb.w2) <- projection(areaselected)
  	          rst.comb.w2m <- mask(rst.comb.w2, areaselected)
  	        }else{
  	          rst.comb.w2m <- rst.comb.w2
  	        }
  	        palos  <-brewer.pal(10,"RdYlBu")
  	        
  	        # Redraw the map now
  	        if(input$mapCONSelect2 == 0){
  	          leafletProxy("mapCON_Electre") %>%
  	            clearTiles() %>%
  	            addGoogleTiles(layerId = "googleTileSat",
  	                           options = tileOptions(maxZoom = 15,
  	                                                 updateWhenZooming = TRUE),
  	                           type = "satellite") %>%
  	            clearImages() %>%
  	            addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityCON2)/100)
  	        }
  	        else if (input$mapCONSelect2 == 1){
  	          leafletProxy("mapCON_Electre") %>%
  	            clearTiles() %>%
  	            addGoogleTiles(layerId = "googleTileRoad",
  	                           options = tileOptions(maxZoom = 15,
  	                                                 updateWhenZooming = TRUE),
  	                           type = "roadmap") %>%
  	            clearImages() %>%
  	            addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityCON2)/100)
  	        }
  	        else{
  	          leafletProxy("mapCON_Electre") %>%
  	            clearTiles() %>%
  	            addGoogleTiles(layerId = "googleTileTer",
  	                           options = tileOptions(maxZoom = 15,
  	                                                 updateWhenZooming = TRUE),
  	                           type = "terrain") %>%
  	            clearImages() %>%
  	            addRasterImage(x = rst.comb.w2m,colors = palos,opacity = (input$mapOpacityCON2)/100)
  	        }
  	        
  	      }
  	    }
  	  })
  	})
  	
  	# Legend for the map
  	observeEvent(input$mapshowCON2,{
  	  proxy <- leafletProxy("mapCON_Electre")
  	  palos  <-brewer.pal(10,"RdYlBu")
  	  # Remove any existing legend, and only if the legend is
  	  # enabled, create a new one.
  	  if (input$mapshowCON2) {
  	    proxy %>% addLegend(position = "bottomright",colors = palos,
  	                        labels =c("0","0,10","0,20","0,30","0,40","0,50","0,60","0,70","0,80","0,90 and more"))
  	  }
  	  else{
  	    proxy %>% clearControls()
  	  }
  	})
  	
  	output$tabCON_Electre <- renderTable({input$Project
  	  input$saveButton
  	  #If no weights are saved, warns the user
  	  validate( need((!is.na(readWeightssaved("Electre")) & !is.null(readWeightssaved("Electre"))), ""))
  	  vec <- weightAverage(readWeightssaved("Electre"))
  	  weightArray(vec)
  	})
  
  
    
  	################## Compare projects ###########################################
  	
  	mthr <<-0
  	
  	# List the rasters stored in rastersaved and create a checkboxGroupInput with these rasters
    output$selectrastersaved <- renderUI({input$saveRasterButton
      input$plot_brush
      validate( need(nlayers(rastersaved) >0, "Please save rasters (go back to the select weigths tab"))
      keys <- names(rastersaved)
      mylist <- vector(mode="list", length=length(keys))
      
      mylist= lapply(1:length(keys), function(i){
        key <- names(rastersaved)[i]
        mylist[[key]] <- names(rastersaved)[i]
      })
      names(mylist) <- keys
      checkboxGroupInput("checkGroupCPrRaster",
                         label = h3("Choose two or more rasters"),
                         choices = mylist,
                         selected = NULL)
    })
    
  	# Store the rasters chosen by the users (selected in input$checkGroupCPrRaster) to be compared
    rasterscompared <- reactive({input$CPrbutton
      isolate({ 
        rasterscomp<-stack()
        if(length(input$checkGroupCPrRaster)>1){
          Q = lapply(1:length(input$checkGroupCPrRaster), function(i){
            layer <- subset(rastersaved, input$checkGroupCPrRaster[i])
            if(input$inputselect=="1"){
              projection(layer) <- projection(areaselected)
              layerd <- mask(layer, areaselected)
            }
            rasterscomp <- addLayer(rasterscomp, layer)
          })
          rasterscomp<-stack(Q)
        }
        else {rasterscomp<-stack()}
        return(rasterscomp) 
      })   
    })	
    
    # Define input selection list of the layers which can be displayed  
    output$selectlayerCPrcompared <- renderUI({rasterscompared()
      n<- names(rasterscompared())
      validate( need(length(n) > 1, " "))
      isolate({
          selectInput("Prnamethr", "Choose a layer:",choices=lapply(1:length(n), function(i) {n[i]}))
      })
    })
    
    # Calculus of the best project for each pixel of the area selected
    bestproject <- reactive({rasterscompared()
      isolate({ 
        rastercomp <- rasterscompared()
        bestPr <-which.max(rastercomp)
        bestPr <- ratify(bestPr)
        rat <- levels(bestPr)[[1]]
        rat$legend <- t(t(names(rastercomp)))
        levels(bestPr) <- rat
        return(bestPr) 
      })   
    })		
    
    # Creation of the raster corresponding to the best pixels of the project selected in input$Prnamethr 
    rasterwithBestPixels <- reactive({input$Prnamethr
      validate(need(length(input$Prnamethr) !=0, " "))
      isolate({ 
            rasterscomp <-rasterscompared()
            n <- names(rasterscompared())
            i <- match(input$Prnamethr,n)
            layerthr <- subset(rasterscompared(),input$Prnamethr)
            rst <- overlay(layerthr,bestproject(),fun=function(x,y){ifelse(y == i,x,NA)})
            return(rst) 
      })   
    })	
    
    # Define the maximum of the sliders Threshold
    datamaxThresholdCPr <- reactive({rasterwithBestPixels()
      validate(need(length(input$Prnamethr) !=0, " "))
      # This calculus is needed to know the number of pixels of the unique raster which are not NA
      rstHC <- rasterwithBestPixels()
      # The layer is cropped to match the area selected
      rstHC <- crop(rstHC, extent(areaselected))
      if(input$inputselect=="1"){
        projection(rstHC) <- projection(areaselected)
        rstHC <- mask(rstHC, areaselected)
      }
      area <-maxThrCalculation(rstHC)
      return(area)
    })
    
    # Download button of the rasterwithBestPixels
    output$downloadCPrbutton <- renderUI({
      validate(need(length(input$Prnamethr) !=0 & nlayers(rasterscompared()) > 1, " "))
      downloadButton('downloadRasterCPr', 'Download Raster')
    })
    
    # Download button of the legend of rasterwithBestPixels
    output$downloadCPrLegendbutton <- renderUI({
      validate(need(length(input$Prnamethr) !=0 & nlayers(rasterscompared()) > 1, " "))
      downloadButton('downloadLegendCPr', 'Download Legend')
    })
      
    # Function enabling the downloading of the raster
    output$downloadRasterCPr <- downloadHandler(
      filename = function(){return(paste0("bestproject.tif"))},
      content = function(file) {writeRaster(bestproject(), format="GTiff", file)}
    )
    
    # Function enabling the downloading of the legend
    output$downloadLegendCPr <- downloadHandler( 
      filename = function(){return("Legend.csv")},
      content = function(file) {write.csv(levels(bestproject()), file)}
    )
    
    # Map displaying rasterwithBestPixels
    output$mapCPr <- renderLeaflet({
      # rasterscompared()
      rasterscomp <-rasterscompared()
      validate( need(nlayers(rasterscomp) > 1, 
                     "Please choose two layers or more"))
      
      # Define progress message to warn the user 
      # to wait during the calculus 
      withProgress({ 
        setProgress(message = "Calculating, please wait",
                    detail = "This may take a few moments...")
        
        bestproject <- bestproject()
        bestproject[is.na(bestproject)] <- 0
        
        # The layer is cropped to match the area selected
        bestproject <- crop( bestproject, extent(areaselected))
        if(input$inputselect=="1"){
          projection( bestproject) <- projection(areaselected)
          bestproject <- mask( bestproject, areaselected)
        }
        
        # Definition of the colour palette  of the future map
        zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
        if(nlayers(rasterscomp)>2){
          paloslg  <- brewer.pal(nlayers(rasterscomp),"RdYlBu")
          palos <- colorQuantile("RdYlBu", domain = NULL,n=nlayers(rasterscomp),na.color=NA)
        }
        else{
          palos <- colorQuantile(c("#ff0000","#0000ff"), domain = NULL,n=2,na.color=NA)
          paloslg <- c("#ff0000","#0000ff")
        } 
        
        # Creation of the html request to create the map with Google Maps. 
        # create an html map file and 2 png files a grid and a legend
        b=sapply(0:(nlayers(rasterscomp)), function(i){
          b<-c(i+0.5)}
        )
        
        leaflet()%>%
          addGoogleTiles(layerId = "googleTileSat",
                         options = tileOptions(maxZoom = 15,
                                               updateWhenZooming = TRUE),
                         type = "satellite") %>%
          setView(lng = xcenter,
                  lat = ycenter,
                  zoom = zoomin[1]) %>%
          addRasterImage(x = bestproject,colors = palos,opacity = (input$mapOpacityAv)/100) %>%
          addLegend(position = "bottomright",colors = paloslg,
                    labels =names(rasterscomp))
        
      },session=session)		 
    })
    
    # Update the map
    observe({ 
      input$mapCPr_zoom
      input$mapOpacityCPr
      input$mapCPrSelect
      rasterscomp <-rasterscompared()
      
      validate( need(nlayers(rasterscomp) > 1, 
                     "Please choose two layers or more"))
      
      isolate({
        zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
        if(input$goButton > 0 ){
          if(input$mapCPr_zoom == zoomin[1] || input$mapCPr_zoom == zoomin[2] || input$mapCPr_zoom == zoomin[3] || input$mapCPr_zoom == zoomin[4] || input$mapCPr_zoom == zoomin[5] || input$mapOpacitymain){
            
            bestproject <- bestproject()
            bestproject[is.na(bestproject)] <- 0
            
            # The layer is cropped to match the area selected
            bestproject <- crop( bestproject, extent(areaselected))
            if(input$inputselect=="1"){
              projection( bestproject) <- projection(areaselected)
              bestproject <- mask( bestproject, areaselected)
            }
            
            if(nlayers(rasterscomp)>2){
              # palos  <- brewer.pal(nlayers(rasterscomp),"RdYlBu") 
              palos <- colorQuantile("RdYlBu", domain = NULL,n=nlayers(rasterscomp),na.color=NA)
            }
            else{
              palos <- colorQuantile(c("#ff0000","#0000ff"), domain = NULL,n=2,na.color=NA)
            }
            
            # Redraw the map now
            if(input$mapCPrSelect == 0){
              leafletProxy("mapCPr") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileSat",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "satellite") %>%
                clearImages() %>%
                addRasterImage(x = bestproject,colors = palos,opacity = (input$mapOpacityCPr)/100)
            }
            else if (input$mapCPrSelect == 1){
              leafletProxy("mapCPr") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileRoad",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "roadmap") %>%
                clearImages() %>%
                addRasterImage(x = bestproject,colors = palos,opacity = (input$mapOpacityCPr)/100)
            }
            else{
              leafletProxy("mapCPr") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileTer",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "terrain") %>%
                clearImages() %>%
                addRasterImage(x = bestproject,colors = palos,opacity = (input$mapOpacityCPr)/100)
            }
            
          }
        }
      })
    })
    
    # Legend for the map
    observeEvent(input$mapshowCPr,{
      proxy <- leafletProxy("mapCPr")
      rasterscomp <-rasterscompared()
      validate( need(nlayers(rasterscomp) > 1, " "))
      
      if(nlayers(rasterscomp)>2){
        palos  <- brewer.pal(nlayers(rasterscomp),"RdYlBu") 
      }
      else{
        palos <- c("#ff0000","#0000ff")
      }
      
      # Remove any existing legend, and only if the legend is
      # enabled, create a new one.
      if (input$mapshowCPr) {
        proxy %>% addLegend(position = "bottomright",colors = palos,
                            labels =nlayers(rasterscomp))
      }
      else{
        proxy %>% clearControls()
      }
    })
    
    # Define threshold input as the value of the slider "Threshold" in the panel "compare methods"
    thrInputCPr <- reactive({ 
      input$thrCPr 
      input$thrCPrP
      if(mthr==1){
        y<-input$thrCPr
      }else if (mthr==0){
        y <-input$thrCPrP
      }
      return(y)      
    })

    # Observe which threshold you use
    observeEvent(input$thrCPr, {
      mthr <<- 1
      m <<- "Area"
      #Creation of the div 
      tags$div(  id="textthr",
                 tags$p("Method : ", m))
    })
    observeEvent(input$thrCPrP, {
      mthr<<-0
      m <<- "Percentage"
      #Creation of the div 
      tags$div(  id="textthr",
                 tags$p("Method : ", m))
    })
    
    # Create the threshold input of the tab Compare projects
    output$renderThrCPr <- renderUI({
      sliderInput(inputId="thrCPr", label = "Threshold per ha",min = 0, max =datamaxThresholdCPr(), post=" ha", value = (50/100)*datamaxThresholdCPr())
    })
    output$renderThrCPrP <- renderUI({
      sliderInput(inputId="thrCPrP", label = "Threshold per %",min = 0, max =100, post=" %", value = 50)
    })
    
    valCPr <- reactive({input$thrCPr}) #x
    valCPrP <- reactive({input$thrCPrP}) #y
    
    #Define the wanted threshold (area or quantile)
    observeEvent(input$thrCPr,{
      t <<- "1"
      y <- as.integer((valCPr()*100)/datamaxThresholdCPr())
      updateSliderInput(session, "thrCPrP", value = y, step = 0.01)
    })
    
    observeEvent(input$thrCPrP,{
      t <<- "2"
      x <- as.integer(valCPrP()*(datamaxThresholdCPr()/100))
      updateSliderInput(session, "thrCPr", value = x, step = 0.01)
    })
    ## End of the "two sliders reactivity"
    
    # Define threshold map for each best project
    output$mapCPrThr <- renderLeaflet({
      input$Prnamethr
      if (is.null(input$Prnamethr) == F){
        validate( need(length(input$Prnamethr)==1 & nlayers(rasterscompared()) > 1, " "))
        withProgress({ 
          setProgress(message = "Calculating, please wait",
                      detail = "This may take a few moments...")
          
          rst <- rasterwithBestPixels()
          area <-datamaxThresholdCPr()
          
          thr=as.numeric(cellStats(rst,stat=function(x,na.rm){quantile(x,probs=1-thrInputCPr()[1]/area,na.rm=T)}))
          
          # calculus of the threshold raster
          rstCPr.thr<-calcthr(rst,thr)
          # The layer is cropped to match the area selected
          rstCPr.thr <- crop(rstCPr.thr, extent(areaselected))
          if(input$inputselect=="1"){
            #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
            projection(rstCPr.thr) <- projection(areaselected)
            rstCPr.thr <- mask(rstCPr.thr, areaselected)
          }
          
          # Definition of the colour palette  of the map for one method  
          palos  <-c("#ff0000","#0000ff")
          zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
          
          leaflet()%>%
            addGoogleTiles(layerId = "googleTileSat",
                           options = tileOptions(maxZoom = 15,
                                                 updateWhenZooming = TRUE),
                           type = "satellite") %>%
            setView(lng = xcenter,
                    lat = ycenter,
                    zoom = zoomin[1]) %>%
            addRasterImage(x = rstCPr.thr,colors = colorQuantile(c("#ff0000","#0000ff"), domain = NULL,n=2,na.color=NA),opacity = (input$mapOpacityCPr2)/100) %>%
            addLegend(position = "bottomright",colors = palos,
                      labels =c("bellow","above "))
          
        },session=session)
        
      }
    })
    
    # Update the map
    observe({ 
      input$mapCPrThr_zoom
      input$mapOpacityCPr
      input$mapCPrSelect
      rasterscomp <-rasterscompared()
      
      validate( need(length(input$Prnamethr)==1 & nlayers(rasterscompared()) > 1, " "))
      withProgress({ 
        setProgress(message = "Calculating, please wait",
                    detail = "This may take a few moments...")
        
        isolate({
          zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
          if(input$mapCPrThr_zoom == zoomin[1] || input$mapCPrThr_zoom == zoomin[2] || input$mapCPrThr_zoom == zoomin[3] || input$mapCPrThr_zoom == zoomin[4] || input$mapCPrThr_zoom == zoomin[5] || input$mapOpacitymain){
            
            rst <- rasterwithBestPixels()
            area <-datamaxThresholdCPr()
            
            thr=as.numeric(cellStats(rst,stat=function(x,na.rm){quantile(x,probs=1-thrInputCPr()[1]/area,na.rm=T)}))
            
            # calculus of the threshold raster
            rstCPr.thr<-calcthr(rst,thr)
            # The layer is cropped to match the area selected
            rstCPr.thr <- crop(rstCPr.thr, extent(areaselected))
            if(input$inputselect=="1"){
              #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
              projection(rstCPr.thr) <- projection(areaselected)
              rstCPr.thr <- mask(rstCPr.thr, areaselected)
            }
            # Definition of the colour palette  of the map for one method  
            palos  <-c("#ff0000","#0000ff")
            zoomin <- leafletGoogle::setZoomBound(xdist=xdist, ydist = ydist)
            # Redraw the map now
            if(input$mapCPrSelect2 == 0){
              leafletProxy("mapCPrThr") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileSat",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "satellite") %>%
                clearImages() %>%
                addRasterImage(x = rstCPr.thr,colors = colorQuantile(c("#ff0000","#0000ff"), domain = NULL,n=2,na.color=NA),opacity = (input$mapOpacityCPr2)/100)
            }
            else if (input$mapCPrSelect2 == 1){
              leafletProxy("mapCPrThr") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileRoad",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "roadmap") %>%
                clearImages() %>%
                addRasterImage(x = rstCPr.thr,colors = colorQuantile(c("#ff0000","#0000ff"), domain = NULL,n=2,na.color=NA),opacity = (input$mapOpacityCPr2)/100)
            }
            else{
              leafletProxy("mapCPrThr") %>%
                clearTiles() %>%
                addGoogleTiles(layerId = "googleTileTer",
                               options = tileOptions(maxZoom = 15,
                                                     updateWhenZooming = TRUE),
                               type = "terrain") %>%
                clearImages() %>%
                addRasterImage(x = rstCPr.thr,colors = colorQuantile(c("#ff0000","#0000ff"), domain = NULL,n=2,na.color=NA),opacity = (input$mapOpacityCPr2)/100)
            }
          }
        })
      })
    })
    
    # Legend for the map
    observeEvent(input$mapshowCPr2,{
      proxy <- leafletProxy("mapCPrThr")
      palos  <-c("#ff0000","#0000ff")
      # Remove any existing legend, and only if the legend is
      # enabled, create a new one.
      if (input$mapshowCPr2) {
        proxy %>% addLegend(position = "bottomright",colors = palos,
                            labels =c("bellow","above"))
      }
      else{
        proxy %>% clearControls()
      }
    })
    
    ################## Sensitivity Analysis ###########################################
    
    
    output$matrixSA <- renderTable(rownames = TRUE, {
      input$goSA
      isolate({
        validate(need(!is.null(weightsVector()),""))
        validate(need(Reduce(function(acc, cur) { acc = (acc || (!is.na(cur) && (cur != 0))) }, weightsVector(), F),
                      "Please put a positive weigth for at least one criterion or select new criteria (go back to select criteria tab)"))
        y <- weightsVector()
        ybis <- y[!is.na(y)]
        # Inital values of the variables
        valx <- 1
        valz <- 1
        print("valx, valz")
        print(valx)
        print(valz)
        disturb <- input$randomizerSA/100
        print("disturb")
        print(disturb)
        
        x <- Matrix::Matrix(nrow = length(ybis),ncol = length(y))
        z <- Matrix::Matrix(nrow = length(ybis),ncol = length(y))

        ## We need to have the matrix of the disturbed vector y <- weigthvector()
        ## So there are two matrix : 
        # z is y + disturb
        for(i in 1:length(y)){
          if(!is.na(y[i])){
            buf <- y
            if((y[i]+disturb<1)){
              y[i] <- y[i]+disturb
            }
            else{
              y[i] <- 1
            }
            for(a in 1:length(y)){
              z[valz,a] <- y[a]
            }
            y <- buf
            valz <- valz+1
          }
        }
        
        # x is y - disturb
        for(i in 1:length(y)){
          if(!is.na(y[i])){
            buf <- y
            if((y[i]-disturb)>0){
              y[i] <- y[i]-disturb
            }
            else{
              y[i] <- 0.1
            }
            
            for(a in 1:length(y)){
              x[valx,a] <- y[a]
            }
            y <- buf
            valx <- valx+1
          }
        }
        
        print("----------------------------------------")
        print("y vector")
        print(y)
        print("----------------------------------------")
        print("z matrix")
        print(z)
        print("----------------------------------------")
        print('x matrix')
        print(x) 
        
        # We need to create two list for the Storage of the many rasters that will be created
        # For z = ++
        rasterVectorZ <- list()
        length(rasterVectorZ) <- length(ybis)
        
        # For x = -- 
        rasterVectorX <- list()
        length(rasterVectorX) <- length(ybis)
        
        # Make sure everything as been created in the logs
        # print(rasterVectorZ)
        # print(rasterVectorX)
        
        # Definition of rasterVectorZ and rasterVectorX
        for(i in 1:length(ybis)){
          if(radiomInput()==2){
            rasterVectorZ[[i]] <- lwc2(rst.pnl, z[i,])
            rasterVectorX[[i]] <- lwc2(rst.pnl, x[i,])
          }
          if(radiomInput()==3){
            rasterVectorZ[[i]] <- electre(rst.pnl, z[i,])
            rasterVectorX[[i]] <- electre(rst.pnl, x[i,])
          }
          #This is the transformation of the raster to access 
          # the only information about the quartiles 
          tmpZ <- rasterVectorZ[[i]]
          tmpZ <- raster::cut(tmpZ,breaks=quantile(tmpZ, probs = c(0,0.5,0.75,0.9,1)))
          rasterVectorZ[[i]] <- tmpZ
          #This is the transformation of the raster to access 
          # the only information about the quartiles 
          tmpX <- rasterVectorX[[i]]
          tmpX <- raster::cut(tmpX,breaks=quantile(tmpX, probs = c(0,0.5,0.75,0.9,1)))
          # plot(tmpX)
          rasterVectorX[[i]] <- tmpX
        }
        
        # These are the two matrix to store the information about the quartiles
        quartZ <- Matrix::Matrix(nrow = ((2*length(ybis))+1),ncol = 4)
        # quartX <- Matrix::Matrix(nrow = length(ybis),ncol = 4)
        # print(length(rasterVectorX))
        # print(length(ybis))
        print("----------------------------------------")
        print("vecteur de raster x")
        print(rasterVectorX)
        
        buf <- y
        if(radiomInput()==2){
          buf <- lwc2(rst.pnl, buf)
        }
        if(radiomInput()==3){
          buf <- electre(rst.pnl, buf)
        }
        plot(buf)
        buf <- raster::cut(buf,breaks=quantile(buf, probs = c(0,0.5,0.75,0.9,1)))
        plot(buf)
        quartZ[1,1] <- trunc(freq(buf,value=1))
        quartZ[1,2] <- trunc(freq(buf,value=2))
        quartZ[1,3] <- trunc(freq(buf,value=3))
        quartZ[1,4] <- trunc(freq(buf,value=4))
        
        # for(i in 2:(length(ybis)+1)){
        #   tmpZ <- rasterVectorZ[[i-1]]
        #   quartZ[i,1] <- trunc(freq(tmpZ,value=1))
        #   quartZ[i,2] <- trunc(freq(tmpZ,value=2))
        #   quartZ[i,3] <- trunc(freq(tmpZ,value=3))
        #   quartZ[i,4] <- trunc(freq(tmpZ,value=4))
        # }
        # for(i in (length(ybis)+2):(2*length(ybis)+1)){
        #   tmpX <- rasterVectorX[[i-(length(ybis)+1)]]
        #   quartZ[i,1] <- trunc(freq(tmpX,value=1))
        #   quartZ[i,2] <- trunc(freq(tmpX,value=2))
        #   quartZ[i,3] <- trunc(freq(tmpX,value=3))
        #   quartZ[i,4] <- trunc(freq(tmpX,value=4))
        # }
        nb1 <- 1
        nb2 <- 1
        for(i in 2:(2*length(ybis)+1)){
          if(i%%2==0){
            tmpZ <- rasterVectorZ[[nb1]]
            quartZ[i,1] <- trunc(freq(tmpZ,value=1))
            quartZ[i,2] <- trunc(freq(tmpZ,value=2))
            quartZ[i,3] <- trunc(freq(tmpZ,value=3))
            quartZ[i,4] <- trunc(freq(tmpZ,value=4))
            nb1 <- nb1 + 1
          }
          else{
            tmpX <- rasterVectorX[[nb2]]
            quartZ[i,1] <- trunc(freq(tmpX,value=1))
            quartZ[i,2] <- trunc(freq(tmpX,value=2))
            quartZ[i,3] <- trunc(freq(tmpX,value=3))
            quartZ[i,4] <- trunc(freq(tmpX,value=4))
            nb2 <- nb2 + 1
          }
        }

        print("----------------------------------------")
        print("Quart Z")
        print(quartZ)
        
        # colnames(quartZ) <- c("First quartile (Q1)","Second quartile (Q2)","Third quartile (Q3)","Fourth quartile (Q4)")
        colnames(quartZ) <- c("(Q1)","(Q2)","(Q3)","(Q4)")
        
        base <- "Basic raster"
        character <- substring(as.character(HPN[which(!is.na(y)),]$Description),1,10)
        first <- paste(character, "Disturbed_PLUS", sep=" ")
        second <- paste(character, "Disturbed_minus", sep=" ")
        
        nb1 <- 1
        nb2 <- 1
        rowwname <- c()
        for(i in 2:(2*length(first)+1)){
          if(i%%2==0){
            rowwname <- c(rowwname,first[nb1])
            nb1 <- nb1 + 1
          }
          else{
            rowwname <- c(rowwname,second[nb2])
            nb2 <- nb2 + 1
          }
        }
        
        concat <- c(base, rowwname)
        quartZ <- data.frame(Matrix::as.array(quartZ))
        rownames(quartZ) <- concat
        quartZ
      })
    })
    
    
  })