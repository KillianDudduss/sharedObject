# Tasks that need to occur once, e.g. sourcing scripts, reading some data, and loading packages .
library(shiny)
library(sp)
library(rgdal)
library(raster)
library(rgeos)
library(lattice)
library(plotGoogleMaps)
library(RColorBrewer)
library(dismo)
library(ggplot2)
library(RMySQL)

source("verif_db.R")
source("calc.R")
source("chooser.R")
source("methods.R")
source("creationDataRaster.R")
source("utilitarian.R")

#Loading of the compiled .c code
#To comment when deploying on shiny apps
#if (Sys.info()["sysname"]=="Windows"){dyn.load("methods.dll")}
#if (Sys.info()["sysname"]=="Linux"){dyn.load("methods.so")}
#To uncomment when deploying on shiny apps
dyn.load("methods.so")
  
# Change Project directory to a sub directory www. Everything will happen there now.
setwd("./www/")

#Loading of the data
hc <<-raster(readGDAL("../data/CL_cscapeQ_r01.tif"))
areaselected <<- hc
print("coucou1")
print(hc)
print(areaselected)
Pr <<-read.table(paste0("../data/Project.txt"),h=T)
HC <<-read.table(paste0("../data/Hard_Constraint.txt"),h=T)
rst.hcl <<- creationHardConstraintRaster(HC)
use_HC<<-TRUE
Met <<-read.table(paste0("../data/Methods.txt"),h=T)
# Define server logic required

shinyServer(function(input, output,session) {
	env<-environment()
observe({
	input$userID
	IdentifiedUser(env)
hide("loading_page")
  show("main_content")
})
    # Remove previous maps and grid to avoid oversize issue
    unlink("./*.html")
    unlink("./*.png")
    unlink("./*.png")
    unlink("./weights*.txt")
    # Reset of the rasters saved and the rasters saved numbering
    rastersaved <<- stack()
    num <<- 0
    nbgoodpx<<-0
    px <<-0
    # Define welcome message with the session username 
    output$welcome <- renderUI({
      tags$h3(paste("Welcome"),session$user,"!")
    })
    #test if the data is normalized
    output$testdata <- renderUI({
      validate(need(hc@data@min >= -1 && hc@data@max <= 1, "Data not normalized, please change it."))
    })
    

 ################################### Choice of the project ######################################################
    # Creation of a radiobutton enabling to choose a project
    output$renderProject <- renderUI({
      # Read the names of the projects in the project database and create a list
      Pnames <- sapply(Pr[,2], toString)
      Pnames <- c(Pnames, "My Data")
      mylist <- vector(mode="list", length=length(Pnames))
      mylist= lapply(1:length(Pnames), function(i){
        mylist[[i]] <- i
      })
      names(mylist) <- Pnames

      # Create the radiobutton with each name of project
      radioButtons("Project",label = "Choose a project", choices = mylist, selected = 1)
      
    })
  
    # Depending on the project choosen, loading of the criteria rasters
    observe({
      if (length(input$Project) ==0){
        # By default, if the user doesn't click on the project tab, Project = Forest
        launchingProject(1, Pr)
        initialisation <<- TRUE
      }
      else if (initialisation==TRUE){ 
        # To avoid the reloading of the data when the user clicks on the project tab for the first time
        initialisation <<- FALSE
      }
      else {
        # Uploading data and using the ones existing is different 
        if(input$Project!="3"){
          # Then
          launchingProject(input$Project, Pr)
          #update hc if necessary
          if (input$Project=="2"){
            hc <<-raster(readGDAL("../data/CL_cscapeQ_r01.tif"))
          }
          #Reset the Compare Methods checkbox
          updateCheckboxGroupInput(session=session, inputId="checkGroupCM",choices = list("LWC" = 1, "LWC2" = 2, "Electre" = 3), selected=NULL)
        }
      }
    })
    
    #Event button Download Example
    output$downloadData <- downloadHandler(
      filename = 'Example.zip',
      content = function(f.out.name) {
        cat(f.out.name,"\n")
        zip(zipfile = f.out.name ,files = 'Example')
      },
      contentType = "application/zip"
    )
    
    # Event button ok 
    observeEvent(input$uploaded,{
      if (input$Project=="3"){
        if (length(input$file) !=0){
          # Name of the folder
          nameuploaded <- unlist(strsplit(input$file$name,"\\."))[1]
          # Name diffrent from the others
          if (nameuploaded!= "Forest" && nameuploaded!="Agriculture" ){
            # Erase a file if they have the same name
            if (file.exists(file.path(getwd(),nameuploaded))){
              #file.remove(file.path(getwd(),nameuploaded))
              unlink(file.path(getwd(),nameuploaded), recursive = TRUE)
              file.remove(file.path(getwd(),"0"))
              unlink(file.path(getwd(),"0"), recursive = TRUE)
            }
            # Copy and unzip the data
            p <- input$file$datapath
            file.copy(p, getwd(), overwrite = TRUE)
            unzip(file.path(getwd(),"0"), exdir = ".")
            file.copy(file.path(getwd(),nameuploaded),"../data", overwrite=TRUE, recursive = TRUE)
            # Read the index file and put in the project table
            if (file.exists(file.path(file.path("../data", nameuploaded), "index.txt"))){
              LU <<- scan(file.path(file.path("../data", nameuploaded), "index.txt"), what="factor")
              u <- c(length(Pr[,1])+1, LU)
                
              # update levels
              levels(Pr[,2]) <- c(levels(Pr[,2]), u[2]) 
              levels(Pr[,3]) <- c(levels(Pr[,3]), u[3]) 
              levels(Pr[,4]) <- c(levels(Pr[,4]), u[4]) 
              levels(Pr[,5]) <- c(levels(Pr[,5]), u[5]) 
              levels(Pr[,6]) <- c(levels(Pr[,6]), u[6]) 

              Pr <- rbind(Pr, u)
              launchingProject(input$Project, Pr)
              Pr <<- Pr
              #update hc
              if (file.exists(file.path(file.path("../data", nameuploaded), "extent.tif"))){
                hc <<- raster(readGDAL(file.path(file.path("../data", nameuploaded), "extent.tif")))
                areaselected <<- hc
              }else{
                output$erreur<- renderText({ 
                  paste("extent.tif is missing")})
              }
              #Upload the Hard Constraints
              if (file.exists(file.path(file.path("../data", nameuploaded), "Hard_Constraint.txt"))){
                HC <<-read.table(paste0(file.path(file.path("../data", nameuploaded), "Hard_Constraint.txt")), h=T)
                if(length(HC)==0){
                  use_HC<<-FALSE
                }else{
                  print(nameuploaded)
                  rst.hcl <<- creationHardConstraintRasterUser(HC, nameuploaded)}
              }else{
                use_HC<<-FALSE
              }
              #Reset the Compare Methods checkbox
              updateCheckboxGroupInput(session=session, inputId="checkGroupCM",choices = list("LWC" = 1, "LWC2" = 2, "Electre" = 3), selected=NULL)
              
              output$uploadok<- renderText({ 
                paste("Data uploaded")})
            }else{
             output$erreur<- renderText({ 
              paste("The file is not correct")})
            }
          }else{
            output$erreur<- renderText({ 
              paste("The name of the file is already used.")})
          }
         }else{
           output$erreur<- renderText({ 
             paste("Uploade your data")})
         }
      }else{
        output$uploadok<- renderText({ 
          paste("Please select My Data")})
      }
    })
    
    # Text below the title, indicating the project chosen
    output$typechosen<- renderText({ input$Project
      if (initialisation == TRUE){
        name <- Pr[1,2]
      } 
      else{ 
        if (input$Project=="3"){
          name <- "My Data"
        }else{
        name <- Pr[input$Project,2]}
      paste0("Project selected : ", name)} 
      
    })
   
  
    ######################################### Select Area ###########################################################
    # Enable selection of a smaller area
    output$selectarea <- renderPlot({
      #Plot the map of the entire area
      mymap <- gmap(hc)
      par(bg = "#EBEFE2")
      plot(mymap)
      inputselect <<- "0"
      areaselected <<- is.na(hc)
      observeEvent(input$sarea, {
        inputselect <<- "1"
        error<- " Selection with a Shapefile"
        output$renderShapefile<- renderPlot({
          # Uploade the .zip, unzip it and read it
          file.copy(input$sarea$datapath, getwd(), overwrite = TRUE)
          unzip(file.path(getwd(),"0"), exdir = "./Shapefile")
          dsa <- unlist(strsplit(input$sarea$name,"\\."))[1]
          nsa <- unlist(strsplit(dir(path=file.path("./Shapefile", dsa))[1],"\\."))[1]
          ogrInfo(path.expand(file.path("./Shapefile", dsa)), nsa)
          sa <<- readOGR(dsn=path.expand(file.path("./Shapefile", dsa)), layer=nsa)
          plot(sa)
        })
        output$error <- renderPrint({
          cat(error)
        }) 
      })
      
      observeEvent(input$plot_brush, {
        inputselect <<- "2"
        error<- " Selection with a rectangle"
        output$error <- renderPrint({
          cat(error)
        }) 
      })
      
      observeEvent(input$fullarea, {
        inputselect <<- "0"
        error<- " All the area selected"
        output$error <- renderPrint({
          cat(error)
        }) 
      })
      
      observeEvent(input$selecta, {
        if(inputselect=="1"){
          areaOSGB36 <-extent(sa)
          ## Condition and error for the cut
          if (areaOSGB36@xmax > hc@extent@xmin & areaOSGB36@ymin < hc@extent@ymax
              & areaOSGB36@ymax > hc@extent@ymin & areaOSGB36@xmin < hc@extent@xmax){
            areaselected <<- sa
            rastersaved <<- stack()
            num <<- 0
            error <-"If you re-select an area after doing some analysis without downloading rasters, all the results will be lost."
            if ((rst.pnl@extent == areaOSGB36)==FALSE){
              rst.pnl <<-  cuttingAreaSelected(rst.pnl.original, areaselected)
              rst.nl <<-  cuttingAreaSelected(rst.nl.original, areaselected)
              rst.pl <<- cuttingAreaSelected(rst.pl.original, areaselected)
            }
            
          }else {
            #If the area selected doesn't match the rasters, a text warns the user
            error <- "No data for this area, please select an other one"
          }
        }else if (inputselect=="2"){
          #Selection of a smaller area by drawing a rectangle on the map
          areaMercator <- extent(input$plot_brush$xmin,input$plot_brush$xmax,input$plot_brush$ymin,input$plot_brush$ymax)
          #The area selected projection is Mercator. However the rasters used in the application are in OSGB36
          #So the projection of the area selected must be changed to OSGB36
          OSGB36 <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
          Mercator <- CRS("+proj=merc +a=6378137 +b=6378137 +lat_ts=0.0 +lon_0=0.0 +x_0=0.0 +y_0=0 +k=1.0 +units=m +nadgrids=@null +wktext +no_defs")
          rasterMercator <-raster()
          rasterMercator@crs <- Mercator
          rasterMercator@extent <- areaMercator
          rasterOSGB36 <- projectExtent(rasterMercator, OSGB36)
          # areaOSGB36 is the area selected in OSGB36
          areaOSGB36 <- rasterOSGB36@extent
          error <- ""
          
          ## Condition and error for the cut
          if (areaOSGB36@xmax > hc@extent@xmin & areaOSGB36@ymin < hc@extent@ymax
              & areaOSGB36@ymax > hc@extent@ymin & areaOSGB36@xmin < hc@extent@xmax){
            areaselected <<- areaOSGB36
            rastersaved <<- stack()
            num <<- 0
            error <-"If you re-select an area after doing some analysis without downloading rasters, all the results will be lost."
            if ((rst.pnl@extent == areaselected)==FALSE){
              
              rst.pnl <<-  cuttingAreaSelected(rst.pnl.original, areaselected)
              rst.nl <<-  cuttingAreaSelected(rst.nl.original, areaselected)
              rst.pl <<- cuttingAreaSelected(rst.pl.original, areaselected)
            }
          }else {
            #If the area selected doesn't match the rasters, a text warns the user
            error <- "No data for this area, please select an other one"
          }
          
          
          
        } else if(inputselect=="0") {
          areaselected <<- is.na(hc)
          
          error <-"If you re-select an area after doing some analysis without downloading rasters, all the results will be lost."
          if ((rst.pnl@extent == areaselected@extent)==FALSE){
            
            rst.pnl <<-  cuttingAreaSelected(rst.pnl.original, areaselected)
            rst.nl <<-  cuttingAreaSelected(rst.nl.original, areaselected)
            rst.pl <<- cuttingAreaSelected(rst.pl.original, areaselected)
          }
        }
        output$error <- renderPrint({
          cat(error)
        }) 
      })
      
    })
    
    
 ############################################## Select Hard Constraints #######################################
    # Display the matrix which contains the hard constraints description
    output$matrixHC <- renderTable({
      validate( need(use_HC==TRUE , "No Hard Constraint Data"))
      
      #Transform the row data in understandable text
      descript <-sapply(HC[,4], toString)
      descript <- gsub("_", " ", descript)
      
      #Get back names of hard constraints
      tname <-sapply(HC[,3], toString)

      matrix <- matrix(descript, nrow=length(HC[,1]))
      dimnames(matrix)=list(tname,c("Description"))
      matrix
    })
    
    #Display the select input of hard constraint that the user wants to display on the map
    output$renderSelectHC <-renderUI({
      validate( need(use_HC==TRUE , ""))
      selectInput("hardconstraint", "Choose a hard constraint to display:", 
                  choices=sapply(HC[,3], toString))
    })
    
    # Display the HC map
    output$mapShowHC <- renderUI({input$hardconstraint
      if (length(input$hardconstraint) != 0){
        #The layer displayed is the one selected by the user in input hardconstraint
         layerdisplayed <- subset(rst.hcl,input$hardconstraint)
         # The layer is cropped to match the area selected
         if(inputselect=="1"){
           projection(layerdisplayed) <- projection(areaselected)
           layerd <- mask(layerdisplayed, areaselected)
         }else{
           layerd <- crop(layerdisplayed, areaselected)
         }
         # It is necessary to  fixe the breakpoints to be sure that all the pixels get the right color
         Min <- unique(as.numeric(layerdisplayed@data@min))
         Max <- unique(as.numeric(layerdisplayed@data@max))
         Moy <- unique(as.numeric((Min + Max)/2))
         breakpoints <-c(Min, Moy, Max)
         colors <- c("grey", "green")
         namos <-paste0("MCDAMAHCMap.html", collapse = NULL)
         layerd <- as(layerd,"SpatialPixelsDataFrame")
         # Try to display but return NA if there is an error
         p <- try(plotGoogleMaps(layerd,filename=namos, layerName=input$hardconstraint, at=breakpoints, colPalette = colors, open=FALSE))
         if(is.character(p)){
           tags$p("There is a problem for displaying the map: continue the analysis or choose an other area.", style = "color:red")
         }else{
           # Creation of an iframe displaying the map
          tags$iframe(src=namos, width = "700px", height = "700px")}
      }
    })
    

    # List the hard constraints 
    output$renderChoiceHC <-renderUI({
      validate( need(use_HC==TRUE , ""))
      # Read the names of the hard constraints in the HC database and create a list
      # List of names
      HCnames <- sapply(HC[,3], toString)
      mylist <- vector(mode="list", length=length(HCnames))
      names(mylist) <- HCnames
      mylist=lapply(1:length(HCnames), function(i){
        mylist[[i]] <- names(mylist)[i]
      })
      names(mylist) <- HCnames
      #Create the checkbox to choose hardconstraints
      checkboxGroupInput("checkGroupHC", "Choose the hard constraints :", 
                         choices=mylist, selected= NULL)
    })
    
    # Compilation of the hard constraints raster in one final HC raster
    compilHC <- reactive({input$HCbutton
      
      # case of one contraint selected
      if(length(input$checkGroupHC)>0){
        hc_final <<-subset(rst.hcl, input$checkGroupHC[1])
        
        # case of two contraints selected
        if (length(input$checkGroupHC)==2){
              layer1 <- subset(rst.hcl, input$checkGroupHC[1])
              layer2 <- subset(rst.hcl, input$checkGroupHC[2])
              # If more than 1, they are merged
              hc_final <-overlay(layer1,layer2, fun=function(x,y){ifelse((x+y)==0,0,1)})
        }
        
        # case of three contraints selected
        if(length(input$checkGroupHC)==3){
          layer1 <- subset(rst.hcl, input$checkGroupHC[1])
          layer2 <- subset(rst.hcl, input$checkGroupHC[2])
          layer3 <- subset(rst.hcl, input$checkGroupHC[3])
          # If more than 1, they are merged
          hc_final <-overlay(layer1,layer2,layer3, fun=function(x,y,z){ifelse(x+y+z==0,0,1)})
        }
        
        # case of four contraints selected
        if(length(input$checkGroupHC)==4){
          layer1 <- subset(rst.hcl, input$checkGroupHC[1])
          layer2 <- subset(rst.hcl, input$checkGroupHC[2])
          layer3 <- subset(rst.hcl, input$checkGroupHC[3])
          layer4 <- subset(rst.hcl, input$checkGroupHC[4])
          # If more than 1, they are merged
          hc_final <-overlay(layer1,layer2,layer3,layer4, fun=function(x,y,z,k){ifelse(x+y+z+k==0,0,1)})
        }
        
        # case of more then four constraints selected
        if(length(input$checkGroupHC)>4){
          output$mapFinalHC <- renderPrint({
            cat(paste0("Please choose four hard constraints maximum."))
          }) 
        }
      }     # If 0 HC selected the final raster pixels values get 0
      else{
        hc_final <- rst.hcl[[1]]
        hc_final[hc_final]=0
      }
      return(hc_final)
      
    })
    
    # Display the final HC map if at least one HC is selected
    output$mapFinalHC <- renderUI({input$HCbutton
      isolate({
        if(length(input$checkGroupHC)> 0){
          layerdisplayed <- compilHC()
          layerdisp <- layerdisplayed
          layerdisp[is.na(layerdisplayed)] <- 0
          # The layer is cropped to match the area selected
          if(inputselect=="1"){
            projection(layerdisp) <- projection(areaselected)
            layerd <- mask(layerdisp, areaselected)
          }else{
            layerd <- crop(layerdisp, extent(areaselected))
          }
          Min <- as.numeric(layerdisplayed@data@min)
          Max <- as.numeric(layerdisplayed@data@max)
          Moy <- as.numeric((Min + Max)/2)
          breakpoints <- unique(c(Min, Moy, Max))
          colors <- c("grey", "green")
          namos <-paste0("MCDAMAHCMap.html", collapse = NULL)
          layerd <- as(layerd,"SpatialPixelsDataFrame")
          p <- try(plotGoogleMaps(layerd,filename=namos, layerName="Hard constraints chosen", at=breakpoints, colPalette=colors, open=FALSE))
          if(is.character(p)){
            tags$p("There is a problem for displaying the map: continue the analysis or choose an other area.", style = "color:red")
          }else{
            # Creation of an iframe displaying the map
            tags$iframe(src=namos, width = "700px", height = "700px")}
        }
      })
    })
    
    #Add the hard constraint chosen to the criteria rasters
    observeEvent(input$HCbutton, {
      HCraster <- compilHC()
      nl <- addHC(rst.nl.original, HCraster)
      pl <- addHC(rst.pl.original, HCraster)
      pnl <- addHC(rst.pnl.original, HCraster)
      rst.pnl <<- cuttingAreaSelected(pnl, areaselected)
      rst.nl <<- cuttingAreaSelected(nl, areaselected)
      rst.pl <<- cuttingAreaSelected(pl, areaselected) 
    })
    
    
 ######################################### Select Criteria ####################################################
    # Display the matrix which contains the criteria description
    output$matrixPN <- renderTable({input$Project 
         #Transform the row data in understandable text
         dp <-sapply(HP[,4], toString)
         dn <-sapply(HN[,4], toString)
        
         dp <- gsub("_", " ", dp)
         dn <- gsub("_", " ", dn)
         
         #Get back names of criteria
         tp <-sapply(HP[,3], toString)
         tn <-sapply(HN[,3], toString)
         N <- c(dp,dn) 
         
         matrix <- matrix(N, nrow=length(HP[,1])+length(HN[,1]))
         dimnames(matrix)=list(c(tp,tn),c("Description"))
         matrix
   })
   
    #Display the select input of criteria that the user wants to display on the map
    output$renderSelectCriteria <-renderUI({input$Project
      selectInput("criteria", "Choose a criteria to display:", 
                  choices=rownames(HPN))
    })
    
    # Display the criteria map
    output$mapShowCriteria <- renderUI({input$criteria
      input$HCbutton
      print("coucou3")
      print(rst.pnl)
      
      if (length(input$criteria) != 0){
        layerdisplayed<- subset(rst.pnl,input$criteria)
        print(layerdisplayed)
        # The layer is cropped to match the area selected
        if(inputselect=="1"){
          projection(layerdisplayed) <- projection(areaselected)
          layerd <- mask(layerdisplayed, areaselected)
        }
        else{
          layerd <- crop(layerdisplayed, areaselected)}
        
        Min <- unique(as.numeric(layerdisplayed@data@min))
        Max <- unique(as.numeric(layerdisplayed@data@max))
        Moy <- unique(as.numeric((Min + Max)/2))
        breakpoints <- c(Min, Moy, Max)
        colors <- c("red", "blue")
        namos <-paste0("MCDAMACriteriaMap.html", collapse = NULL)
        print(layerd)
        p<-try(plotGoogleMaps(layerd,filename=namos, layerName=input$criteria, at=breakpoints,colPalette=colors, open=FALSE))
        if(is.character(p)){
          tags$p("There is a problem for displaying the map: continue the analysis or choose an other area.", style = "color:red")
        }else{
          # Creation of an iframe displaying the map
          tags$iframe(src=namos, width = "700px", height = "700px")}
      }
   })
    
    #Chooser
    output$chooserpdisplayed <-renderUI({input$Project 
      chooserInput("mychooserp", "available", "selected",c(x1p[2:length(x1p)]), c(x1p[1]), size = length(x1p), multiple = TRUE)
    })
    output$chooserndisplayed <-renderUI({input$Project 
      chooserInput("mychoosern", "available", "selected",c(x1n[2:length(x1n)]), c(x1n[1]), size = length(x1n), multiple = TRUE)
    })
  
    
 ############################################# Select weights ###########################################
    # Define input sliders as the selected positive criteria of the chooser input for positive criteria. 
    output$slidersp <- renderUI({input$Project
      if(length(input$mychooserp)>=1){
        lapply(1:length(input$mychooserp), function(i) {
          sliderInput(inputId = paste0("sliderp",which(xp==input$mychooserp[i])), label = input$mychooserp[i],min=0, max=1, value=0,ticks=F)
        }
        )                              
      }
    })
    
    # Define input sliders as the selected negative criteria of the chooser input for negative criteria.  
    output$slidersn <- renderUI({input$Project 
      if(length(input$mychoosern)>=1){
        lapply(1:length(input$mychoosern), function(i) {
          sliderInput(inputId = paste0("slidern",which(xn==input$mychoosern[i])), label = input$mychoosern[i],min=0, max=1, value=0,ticks=F)
        }
        )                              
      }
    })
    
    
    # Define input data as the values of each criteria weight (sliders)
    # Updated when goButton is pressed
    weightsVector <- reactive({input$goButton
      isolate({      
        #creation of the vector weight
        y<-c()
        #Loop filling vector weight with positive weights. Check if each positive criteria is selected to plot the sliders. if not remove the slider variable if it existed previously 
        m=unlist(lapply(1:length(xp) ,function(i){
          if(!(toString(xp[i]) %in% input$mychooserp)){
            #rm(list=input[[paste0("sliderp", i)]])
            y <-c(y,NA)
          }
          else{
            y <-c(y,input[[paste0("sliderp", i)]])
          }
        }))
        #Loop filling vector weight with negative weights. Check if each negative criteria is selected to plot the sliders. if not remove the slider variable if it existed previously 
        n=unlist(lapply(1:length(xn) ,function(i){
          if(!(toString(xn[i]) %in% input$mychoosern)){
            #rm(list=input[[paste0("slidern", i)]])
            y <-c(y,NA)
          }
          else{
            y <-c(y,input[[paste0("slidern", i)]])
          }
        }))
        y<-c(m,n)
        ar <- array(NA, dim=(length(xn)+length(xp)-length(input$mychoosern)-length(input$mychooserp)))
        if(identical(y, c(ar))){
          y<-c(array(NA, (length(xn)+length(xp))))
        }
        return(y) 
      })
      
    })
    
    #Waiting for press save button. Save weight combinations in the file created previously for the chosen method
    observe({
      if (input$saveButton == 0){return()}
      isolate({
        y <- weightsVector() 
        if(input$methodsmain==1){
          write(y, file = toString(Path["LWC1",2]),ncolumns = length(HP[,1])+length(HN[,1]),append=TRUE)}
        else if(input$methodsmain==2){    
          write(y, file = toString(Path["LWC2",2]),ncolumns = length(HP[,1])+length(HN[,1]),append=TRUE)}
        else if(input$methodsmain==3){     
          write(y, file = toString(Path["Electre",2]),ncolumns = length(HP[,1])+length(HN[,1]),append=TRUE)}
        })
    })
    
    # Update of rastersaved when save Raster button is pressed 
    observe({
      if (input$saveRasterButton == 0){return()}
      isolate({
          names(temporaryrast) <- paste0(type,"_",num)
          rastersaved <<- addLayer(rastersaved, temporaryrast)
        })
    })
    
    #Waiting for press save for real button. Save final weight combinations in the file created previously for the chosen method
    observe({
      if (input$savorButton == 0){return()}
      isolate({y <- weightsVector()  
      if(input$methodsmain==1){
        write(y, file = toString(Path["LWC1",1]),ncolumns = length(HP[,1])+length(HN[,1]),append=TRUE)}
      else if(input$methodsmain==2){     
        write(y, file = toString(Path["LWC2",1]),ncolumns = length(HP[,1])+length(HN[,1]),append=TRUE)}
      else if(input$methodsmain==3){     
        write(y, file = toString(Path["Electre",1]),ncolumns = length(HP[,1])+length(HN[,1]),append=TRUE)}
      })
    })
    
    # Transform the radio input in an input variable depending of the Go button.	  
    radiomInput <- reactive({input$goButton | input$goButtonThr
      isolate({  
        m <- input$methodsmain
        return(m)						   
      })    
    })
    
    #Calculation of the unique raster with the positive and negative weights vector and the method chosen
    calculmapmain <- reactive({weightsVector() 
      isolate({ 
        radiomInput
        if(radiomInput()==1){
          # Definition of the positive and negative weights vector
          P <- head(weightsVector(),n=length(HP[,1]))
          N <- tail(weightsVector(),n=length(HN[,1]))
          rst.comb.w=lwc(rst.nl, rst.pl,N,P)}
        
        if(radiomInput()==2){rst.comb.w=lwc2(rst.pnl, weightsVector())}
        if(radiomInput()==3){rst.comb.w=electre(rst.pnl, weightsVector())}
       # if(radiomInput()==4){rst.comb.w=regime(rst.pnl, weightsVector())}
        
        # Normalization of the unique raster
        rst.comb.w2=normalizer(rst.comb.w)

        return(rst.comb.w2) 
      })   
    })
    
     # Define main map to visualize the unique raster created with the chosen weights combination 
    output$mapMain <- renderUI({calculmapmain()
      # If all weights sliders are on 0, warns the user
  					validate( need(weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])), "Please put a positive value for at least one criteria or select new criteria (go back to select criteria tab)"))
                                 
  							   # Define progress message to warn the user to wait during the calculus 
  					withProgress({ 
  							  setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
                  rst.comb.w2 <- calculmapmain()
                  # The layer is cropped to match the area selected
                  rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
                  if(inputselect=="1"){
                    projection(rst.comb.w2) <- projection(areaselected)
                    rst.comb.w2m <- mask(rst.comb.w2, areaselected)
                  }else{
                    rst.comb.w2m <- rst.comb.w2
                  }
                  temporaryrast <<- rst.comb.w2m
                  num <<- num+1  
  							  # Transformation of the unique raster data in SpatialPixelsDataFrame
                  prst.spdf <- as(rst.comb.w2m,"SpatialPixelsDataFrame")
  							  # Definition of the colour palette  of the future map
                  palos  <-brewer.pal(10,"RdYlBu")  
  							  # Definition of the name of the map
                  namos  <-paste0("MCDAMAMapI",as.numeric(Sys.time()),".html", collapse = NULL)
                  # Creation of the html request to create the map with Google Maps. create an html map file and 2 png files a grid and a legend
                  p <- try(plotGoogleMaps(prst.spdf,zcol=1, at=unique(seq(0, 1, by=0.1)), colPalette=palos, filename = namos ,layerName=paste0(toString(Pr[Pr$Name==type,3]), " expansion index"), mapTypeId="HYBRID", openMap=FALSE, legend=TRUE))
                  if(is.character(p)){
                    tags$p("There is a problem for displaying the map: continue the analysis or choose an other area.", style = "color:red")
                  }else{
                    # Creation of an iframe displaying the map
  						      tags$iframe(src=namos, width = "100%", height = "800px")}
  						},session=session)		 
    })
   
   # Create an histogram to display the distribution of pixels for this combination of weigths
   output$histo <- renderPlot({ validate( need(weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])),  "Please put a positive value for at least one criteria or select new criteria (go back to select criteria tab)"))
     rst.comb.w2 <- calculmapmain()
     rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
     if(inputselect=="1"){
       projection(rst.comb.w2) <- projection(areaselected)
       rst.comb.w2m <- mask(rst.comb.w2, areaselected)
     }else{
       rst.comb.w2m <- rst.comb.w2
     }
     #Plot the histogram
     hist(na.omit(rst.comb.w2m@data@values),main="Distribution of Pixels Select Criteria",xlab=paste0(toString(Pr[Pr$Name==type,3])," expansion index"))
   })
  
   # Button to download the raster created, displayed only when a map has been displayed
   output$downloadRasterbutton <- renderUI({
     validate( need(weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])), " "))
     downloadButton('downloadRaster', 'Download Raster')
   })
   
   # Function enabling the downloading of the raster
   output$downloadRaster <- downloadHandler( 
        filename = function(){return(paste0(type,"_",num,".tif"))},
        content = function(file) {writeRaster(temporaryrast, format="GTiff", file)}
   )
   
  
   
 ######################################## Threshold ############################################################	
   # Define threshold input as the value of the slider "Threshold" in the panel threshold
   t <- "0"
   # Use of an input button to update
   thrInput <- reactive({input$goButton | input$goButtonThr 
     isolate({      
       y<-input$thr
       return(y)      
     })    
   })
   thrQInput <- reactive({input$goButton | input$goButtonThr 
     isolate({      
       y<-input$thrQ
       return(y)      
     })    
   })
   
   # Define the maximum of the sliders Threshold
   datamaxThreshold<- reactive({input$goButton | input$comparebutton
     layer <-rst.pnl[[1]]
     area <- maxThrCalculation(layer)
     return(area)
   })
   
   # Creation of the slider Threshold
   output$renderThr <- renderUI({
     sliderInput(inputId="thr", label = "Threshold per ha",min = 0, max =datamaxThreshold(), post=" ha", value = 0)
   })
   
   # Creation of the slider Threshold per quantile
   output$renderThrQ <- renderUI({
     sliderInput(inputId="thrQ", label = "Threshold per %",min = 0, max =100, post=" %", value = 0)
   })
   
   #Define the wanted threshold (area or quantile)
   observeEvent(input$thr, {
     t <<- "1"
   })
   observeEvent(input$thrQ, {
     t <<- "2"
   })
   
   
   # Define threshold map to visualize the best pixels under the threshold  
   output$mapThr <- renderUI({input$goButtonThr 
       # If all weights sliders are on 0, warns the user
       validate( need(weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])), "Please put a positive value for at least one criteria (go back to select weights tab) or select new criteria (go back to select criteria tab) (go back to select criteria tab)"))
       
       # Define progress message to warn the user to wait during the calculus 
       withProgress({ 
           setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
           
           rst.comb.w <- calculmapmain()
           area <-datamaxThreshold()
           
           # Calculus of the raster value which corresponds approximately to the quantile of the ratio 1-threshold/total area
           if(t=="0"){
             thr=as.numeric(cellStats(rst.comb.w,stat=function(x,na.rm){quantile(x,probs=1,na.rm=T)}))}
           
           else if (t == "1"){
             thr=as.numeric(cellStats(rst.comb.w,stat=function(x,na.rm){quantile(x,probs=1-thrInput()[1]/area,na.rm=T)}))
           } else if (t == "2"){
             thr=as.numeric(cellStats(rst.comb.w,stat=function(x,na.rm){quantile(x,probs=1-thrQInput()[1]/100,na.rm=T)}))
           }
           
           # calculus of the threshold raster
           rst.comb.thr<-calcthr(rst.comb.w,thr)
           if(inputselect=="1"){
             projection(rst.comb.thr) <- projection(areaselected)
             rst.comb.thrm <- mask(rst.comb.thr, areaselected)
           }else{
             rst.comb.thrm <- rst.comb.thr
           }
           
           # Transformation of the threshold raster data in SpatialPixelsDataFrame
           prst.spdf2 <- as(rst.comb.thrm, "SpatialPixelsDataFrame")
           
           # Definition of the colour palette  of the future map
           palos  <-colorRampPalette( c("red","blue") )  
           
           # Definition of the name of the map
           namos  <-paste0("MCDAMAMapII",as.numeric(Sys.time()),".html", collapse = NULL)
           
           # Creation of the html request to create the map with Google Maps. create an html map file and 2 png files a grid and a legend
           p <- try(plotGoogleMaps(prst.spdf2, at=unique(c(-1,0,1)), col=palos(2), filename = namos ,layerName=paste0(toString(Pr[Pr$Name==type,3])," expansion threshold"),mapTypeId="HYBRID",openMap=F,clickable = TRUE))
           if(is.character(p)){
             tags$p("There is a problem for displaying the map: continue the analysis or choose an other area.", style = "color:red")
           }else{
             # Creation of an iframe displaying the map
            tags$iframe( src=namos, width = "100%", height = "800px")}
       }, session=session)
   })
   
   observeEvent(input$goButtonThr, {
   #Statistics displayed on Thereshold tab
   output$stata  <- renderUI({   
     #If all weights sliders are on 0, display no text
     validate( need(weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])), ""))
       rst.comb.w <- calculmapmain()
       if(inputselect=="1"){
         projection(rst.comb.w) <- projection(areaselected)
         rst.comb.wm <- mask(rst.comb.w, areaselected)
       }else{
         rst.comb.wm <- rst.comb.w
       }
       somma <-nbpx_notNA(rst.comb.wm)
       area <-datamaxThreshold()
       
       # Calculus of the raster value which corresponds approximately to the quantile of the ratio 1-threshold/total area
       if(t=="0"){
         thr=as.numeric(cellStats(rst.comb.wm,stat=function(x,na.rm){quantile(x,probs=1,na.rm=T)}))}
       
       else if (t == "1"){
         thr=as.numeric(cellStats(rst.comb.wm,stat=function(x,na.rm){quantile(x,probs=1-thrInput()[1]/area,na.rm=T)}))
       } else if (t == "2"){
         thr=as.numeric(cellStats(rst.comb.wm,stat=function(x,na.rm){quantile(x,probs=1-thrQInput()[1]/100,na.rm=T)}))
       }
       
       #Calculus of the threshold raster
       rst.comb.thr2=binarythr(rst.comb.wm,thr)
       if(inputselect=="1"){
         projection(rst.comb.thr2) <- projection(areaselected)
         rst.comb.thr2m <- mask(rst.comb.thr2, areaselected)
       }else{
         rst.comb.thr2m <- rst.comb.thr2
       }
       
       #Count the number of good pixels
       c <- cellStats(rst.comb.thr2m,sum)
       
       #Calculus of the number of bad pixels
       d <- somma -c
       
       #Percentage of c and d
       pc <-c/somma*100
       pd <-d/somma*100
       
       # Area of c and d
       Agpx <-(xres(rst.comb.thr2m)*yres(rst.comb.thr2m))/10000*c
       Abpx <-(xres(rst.comb.thr2m)*yres(rst.comb.thr2m))/10000*d
       
       # Chosen method
       if(t =="1"){
         m <<- "Area"
       } else {
         m <<- "Percentage"
       }
       
       #Creation of the stata div 
       tags$div(  id="stata",
                  tags$p("Method : ", m),
                  tags$p("Number of good pixels : ",c),
                  tags$p("Percentage of good pixels : ",tags$b(round(pc, digits = 1)),"%"),
                  tags$p("Area of good pixels : ",tags$i(round(Agpx,digits = 2)),"ha"),
                  tags$p("Number of bad pixels : ",d),
                  tags$p("Percentage of bad pixels : ",tags$b(round(pd, digits = 1)),"%"),
                  tags$p("Area of bad pixels : ",tags$i(round(Abpx,digits = 2)),"ha")
      )
  
   })
   })
   
 ######################################## Compare methods ###################################################
   # Retrieval of the names of the methods to compare (Panel "comparison of methods") from input$checkGroupCM
   mthr=1

   methodscomparedname <- reactive({input$comparebutton
     input$goButton
     isolate({ 
       n <-array(0,3)
       if(length(input$checkGroupCM)==2){
         
         K=sapply(1:2, function(i){
           if(input$checkGroupCM[i]==1){n[i]<- "LWC"}
           else if(input$checkGroupCM[i]==2){n[i]<- "LWC2"}
           else if(input$checkGroupCM[i]==3){n[i]<- "Electre"}
         })
         n[1] <- paste0(K[1], "-", K[2])
         n[2:3]<- K[1:2]
       }
       else {n[] <-0}
       return(n)
     })   
   })		
   
   
   # Calculation of the raster for the two methods chosen and comparison of the two methods
   methodscomparedcalcul <- reactive({methodscomparedname()
     isolate({ 
       n<- methodscomparedname()
       if (n[1] != 0){
         rst.comb <-stack()
         Q= lapply(2:3, function(i){
           if(n[i]=="LWC"){
             P <- head(weightsVector(),n=length(HP[,1]))
             N <- tail(weightsVector(),n=length(HN[,1]))
             rst.comb.w<-lwc(rst.nl, rst.pl,N,P)}
           else if(n[i]=="LWC2"){rst.comb.w<-lwc2(rst.pnl,weightsVector())}
           else if(n[i]=="Electre"){rst.comb.w=electre(rst.pnl, weightsVector())}
           rst.comb.w=normalizer(rst.comb.w)
           rst.comb <- addLayer(rst.comb, rst.comb.w)
         })
         rst.comb=stack(Q)
         # Absolute difference between the two layers
         comp <- abs(rst.comb[[1]] - rst.comb[[2]])
         rst.comb <- addLayer(rst.comb, comp)
         names(rst.comb) <- c(n[2],n[3],n[1])
       }
       return(rst.comb) 
     })    
   })	
   
   # Define input selection list of the layers which can be displayed in the panel "Compare methods":
   # The unique raster with the positive and negative weights vector for each method
   # The absolute difference between the two unique rasters
   output$renderSelectlayerCM <- renderUI({methodscomparedname()
     isolate({
       n<- methodscomparedname()
       if (n[1] != 0){
         selectInput("methodscomp", "Choose a layer to display:",choices=lapply(1:length(n), function(i) {n[i]}))
       }
     })
   })
   
   # Define input selection list of the thresholdlayers which can be displayed in the panel "Compare methods" 
   output$renderSelectlayerThrCM <- renderUI({methodscomparedname()
     isolate({
       n<- methodscomparedname()
       if (n[1] != 0){
         selectInput("thresholdcomp", "Choose a layer to display:", 
                     choices=lapply(1:length(n), function(i) {n[i]}))
       }
     })
   })  
   
   #Text above the map, depends on the layer to be displayed selected
   output$txtmapCM <- renderText({input$methodscomp
     n<- methodscomparedname()
     validate(need(n[1] !=0," "))
     if (is.null(input$methodscomp) == F){
       if (input$methodscomp =="LWC" | input$methodscomp =="LWC2" |input$methodscomp =="Electre"){
         txt<-"The best value is 1 (blue) and the worst 0 (red) for the project chosen Expansion considering these criteria, the weights selected and the chosen method"
       }
       else{
         txt<-"Absolute difference of the values obtained with the two methods chosen."
       }
     txt
     }
   })
   
    # Display the layer selected on input$methodscomp
    output$mapCM <- renderUI({input$methodscomp
      if (is.null(input$methodscomp) == F){
          n<- methodscomparedname()
          validate( need(weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])), "Please put a positive value for at least one criteria (go back to select weights tab) or select new criteria (go back to select criteria tab)"))
          validate( need(n[1] !=0, "Please choose 2 methods"))
          withProgress({ 
                setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
                rst.comb <- methodscomparedcalcul()
                
                #Substitution of the dash (-) by a point to match the selected layer and the layer to display
                dash <- gsub("-",".",input$methodscomp)
                if (names(rst.comb)[1]== dash | names(rst.comb)[2]== dash | names(rst.comb)[3] == dash){
                    layerdisplayed <- subset(rst.comb,dash)
                    # The layer is cropped to match the area selected
                    layerdisplayed <- crop(layerdisplayed, extent(areaselected))
                    if(inputselect=="1"){
                      projection(layerdisplayed) <- projection(areaselected)
                      layerd <- mask(layerdisplayed, areaselected)
                    }else{
                      layerd <- layerdisplayed
                    }
                    # Definition of the colour palette  of the map for one methods
                    palos  <-brewer.pal(10,"RdYlBu")  
              
                    # Definition of the name of the map
                    namos  <-paste0("MCDAMAMapComparison",as.numeric(Sys.time()),".html", collapse = NULL)
                    layerd <- as(layerd, "SpatialPixelsDataFrame")
                    # The colors used on the map depends of the layer chosen to be displayed
                    if (input$methodscomp =="LWC" | input$methodscomp =="LWC2" |input$methodscomp =="Electre"){
                      m<-try(plotGoogleMaps(layerd,at=seq(0, 1, by=0.1),filename = namos, layerName=input$methodscomp,colPalette=palos,  openMap=FALSE))
                      }
                    else{
                       m<-try(plotGoogleMaps(layerd,filename = namos, layerName=input$methodscomp,colPalette=brewer.pal(9,"Reds"), openMap=F))
                    }
                    if(is.character(m)){
                      tags$p("There is a problem for displaying the map: continue the analysis or choose an other area.", style = "color:red")
                    }else{
                      # Creation of an iframe displaying the map                            
                      tags$iframe(src=namos, width = "100%", height = "800px")}
           }},session=session)
      }
    })
    
    # Define the scatter plot of the two methods chosen
    output$scatter <- renderPlot({ methodscomparedname()
      n<- methodscomparedname()
      validate( need(weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])), "Please put a positive value for at least one criteria (go back to select weights tab) or select new criteria (go back to select criteria tab)"))
      validate( need(n[1] !=0, "Please choose 2 methods"))
      withProgress({ 
        setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
        rst.comb <- methodscomparedcalcul()# The layer is cropped to match the area selected
        rst.comb <- crop(rst.comb, extent(areaselected))
        if(inputselect=="1"){
          #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
          projection(rst.comb) <- projection(areaselected)
          rst.combm <- mask(rst.comb, areaselected)
        }else{
          rst.combm <- rst.comb
        }
        layer1 <- subset(rst.combm,n[2])
        layer2 <- subset(rst.combm,n[3])
        plot(na.omit(layer1), na.omit(layer2), xlab=n[2], ylab=n[3])
      },session=session)
    })
    
    # Define threshold input as the value of the slider "Threshold" in the panel "compare methods"
    thrInputCM <- reactive({ input$thrCM | input$thrCMQ
      if(mthr==1){
        y<-input$thrCM
      }else if (mthr==0){
        y <-input$thrCMQ
      }
      return(y)      
    })
   
    
    # Observe which threshold you use
    observeEvent(input$thrCM, {
      mthr <<- 1
    })
    observeEvent(input$thrCMQ, {
      mthr<<-0
    })
    
    # Display the threshold sliderinput in Compare methods
  	output$renderThrCM <- renderUI({
  	         sliderInput(inputId="thrCM", label = "Threshold",min = 0, max =datamaxThreshold(), post = " ha", value = 0)
  	})
  	output$renderThrCMQ <- renderUI({
  	         sliderInput(inputId="thrCMQ", label = "Threshold",min = 0, max =100, post = " %", value = 0)
  	})
  
    # Display the threshold map of the layer selected in input$thresholdcomp
    output$mapThrCM <- renderPlot({input$thresholdcomp
      if (is.null(input$thresholdcomp) == F){
          n<- methodscomparedname()
          # If all weights sliders are on 0, warns the user
          validate( need(weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])) & n[1] !=0, " "))
          
          # Define progress message to warn the user to wait during the calculus 
          withProgress({ 
            setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
            rst.comb <- methodscomparedcalcul()
            dash <- gsub("-",".",input$thresholdcomp)
            rst.comb.thr <- stack()
            if (names(rst.comb)[1]== dash | names(rst.comb)[2]== dash | names(rst.comb)[3] == dash){
               Q=lapply(2:3, function(i){
                    rst.comb.thr.w <- subset(rst.comb, n[i])
                    if(inputselect=="1"){
                      #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
                      projection(rst.comb.thr.w) <- projection(areaselected)
                      rst.comb.thr.w <- mask(rst.comb.thr.w, areaselected)
                    }
                    
            
                    area <- maxThrCalculation(rst.comb.thr.w)
                    # Calculus of the raster value which corresponds approximately to the quantile of the ratio 1-threshold/total area
                    if (mthr==0){
                      thr=as.numeric(cellStats(rst.comb.thr.w,stat=function(x,na.rm){quantile(x,probs=1-thrInputCM()[1]/100,na.rm=T)}))
                    }
                    else if (mthr==1){
                      thr=as.numeric(cellStats(rst.comb.thr.w,stat=function(x,na.rm){quantile(x,probs=1-thrInputCM()[1]/area,na.rm=T)}))
                    }
                    
                    
                    # calculus of the threshold raster
                    rst.comb.thr.w=calcthr(rst.comb.thr.w,thr)
                    rst.comb.thr <- addLayer(rst.comb.thr, rst.comb.thr.w)
               })

               rst.comb.thr<-stack(Q)
               comp <- overlay(rst.comb.thr$layer.1,rst.comb.thr$layer.2, fun=function(x,y){ifelse(x>=0 & y>=0,10,ifelse(x<0 & y<0,-10, ifelse(x>=0 & y<0,-5,5)))})
               
               rst.comb.thr <- addLayer(rst.comb.thr, comp)
               names(rst.comb.thr) <- c(n[2],n[3],n[1])

               layerdisplayed <- subset(rst.comb.thr,dash)
               # The layer is cropped to match the area selected
               layerdisplayed <- crop(layerdisplayed, extent(areaselected))
               if(inputselect=="1"){
                 projection(layerdisplayed) <- projection(areaselected)
                 layerd <- mask(layerdisplayed, areaselected)
               }else{
                 layerd <- layerdisplayed
               }
               
               nbgoodpx <<- length(layerd[layerd==10])
               px <<- sum(is.na(layerd[1:ncell(layerd)])==FALSE)

               # Definition of the colour palette  of the future map
               palos  <- brewer.pal(10,"RdYlBu")  
                
               # Definition of the name of the map
               namos  <-paste0("MCDAMAMapII",as.numeric(Sys.time()),".html", collapse = NULL)
                
               # Creation of the html request to create the map with Google Maps. create an html map file and 2 png files a grid and a legend
               if (input$thresholdcomp =="LWC" | input$thresholdcomp =="LWC2" |input$thresholdcomp =="Electre"){
                 breakpoints<-unique(c(-1,0,1))
                  par(mar=c(8, 4.1, 4.1, 2.1), xpd=F)
                  plot(layerd, legend = FALSE, col = brewer.pal(2,"RdYlBu"),breaks=breakpoints)
                  par(xpd=TRUE,mar=c(1, 4.1, 1, 4.1))
                  legend("bottomright", inset=c(0,-0.4), legend = c("Others", "Best pixels"), fill = brewer.pal(2,"RdYlBu"),xpd = TRUE)
                   
               }
               else{
                  breakpoints<-unique(c(-10,-7,0,7,10))
                  par(mar=c(8, 4.1, 4.1, 2.1), xpd=F)
                  plot(layerd, legend=F, col = brewer.pal(4,"RdYlBu"),breaks=breakpoints)
                  par(xpd=TRUE,mar=c(1, 4.1, 1, 4.1))
                  legend("bottomright", inset=c(0,-0.4), legend = c("Others","Best for the first method","Best for the second method", "Best pixels"), fill = brewer.pal(4,"RdYlBu"))
                }
            }
         }, session=session)
      }
    })
    
    # Calculus used when the user want to compare the threshold between two methods
    # It calculate the area above the threshold for both methods selected
    areaboth <- reactive({thrInputCM()
      areagoodpx <- (xres(rst.pnl[[1]])*yres(rst.pnl[[1]]))/10000* nbgoodpx
      return(areagoodpx)
    })
    percentageboth <- reactive({thrInputCM()
      percentgoodpx <- 100*nbgoodpx/px
      return(percentgoodpx)
    })
    
    # Displayed the number obtained with areabothA ou areabothQ
    output$txtgoodarea <- renderText({
      n<- methodscomparedname()
      validate(need((weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])) & n[1] !=0 & input$thresholdcomp !="LWC" & input$thresholdcomp !="LWC2" & input$thresholdcomp !="Electre")," "))
      if (mthr==1){
        paste0("Areas above threshold for both methods : ",areaboth()," ha")
      }else if (mthr==0){
        paste0("Areas above threshold for both methods : ",percentageboth()," %")
      }
    })
    
     
 ##################################### Stats ###########################################################
  # Create a matrix which contains the positive criteria weights
   output$matrixCurrentWeightsP <- renderTable({input$Project
     weightsVector()  								
  				validate( need(weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])), "Please put a positive value for at least one criteria (go back to select weights tab) or select new criteria (go back to select criteria tab)"))
  									#read the positive weights.create a matrix
                    P <- head(weightsVector(),n=length(HP[,1]))
                    matrix <- matrix(P,nrow=1)
                    dimnames(matrix)=list(c(""),xp)
                    matrix
    })
  								   
  # Create a matrix which contains the negative criteria weights
   output$matrixCurrentWeightsN <- renderTable({input$Project 
     weightsVector()
  				validate( need(weightsVector() != vector(mode = "numeric", length = length(HP[,1])+length(HN[,1])), "Please put a positive value for at least one criteria (go back to select weights tab) or select new criteria (go back to select criteria tab)"))
  									#read the negative weights create a matrix
                    N <- tail(weightsVector(),n=length(HN[,1]))
                    matrix <- matrix(N,nrow=1)
  									dimnames(matrix)=list(c(""),xn)
                    matrix
     })
  								
   #Create the weights history matrix for each method
   output$christomatLWC1 <- renderTable({input$Project
     input$saveButton
     #If no weights are saved, warns the user
  				validate( need(temp_WeightssavedSize("LWC1") > 0, "Please save criteria weights with method LWC (go back to select weights tab)"))
          matrix_Stats(readWeightssaved("LWC1","temp"))
  
     })
   
   output$christomatLWC2 <- renderTable({input$Project
     input$saveButton  #If no weights are saved, warns the user
          validate( need(temp_WeightssavedSize("LWC2") > 0, "Please save criteria weights with method LWC2 (go back to select weights tab)"))
          matrix_Stats(readWeightssaved("LWC2","temp"))
     })
   
   output$christomatElectre <- renderTable({input$Project
     input$saveButton  #If no weights are saved, warns the user
          validate( need(temp_WeightssavedSize("Electre") > 0, "Please save criteria weights with method Electre (go back to select weights tab)"))
          matrix_Stats(readWeightssaved("Electre", "temp"))
     })
  
   #Create the download handler to download the criteria weight history	(CWH)							  
   
   output$downloadCWH_LWC1 <- downloadHandler( 
     filename = function(){return("WeightsLWC.csv")},
     content = function(file) {write.csv(readWeightssaved("LWC1", "temp"), file)}
   )
   
   output$downloadCWH_LWC2 <- downloadHandler( 
     filename = function(){return("WeightsLWC2.csv")},
     content = function(file) { write.csv(readWeightssaved("LWC2","temp"), file)}
   )
   
   output$downloadCWH_Electre <- downloadHandler( 
     filename = function(){return("WeightsElectre.csv")},
     content = function(file) {write.csv(readWeightssaved("Electre","temp"), file)}
   )
   
   
 ############################################## Average ##########################################################					  
  	#Create the average map for each method
   output$mapAV_LWC1 <- renderUI({input$Project
      input$saveButton
  			  #If no weights are saved, warns the user
  			  validate( need(temp_WeightssavedSize("LWC1") > 0, "Please save criteria weights with method LWC (go back to select weights tab)"))
  									  
  								#Creation progress warning
  								withProgress({ 
  							      setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
  									  
  							  	  vec <- weightAverage(readWeightssaved("LWC1", "temp"))
  									  #Create the corresponding map in an iframe
  								  	P <- head(vec,n=length(HP[,1]))
                      N <- tail(vec,n=length(HN[,1]))
  									  rst.comb.w=lwc(rst.nl, rst.pl,N,P)
  									  rst.comb.w2=normalizer(rst.comb.w)
                      # The layer is cropped to match the area selected
                      rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
                      if(inputselect=="1"){
                        #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
                        projection(rst.comb.w2) <- projection(areaselected)
                        rst.comb.w2m <- mask(rst.comb.w2, areaselected)
                      }else{
                        rst.comb.w2m <- rst.comb.w2
                      }
                      prst.spdf <- as(rst.comb.w2m, "SpatialPixelsDataFrame")
                      palos  <-brewer.pal(10,"RdYlBu")  
                      namos  <-paste0("MCDAMAMapIIIA",as.numeric(Sys.time()),".html", collapse = NULL)
                      
                      p <- try(plotGoogleMaps(prst.spdf, at=seq(0, 1, by=0.1), col=palos, filename = namos ,layerName=paste0(toString(Pr[Pr$Name==type,3])," expansion average LWC"),mapTypeId="HYBRID", openMap=F,clickable=TRUE))
                      if(is.character(p)){
                        tags$p("There is a problem for displaying the map: continue the analysis or choose an other area.", style = "color:red")
                      }else{
                        
  									  tags$iframe(       
  												src=namos,
  									       #srcdoc=paste(gsub("http://maps.google.com/", "https://maps.google.com/",readLines(namos), fixed=TRUE), collapse = "\n"),
  												width = "100%",
  												height = "800px"
  												)}
                                                                                                                                                                                                          
  					
                 }, session=session)
    })
  								  
  	output$tabAV_LWC1 <- renderTable({input$Project
  	  input$saveButton  
  					#If no weights are saved, warns the user
  					validate( need(temp_WeightssavedSize("LWC1") > 0, ""))
  	            vec <- weightAverage(readWeightssaved("LWC1", "temp"))
  	            weightArray(vec)
  		})
  	
  	output$mapAV_LWC2 <- renderUI({  input$Project
  	  input$saveButton
  					#If no weights are saved, warns the user
            validate( need(temp_WeightssavedSize("LWC2") > 0, "Please save criteria weights with method LWC2 (go back to select weights tab)"))
                #Creation progress warning
                withProgress({ 
  							    setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
                    vec <- weightAverage(readWeightssaved("LWC2", "temp"))
                    
  									#Create the corresponding map in an iframe
  									rst.comb.w=lwc2(rst.pnl, vec)
                    rst.comb.w2=normalizer(rst.comb.w)
                    # The layer is cropped to match the area selected
                    rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
                    if(inputselect=="1"){
                      #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
                      projection(rst.comb.w2) <- projection(areaselected)
                      rst.comb.w2m <- mask(rst.comb.w2, areaselected)
                    }else{
                      rst.comb.w2m <- rst.comb.w2
                    }
                    prst.spdf <- as(rst.comb.w2m, "SpatialPixelsDataFrame")
                    palos  <-brewer.pal(10,"RdYlBu")  
                    namos  <-paste0("MCDAMAMapIIIB",as.numeric(Sys.time()),".html", collapse = NULL)
                    p <- try(plotGoogleMaps(prst.spdf, at=seq(0, 1, by=0.1), col=palos, filename = namos ,layerName=paste0(toString(Pr[Pr$Name==type,3])," expansion average LWC2"),mapTypeId="HYBRID", openMap=F,clickable=TRUE))
                    if(is.character(p)){
                      tags$p("There is a problem for displaying the map: continue the analysis or choose an other area.", style = "color:red")
                    }else{
                      
                      tags$iframe( src=namos,width = "100%",	height = "800px")}
  									
              }, session=session)
  	  })
  								  
  	output$tabAV_LWC2 <- renderTable({input$Project
  	  input$saveButton  
  					#If no weights are saved, warns the user
            validate( need(temp_WeightssavedSize("LWC2") > 0, ""))
  	            vec <- weightAverage(readWeightssaved("LWC2", "temp"))
  	            weightArray(vec)
       })
  		
  	output$mapAV_Electre <- renderUI({ input$Project
  	  input$saveButton 
  		  #If no weights are saved, warns the user
  		  validate( need(temp_WeightssavedSize("Electre") > 0, "Please save criteria weights with method Electre (go back to select weights tab)"))
  		  #Creation progress warning
  		  withProgress({ 
  		    setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
  		    vec <- weightAverage(readWeightssaved("Electre", "temp"))
  		    
  		    #Create the corresponding map in an iframe
  		    rst.comb.w=electre(rst.pnl, vec)
  		    rst.comb.w2=normalizer(rst.comb.w)
  		    # The layer is cropped to match the area selected
  		    rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
  		    if(inputselect=="1"){
  		      #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
  		      projection(rst.comb.w2) <- projection(areaselected)
  		      rst.comb.w2m <- mask(rst.comb.w2, areaselected)
  		    }else{
  		      rst.comb.w2m <- rst.comb.w2
  		    }
  		    prst.spdf <- as(rst.comb.w2m, "SpatialPixelsDataFrame")
  		    palos  <-brewer.pal(10,"RdYlBu")  
  		    namos  <-paste0("MCDAMAMapIIIA",as.numeric(Sys.time()),".html", collapse = NULL)
  		    p <- try(plotGoogleMaps(prst.spdf, at=seq(0, 1, by=0.1), col=palos, filename = namos ,layerName=paste0(toString(Pr[Pr$Name==type,3])," expansion average Electre"),mapTypeId="HYBRID", openMap=F,clickable=TRUE))
  		    if(is.character(p)){
  		      tags$p("There is a problem for displaying the map: continue the analysis or choose an other area.", style = "color:red")
  		    }else{
  		      
  		      tags$iframe( src=namos,width = "100%",	height = "800px")}
  		  }, session=session)
  	})
  		
  	output$tabAV_Electre <- renderTable({ input$Project
  		  input$saveButton 
  		  #If no weights are saved, warns the user
  		  validate( need(temp_WeightssavedSize("Electre") > 0, ""))
  		  vec <- weightAverage(readWeightssaved("Electre", "temp"))
  		  weightArray(vec)
  		  })
  		
  		
 ################################## Consensus ################################################################
  		
    #Create the consensus map for each method							
    output$mapCON_LWC1 <- renderUI({input$Project
      input$saveButton  #If no combination of weights is saved, warns the user
  						validate( need((!is.na(readWeightssaved("LWC1")) & !is.null(readWeightssaved("LWC1"))), "Please save for real criteria weights with method LWC (go back to select weights tab)"))
              withProgress({ 
  							    setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
                    vec <- weightAverage(readWeightssaved("LWC1"))
                    
  							    #Create the map with the consensus vector in an iframe
  							  	P <- head(vec,n=length(HP[,1]))
                    N <- tail(vec,n=length(HN[,1]))
  							    rst.comb.w=lwc(rst.nl, rst.pl,N,P)
                    rst.comb.w2=normalizer(rst.comb.w)
                    # The layer is cropped to match the area selected
                    rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
                    if(inputselect=="1"){
                      #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
                      projection(rst.comb.w2) <- projection(areaselected)
                      rst.comb.w2m <- mask(rst.comb.w2, areaselected)
                    }else{
                      rst.comb.w2m <- rst.comb.w2
                    }
                    prst.spdf <- as(rst.comb.w2m, "SpatialPixelsDataFrame")
                    palos  <-brewer.pal(10,"RdYlBu")  
                    namos  <-paste0("MCDAMAMapIVA",as.numeric(Sys.time()),".html", collapse = NULL)
                    p <- try(plotGoogleMaps(prst.spdf, at=seq(0, 1, by=0.1), col=palos, filename = namos ,layerName=paste0(toString(Pr[Pr$Name==type,3])," expansion consensus LWC"),mapTypeId="HYBRID", openMap=F,clickable=TRUE))
                    if(is.character(p)){
                      tags$p("There is a problem for displaying the map: continue the analysis or choose an other area.", style = "color:red")
                    }else{
                      # Creation of an iframe displaying the map
  							  	  tags$iframe(src=namos,width = "100%",	height = "800px")}
             
              },session=session)
    })
  								  
  	output$tabCON_LWC1 <- renderTable({  input$Project
  		  input$saveButton
  						#If no weights are saved, warns the user
  						validate( need((!is.na(readWeightssaved("LWC1")) & !is.null(readWeightssaved("LWC1"))), ""))
  						#Create a list of all txt files which contains final combinations
  	      	  vec <- weightAverage(readWeightssaved("LWC1"))
  	      	  weightArray(vec)
  			})
  								  
  	output$mapCON_LWC2 <- renderUI({input$Project
  	  input$saveButton   #If no combination of weights is saved, warns the user
  						validate( need((!is.na(readWeightssaved("LWC2")) & !is.null(readWeightssaved("LWC2"))) , "Please save for real criteria weights with method LWC2 (go back to select weights tab)"))
  						#Creation Progress warning
              withProgress({ 
  							  setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
                  vec <- weightAverage(readWeightssaved("LWC2"))
  														 
  								#Create the map with the consensus vector in an iframe
  							  rst.comb.w=lwc2(rst.pnl, vec)
                  rst.comb.w2=normalizer(rst.comb.w)
                  # The layer is cropped to match the area selected
                  rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
                  if(inputselect=="1"){
                    #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
                    projection(rst.comb.w2) <- projection(areaselected)
                    rst.comb.w2m <- mask(rst.comb.w2, areaselected)
                  }else{
                    rst.comb.w2m <- rst.comb.w2
                  }
                  prst.spdf <- as(rst.comb.w2m, "SpatialPixelsDataFrame")
                  palos  <-brewer.pal(10,"RdYlBu")  
                  namos  <-paste0("MCDAMAMapIVB",as.numeric(Sys.time()),".html", collapse = NULL)
                  p <- try(plotGoogleMaps(prst.spdf, at=seq(0, 1, by=0.1), col=palos, filename = namos ,layerName=paste0(toString(Pr[Pr$Name==type,3])," expansion consensus LWC2"),mapTypeId="HYBRID", openMap=F,clickable=TRUE))
                  if(is.character(p)){
                    tags$p("There is a problem for displaying the map: continue the analysis or choose an other area.", style = "color:red")
                  }else{
                    # Creation of an iframe displaying the map
  								  tags$iframe(  src=namos,width = "100%",height = "800px")}
              },session=session)
  	})
  								  
  	output$tabCON_LWC2 <- renderTable({input$Project
  	  input$saveButton  
  						  #If no weights are saved, warns the user
                validate( need((!is.na(readWeightssaved("LWC2")) & !is.null(readWeightssaved("LWC2"))), ""))
  	            vec <- weightAverage(readWeightssaved("LWC2"))
  	            weightArray(vec)
  		})
  	
  	output$mapCON_Electre <- renderUI({ input$Project
  	  input$saveButton  #If no combination of weights is saved, warns the user
        	  validate( need((!is.na(readWeightssaved("Electre")) & !is.null(readWeightssaved("Electre"))), "Please save for real criteria weights with method Electre (go back to select weights tab)"))
        	  #Creation Progress warning
        	  withProgress( { 
        	    setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
        	    vec <- weightAverage(readWeightssaved("Electre"))
        	  
        	    #Create the map with the consensus vector in an iframe
        	    rst.comb.w=electre(rst.pnl, vec)
        	    rst.comb.w2=normalizer(rst.comb.w)
        	    # The layer is cropped to match the area selected
        	    rst.comb.w2 <- crop(rst.comb.w2, extent(areaselected))
        	    if(inputselect=="1"){
        	      #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
        	      projection(rst.comb.w2) <- projection(areaselected)
        	      rst.comb.w2m <- mask(rst.comb.w2, areaselected)
        	    }else{
        	      rst.comb.w2m <- rst.comb.w2
        	    }
        	    prst.spdf <- as(rst.comb.w2m, "SpatialPixelsDataFrame")
        	    palos  <-brewer.pal(10,"RdYlBu")  
        	    namos  <-paste0("MCDAMAMapIVA",as.numeric(Sys.time()),".html", collapse = NULL)
        	    p <- try(plotGoogleMaps(prst.spdf, at=seq(0, 1, by=0.1), col=palos, filename = namos ,layerName=paste0(toString(Pr[Pr$Name==type,3])," expansion consensus Electre"),mapTypeId="HYBRID", openMap=F,clickable=TRUE))
        	    if(is.character(p)){
        	      tags$p("There is a problem for displaying the map: continue the analysis or choose an other area.", style = "color:red")
        	    }else{
        	      # Creation of an iframe displaying the map
        	    tags$iframe( src=namos, width = "100%",height = "800px")}
        	    
        	  },session=session)
  	})
  	
  	output$tabCON_Electre <- renderTable({input$Project
  	  input$saveButton
    	  #If no weights are saved, warns the user
    	  validate( need((!is.na(readWeightssaved("Electre")) & !is.null(readWeightssaved("Electre"))), ""))
  	    vec <- weightAverage(readWeightssaved("Electre"))
  	    weightArray(vec)
  	})
  
  
    
 ############################################ Compare projects ################################################
    mthr <<-0
  	
  	# List the rasters stored in rastersaved and create a checkboxGroupInput with these rasters
    output$selectrastersaved <- renderUI({input$saveRasterButton
      input$plot_brush
      validate( need(nlayers(rastersaved) >0, "Please save rasters (go back to the select weigths tab"))
      keys <- names(rastersaved)
      mylist <- vector(mode="list", length=length(keys))
      
      mylist= lapply(1:length(keys), function(i){
        key <- names(rastersaved)[i]
        mylist[[key]] <- names(rastersaved)[i]
      })
      names(mylist) <- keys
      checkboxGroupInput("checkGroupCPrRaster",
                         label = h3("Choose two or more rasters"),
                         choices = mylist,
                         selected = NULL)
    })
    
  	# Store the rasters chosen by the users (selected in input$checkGroupCPrRaster) to be compared
    rasterscompared <- reactive({input$CPrbutton
      isolate({ 
        rasterscomp<-stack()
        if(length(input$checkGroupCPrRaster)>1){
          Q = lapply(1:length(input$checkGroupCPrRaster), function(i){
            layer <- subset(rastersaved, input$checkGroupCPrRaster[i])
            if(inputselect=="1"){
              projection(layer) <- projection(areaselected)
              layerd <- mask(layer, areaselected)
            }
            rasterscomp <- addLayer(rasterscomp, layer)
          })
          rasterscomp<-stack(Q)
        }
        else {rasterscomp<-stack()}
        return(rasterscomp) 
      })   
    })	
    
    # Define input selection list of the layers which can be displayed  
    output$selectlayerCPrcompared <- renderUI({rasterscompared()
      n<- names(rasterscompared())
      validate( need(length(n) > 1, " "))
      isolate({
          selectInput("Prnamethr", "Choose a layer:",choices=lapply(1:length(n), function(i) {n[i]}))
      })
    })
    
    # Calculus of the best project for each pixel of the area selected
    bestproject <- reactive({rasterscompared()
      isolate({ 
        rastercomp <- rasterscompared()
        bestPr <-which.max(rastercomp)
        bestPr <- ratify(bestPr)
        rat <- levels(bestPr)[[1]]
        rat$legend <- t(t(names(rastercomp)))
        levels(bestPr) <- rat
        return(bestPr) 
      })   
    })		
    
    # Creation of the raster corresponding to the best pixels of the project selected in input$Prnamethr 
    rasterwithBestPixels <- reactive({input$Prnamethr
      validate(need(length(input$Prnamethr) !=0, " "))
      isolate({ 
            rasterscomp <-rasterscompared()
            n <- names(rasterscompared())
            i <- match(input$Prnamethr,n)
            layerthr <- subset(rasterscompared(),input$Prnamethr)
            rst <- overlay(layerthr,bestproject(),fun=function(x,y){ifelse(y == i,x,NA)})
            return(rst) 
      })   
    })	
    
    # Define the maximum of the sliders Threshold
    datamaxThresholdCPr <- reactive({rasterwithBestPixels()
      validate(need(length(input$Prnamethr) !=0, " "))
      # This calculus is needed to know the number of pixels of the unique raster which are not NA
      rstHC <- rasterwithBestPixels()
      # The layer is cropped to match the area selected
      rstHC <- crop(rstHC, extent(areaselected))
      if(inputselect=="1"){
        projection(rstHC) <- projection(areaselected)
        rstHC <- mask(rstHC, areaselected)
      }
      area <-maxThrCalculation(rstHC)
      return(area)
    })
    
    # Download button of the rasterwithBestPixels
    output$downloadCPrbutton <- renderUI({
      validate(need(length(input$Prnamethr) !=0 & nlayers(rasterscompared()) > 1, " "))
      downloadButton('downloadRasterCPr', 'Download Raster')
    })
    
    # Download button of the legend of rasterwithBestPixels
    output$downloadCPrLegendbutton <- renderUI({
      validate(need(length(input$Prnamethr) !=0 & nlayers(rasterscompared()) > 1, " "))
      downloadButton('downloadLegendCPr', 'Download Legend')
    })
      
    # Function enabling the downloading of the raster
    output$downloadRasterCPr <- downloadHandler(
      filename = function(){return(paste0("bestproject.tif"))},
      content = function(file) {writeRaster(bestproject(), format="GTiff", file)}
    )
    
    # Function enabling the downloading of the legend
    output$downloadLegendCPr <- downloadHandler( 
      filename = function(){return("Legend.csv")},
      content = function(file) {write.csv(levels(bestproject()), file)}
    )
    
    # Map displaying rasterwithBestPixels
    output$mapCPr <- renderUI({rasterscompared()
      rasterscomp <-rasterscompared()
      validate( need(nlayers(rasterscomp) > 1, "Please choose two layers or more"))

      # Define progress message to warn the user to wait during the calculus 
      withProgress({ 
        setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
        bestproject <-bestproject()
        bestproject[is.na(bestproject)] <- 0
        # The layer is cropped to match the area selected
        bestproject <- crop( bestproject, extent(areaselected))
        if(inputselect=="1"){
          projection( bestproject) <- projection(areaselected)
          bestproject <- mask( bestproject, areaselected)
        }
        # Definition of the colour palette  of the future map
        palos  <- brewer.pal(nlayers(rasterscomp),"RdYlBu") 
        
        # Definition of the name of the map
        namos  <-paste0("MCDAMAMapCPr.html", collapse = NULL)
        # Creation of the html request to create the map with Google Maps. create an html map file and 2 png files a grid and a legend
        b=sapply(0:(nlayers(rasterscomp)), function(i){
          b<-c(i+0.5)
        })
        m<-try(plotGoogleMaps(bestproject, filename = namos, layerName="Comparison between project",at= b,colPalette=palos,openMap=FALSE, legend= FALSE))
        if(is.character(m)){
          tags$p("There is a problem for displaying the map: continue the analysis or choose an other area.", style = "color:red")
        }else{
          # Creation of an iframe displaying the map
          tags$iframe( src=namos, width = "100%", height = "800px")}
      },session=session)		 
    })
    
    # Legend of the mapCPr
    output$Legend <- renderPlot({
      rasterscomp <-rasterscompared()
      validate( need(nlayers(rasterscomp) > 1, " "))
      par(bg = "#94C73F")
      plot(1, type="n", axes=FALSE, xlab="", ylab="")
      palos  <-brewer.pal(nlayers(rasterscomp),"RdYlBu")  
      legend(1, 1, title= "Legend", legend = names(rasterscomp),fill=palos)
    })
    
    # Define threshold input as the value of the slider "Threshold" in the panel "compare methods"
    thrInputCPr <- reactive({ input$thrCPr | input$thrCPrP
      if(mthr==1){
        y<-input$thrCPr
      }else if (mthr==0){
        y <-input$thrCPrP
      }
      return(y)      
    })

    # Observe which threshold you use
    observeEvent(input$thrCPr, {
      mthr <<- 1
      m <<- "Area"
      #Creation of the div 
      tags$div(  id="textthr",
                 tags$p("Method : ", m))
    })
    observeEvent(input$thrCPrP, {
      mthr<<-0
      m <<- "Percentage"
      #Creation of the div 
      tags$div(  id="textthr",
                 tags$p("Method : ", m))
    })
    
    # Create the threshold input of the tab Compare projects
    output$renderThrCPr <- renderUI({
      sliderInput(inputId="thrCPr", label = "Threshold",min = 0, max =datamaxThresholdCPr(), post=" ha", value = 0)
    })
    output$renderThrCPrP <- renderUI({
      sliderInput(inputId="thrCPrP", label = "Threshold",min = 0, max =100, post=" %", value = 0)
    })
    

    # Define threshold map for each best project
    output$mapCPrThr <- renderUI({input$Prnamethr
      if (is.null(input$Prnamethr) == F){
          validate( need(length(input$Prnamethr)==1 & nlayers(rasterscompared()) > 1, " "))
          withProgress({ 
            setProgress(message = "Calculating, please wait",detail = "This may take a few moments...")
            rst <- rasterwithBestPixels()
            area <-datamaxThresholdCPr()
            
            # Calculus of the raster value which corresponds approximately to the quantile 
            if (mthr==0){
              thr=as.numeric(cellStats(rst,stat=function(x,na.rm){quantile(x,probs=1-thrInputCPr()[1]/100,na.rm=T)}))
            }
            if (mthr==1){
              thr=as.numeric(cellStats(rst,stat=function(x,na.rm){quantile(x,probs=1-thrInputCPr()[1]/area,na.rm=T)}))
            }
            
            # calculus of the threshold raster
            rstCPr.thr<-calcthr(rst,thr)
            # The layer is cropped to match the area selected
            rstCPr.thr <- crop(rstCPr.thr, extent(areaselected))
            if(inputselect=="1"){
              #projection(areaselected) <- CRS("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs")
              projection(rstCPr.thr) <- projection(areaselected)
              rstCPr.thr <- mask(rstCPr.thr, areaselected)
            }
      
            # Definition of the colour palette  of the map for one methods
            #palos  <-brewer.pal(10,"RdYlBu")  
            palos  <-colorRampPalette( c("red","blue") ) 
            
            # Definition of the name of the map
            namos  <-paste0("MCDAMAMapComparisonThr.html", collapse = NULL)
            rstCPr.thr <- as(rstCPr.thr, "SpatialPixelsDataFrame")
            m<-try(plotGoogleMaps(rstCPr.thr, at=c(-1,0,1), col=palos(2),filename = namos, layerName=input$Prnamethr,  openMap=FALSE))
            if(is.character(m)){
              tags$p("There is a problem for displaying the map: continue the analysis or choose an other area.", style = "color:red")
            }else{
              # Creation of an iframe displaying the map
              tags$iframe(src=namos, width = "100%", height = "800px")}
          },session=session)
                     
      }
    })
    })

