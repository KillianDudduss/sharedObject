library(shiny)
library(RMySQL)
library(devtools)

#This function makes sure the user is loged in before accessing the app
#If not, the app is terminated

#TODO : secure database connection
con = dbConnect(MySQL(), user='root', password='', db='shiny', host='localhost')

IdentifiedUser<-function(env){
#Getting the user id and user name thanks to the javascript input
	userID <- reactive({ env$input$userID }) 
	username <- reactive({ env$input$username }) 

	observe({
		userID()
		if(is.null(userID())||is.null(username())){
                        shinyjs::hide("loading_page")
                        shinyjs::info("You are not autorised to launch this application")
                        env$session$close()
		}
		if((userID()=='')||(username()=='')){
                        shinyjs::hide("loading_page")
                        shinyjs::info("You are not autorised to launch this application")
                        env$session$close()
                }
		if((userID()=='undefined')||(username()=='undefined')){
			shinyjs::hide("loading_page")
			shinyjs::info("You are not autorised to launch this application")
			env$session$close()
		}

		query<-paste("SELECT user_key FROM users WHERE user_name='",username(),"'",sep = "")
		result <- dbGetQuery(con, query)

		if(!(userID()==result)){
                        shinyjs::hide("loading_page")
			shinyjs::info("bad credentials")
			env$session$close()
		}
		else{
			shinyjs::hide("loading_page")
			shinyjs::show("main_content")
		}
	})
  
}
